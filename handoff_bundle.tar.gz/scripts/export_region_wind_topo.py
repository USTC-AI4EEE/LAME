#!/usr/bin/env python
"""
Determine the geographic extent of the local ERA5/CERRA data, then export
PNG images of wind speed and terrain for that region.

What it does
- Reads an ERA5 monthly GRIB from `data/WindSRData/ERA5/<year>/` to infer
  the latitude/longitude bounds and grid size (also cross-validates with
  CERRA if present).
- Exports a wind-speed PNG (monthly mean or a selected time index).
- Attempts to download and plot terrain for the same region using an
  online global DEM source (requires network). If download fails, it
  prints clear instructions.

Notes
- Wind comes from local GRIB files (u10/v10 for ERA5).
- Terrain is fetched from ETOPO1 (global 1 arc‑min) via OPeNDAP when
  available. You can also use OpenTopography with an API key.

Examples
  python scripts/export_region_wind_topo.py --year 2019 --month 01 \
      --wind-agg mean --out-dir outputs

  python scripts/export_region_wind_topo.py --year 2019 --month 01 \
      --wind-agg snapshot --time-index 0 --out-dir outputs

  # Use OpenTopography (SRTMGL3 ~90m) if you have an API key
  OPENTOPO_API_KEY=... \
  python scripts/export_region_wind_topo.py --year 2019 --month 01 \
      --topo-source opentopo --out-dir outputs
"""
from __future__ import annotations

import argparse
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Tuple

import numpy as np
import xarray as xr


# Try to import cfgrib (required for reading GRIB)
try:
    import cfgrib  # noqa: F401
except Exception as e:  # pragma: no cover - environment dependent
    raise SystemExit(
        "cfgrib is required. Install with: pip install xarray cfgrib eccodes"
    )


@dataclass
class Region:
    north: float
    south: float
    west: float
    east: float
    h: int
    w: int

    def __str__(self) -> str:
        return (
            f"lat [{self.south}, {self.north}], lon [{self.west}, {self.east}] "
            f"grid {self.h}x{self.w}"
        )


def find_grib(base: Path, year: str) -> Path:
    """Pick a GRIB file for given year under base directory.

    Searches `<base>/<year>/era5_<year>_*.grib`.
    """
    year_dir = base / year
    if not year_dir.is_dir():
        raise FileNotFoundError(f"Directory not found: {year_dir}")
    matches = sorted(year_dir.glob(f"era5_{year}_*.grib"))
    if not matches:
        raise FileNotFoundError(f"No GRIB files found under {year_dir}")
    return matches[0]


def read_region_from_era5_grib(grib_path: Path) -> Region:
    ds = xr.open_dataset(grib_path, engine="cfgrib")
    # ERA5 has 1D latitude/longitude axes
    lat = ds["latitude"]
    lon = ds["longitude"]
    north = float(lat.max())
    south = float(lat.min())
    west = float(lon.min())
    east = float(lon.max())
    h = lat.sizes.get("latitude", lat.size)
    w = lon.sizes.get("longitude", lon.size)
    return Region(north=north, south=south, west=west, east=east, h=h, w=w)


def export_wind_png(
    grib_path: Path,
    out_png: Path,
    agg: str = "mean",
    time_index: Optional[int] = None,
) -> None:
    """Export wind-speed (m/s) PNG from ERA5 u10/v10 in a GRIB file.

    agg: 'mean' for monthly mean, 'snapshot' for a specific time index.
    """
    ds = xr.open_dataset(grib_path, engine="cfgrib")
    if not {"u10", "v10"}.issubset(set(ds.data_vars)):
        raise ValueError(f"u10/v10 not found in {grib_path}")
    u = ds["u10"]
    v = ds["v10"]
    spd = np.sqrt((u**2 + v**2).astype("float64"))  # xarray DataArray

    if agg == "mean":
        field = spd.mean(dim="time")
        title = f"ERA5 wind speed mean: {grib_path.stem}"
    elif agg == "snapshot":
        if time_index is None:
            raise ValueError("time_index is required for agg='snapshot'")
        field = spd.isel(time=time_index)
        title = f"ERA5 wind speed t={int(time_index)}: {grib_path.stem}"
    else:
        raise ValueError("agg must be 'mean' or 'snapshot'")

    arr = field.values

    import matplotlib.pyplot as plt

    vmin = float(np.nanmin(arr))
    vmax = float(np.nanmax(arr))
    fig, ax = plt.subplots(figsize=(6, 6))
    im = ax.imshow(arr, origin="lower", interpolation="none", vmin=vmin, vmax=vmax, cmap="viridis")
    ax.set_title(title, fontsize=9)
    ax.axis("off")
    fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04, label="m/s")
    out_png.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out_png, dpi=200, bbox_inches="tight")
    print(f"Saved wind PNG -> {out_png.resolve()}")


def try_fetch_topography_etopo(region: Region) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Try fetching ETOPO1 bedrock heights via OPeNDAP and return (Z, lats, lons).

    Returns
    -------
    Z : 2D np.ndarray (lat x lon)
    lats : 1D np.ndarray
    lons : 1D np.ndarray

    Raises on failure.
    """
    # ETOPO1 (grid-registered). Uses x='lon', y='lat'
    url = (
        "https://www.ngdc.noaa.gov/thredds/dodsC/relief/ETOPO1/data/bedrock/"
        "grid_registered/ETOPO1_Bed_g_gmt4.grd"
    )
    try:
        ds = xr.open_dataset(url)  # requires netcdf4/pydap
    except Exception as e:
        raise RuntimeError(f"Failed to open ETOPO1 via OPeNDAP: {e}")

    # Coordinates are named 'x' (lon) and 'y' (lat)
    x = ds["x"]
    y = ds["y"]
    # Select region; note longitudes are 0..360 or -180..180 depending on dataset
    # ETOPO1 uses -180..180, so we can select directly
    sub = ds.sel(
        x=slice(region.west, region.east),
        y=slice(region.south, region.north),
    )
    Z = sub["z"].values  # elevation in meters
    lats = sub["y"].values
    lons = sub["x"].values
    return Z, lats, lons


def try_fetch_topography_opentopo(region: Region, api_key: Optional[str]) -> Path:
    """Download SRTMGL3 GeoTIFF via OpenTopography API and return local path.

    Requires OPENTOPO_API_KEY.
    """
    if not api_key:
        raise RuntimeError("OpenTopography API key is required (OPENTOPO_API_KEY)")
    url = (
        "https://portal.opentopography.org/API/globaldem?"
        f"demtype=SRTMGL3&south={region.south}&north={region.north}"
        f"&west={region.west}&east={region.east}&outputFormat=GTiff"
        f"&API_Key={api_key}"
    )
    import requests

    out_dir = Path("outputs/topography")
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / (
        f"srtmgl3_{region.south:.2f}_{region.north:.2f}_{region.west:.2f}_{region.east:.2f}.tif"
    )
    print(f"Requesting OpenTopography DEM...\n{url}")
    r = requests.get(url, timeout=300)
    if r.status_code != 200:
        raise RuntimeError(f"OpenTopography request failed: HTTP {r.status_code}: {r.text[:200]}")
    with open(out_path, "wb") as f:
        f.write(r.content)
    print(f"Saved DEM GeoTIFF -> {out_path.resolve()}")
    return out_path


def export_topography_png(
    region: Region,
    out_png: Path,
    topo_source: str = "auto",
) -> None:
    """Export a PNG of terrain for the region.

    topo_source: 'auto'|'etopo'|'opentopo'
    - 'etopo' uses ETOPO1 via OPeNDAP (requires network, no API key).
    - 'opentopo' uses OpenTopography SRTMGL3 (requires OPENTOPO_API_KEY).
    - 'auto' tries ETOPO1 then OpenTopography.
    """
    Z: Optional[np.ndarray] = None
    lats: Optional[np.ndarray] = None
    lons: Optional[np.ndarray] = None
    used: Optional[str] = None

    errors: list[str] = []
    def try_etopo():
        nonlocal Z, lats, lons, used
        Z, lats, lons = try_fetch_topography_etopo(region)
        used = "ETOPO1"

    def try_opentopo():
        nonlocal Z, lats, lons, used
        api_key = os.environ.get("OPENTOPO_API_KEY")
        tif = try_fetch_topography_opentopo(region, api_key)
        # Read GeoTIFF with rasterio if available, else fall back to imageio
        try:
            import rasterio
            with rasterio.open(tif) as src:
                Z = src.read(1)
            used = "OpenTopography SRTMGL3 (GeoTIFF)"
            lats = np.array([])  # not used in imshow
            lons = np.array([])
        except Exception as e:
            raise RuntimeError(
                f"Downloaded DEM but couldn't read GeoTIFF (install rasterio): {e}"
            )

    try:
        if topo_source in ("auto", "etopo"):
            try_etopo()
        elif topo_source == "opentopo":
            try_opentopo()
        else:
            raise ValueError("topo_source must be 'auto', 'etopo', or 'opentopo'")
    except Exception as e:
        errors.append(str(e))
        if topo_source == "auto":
            try:
                try_opentopo()
            except Exception as e2:
                errors.append(str(e2))

    if Z is None:
        msg = (
            "Failed to fetch terrain. Errors: " + " | ".join(errors) +
            "\nSet OPENTOPO_API_KEY and try --topo-source opentopo, or ensure network access to NOAA THREDDS for ETOPO1."
        )
        raise RuntimeError(msg)

    import matplotlib.pyplot as plt

    vmin = float(np.nanpercentile(Z, 1))
    vmax = float(np.nanpercentile(Z, 99))
    fig, ax = plt.subplots(figsize=(6, 6))
    im = ax.imshow(Z, origin="lower", cmap="terrain", vmin=vmin, vmax=vmax)
    ax.set_title(f"Terrain elevation ({used})", fontsize=9)
    ax.axis("off")
    fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04, label="m")
    out_png.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out_png, dpi=200, bbox_inches="tight")
    print(f"Saved terrain PNG -> {out_png.resolve()}")


def main() -> None:
    ap = argparse.ArgumentParser(description="Export region wind/terrain PNGs for local ERA5/CERRA")
    ap.add_argument("--year", default="2019", help="Year to use for GRIB lookup (e.g., 2019)")
    ap.add_argument("--month", default="01", help="Month to use for GRIB lookup (e.g., 01)")
    ap.add_argument("--base", default="data/WindSRData", help="Base data root (symlinked in repo)")
    ap.add_argument("--out-dir", default="outputs", help="Output directory for PNGs")
    ap.add_argument(
        "--wind-agg",
        choices=["mean", "snapshot"],
        default="mean",
        help="Aggregate monthly mean or single snapshot",
    )
    ap.add_argument("--time-index", type=int, default=0, help="Time index if --wind-agg snapshot")
    ap.add_argument(
        "--topo-source",
        choices=["auto", "etopo", "opentopo"],
        default="auto",
        help="Where to obtain terrain data",
    )
    args = ap.parse_args()

    base = Path(args.base)
    era5_grib = find_grib(base / "ERA5", args.year)
    cerra_grib = None
    try:
        cerra_grib = find_grib(base / "CERRA_reproject", args.year)
    except Exception:
        pass

    region = read_region_from_era5_grib(era5_grib)
    print("Detected region from ERA5:", region)

    if cerra_grib is not None:
        try:
            cerra_ds = xr.open_dataset(cerra_grib, engine="cfgrib")
            lat = cerra_ds["latitude"]
            lon = cerra_ds["longitude"]
            print(
                "CERRA grid:",
                f"lat [{float(lat.min()):.2f}, {float(lat.max()):.2f}], ",
                f"lon [{float(lon.min()):.2f}, {float(lon.max()):.2f}], ",
                f"grid {lat.size}x{lon.size}",
            )
        except Exception as e:
            print(f"Warning: couldn't open CERRA GRIB to cross-validate: {e}")

    out_dir = Path(args.out_dir)
    wind_png = out_dir / f"wind_speed_{args.year}_{args.month}_{args.wind_agg}.png"
    # Prefer the requested month if available, else first GRIB
    month_grib = (era5_grib.parent / f"era5_{args.year}_{args.month}.grib")
    use_grib = month_grib if month_grib.exists() else era5_grib
    if month_grib.exists():
        print(f"Using GRIB for wind: {month_grib}")
    else:
        print(f"Requested month not found; using: {era5_grib}")
    export_wind_png(
        use_grib,
        wind_png,
        agg=args.wind_agg,
        time_index=args.time_index,
    )

    topo_png = out_dir / f"terrain_{args.topo_source}.png"
    try:
        export_topography_png(region, topo_png, topo_source=args.topo_source)
    except Exception as e:
        print("WARNING: Terrain export skipped.")
        print(e)
        # Still print how to get it next time
        print(
            "Hint: set OPENTOPO_API_KEY and run with --topo-source opentopo, "
            "or ensure OPeNDAP to NOAA ETOPO1 is reachable and use --topo-source etopo."
        )


if __name__ == "__main__":
    main()

