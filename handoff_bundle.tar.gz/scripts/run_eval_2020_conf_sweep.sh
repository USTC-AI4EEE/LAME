#!/usr/bin/env bash
set -euo pipefail

# 2020 split evaluation sweep across specified noise levels, using a given checkpoint.
# Noise levels follow configs/experiment/center/paper/confidence definitions:
#   - clean (no noise)
#   - additive std=1.0
#   - angle jitter deg=10
#   - magnitude scale std=0.1
#   - pixel drop prob=0.05
#   - block/cutout drop prob=0.5
#
# Usage:
#   bash scripts/run_eval_2020_conf_sweep.sh [-c CKPT] [-d DEVICE] [-o OUT_ROOT]
#
# Options:
#   -c CKPT     Path to checkpoint (.ckpt). Default set to your provided path below.
#   -d DEVICE   Device override: auto|cpu|gpu (default: auto)
#   -o OUT_ROOT Output root directory (default: logs/eval/2020_conf_sweep)
#

CKPT_DEFAULT="logs/train/runs/<experiment>/<timestamp>/checkpoints/epoch_xxx.ckpt"
CKPT="$CKPT_DEFAULT"
DEVICE="auto"
OUT_ROOT="logs/eval/2020_conf_sweep"

while getopts ":c:d:o:h" opt; do
  case $opt in
    c) CKPT="$OPTARG" ;;
    d) DEVICE="$OPTARG" ;;
    o) OUT_ROOT="$OPTARG" ;;
    h)
      cat <<USAGE
Usage: bash scripts/run_eval_2020_conf_sweep.sh [-c CKPT] [-d DEVICE] [-o OUT_ROOT]
  -c  Checkpoint path (.ckpt). Default:
      $CKPT_DEFAULT
  -d  Device override: auto|cpu|gpu (default: auto)
  -o  Output root (default: logs/eval/2020_conf_sweep)
USAGE
      exit 0 ;;
    \?) echo "Invalid option: -$OPTARG" >&2; exit 1 ;;
    :)  echo "Option -$OPTARG requires an argument." >&2; exit 1 ;;
  esac
done
shift $((OPTIND - 1))

if [ ! -f "$CKPT" ]; then
  echo "ERROR: Checkpoint not found: $CKPT" >&2
  exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"
cd "$PROJECT_ROOT"

echo ">>> Using checkpoint: $CKPT"
echo ">>> Output root: $OUT_ROOT"

accel_args=()
case "$DEVICE" in
  cpu) accel_args+=("trainer.accelerator=cpu" "trainer.devices=1") ;;
  gpu) accel_args+=("trainer.accelerator=gpu" "trainer.devices=1") ;;
  auto) ;; # let lightning auto-detect
  *) echo "Unknown DEVICE: $DEVICE (use auto|cpu|gpu)" >&2 ;;
esac

run_eval() {
  local label="$1"; shift
  local hydra_dir="$OUT_ROOT/${label}"
  echo "\n>>> Running eval: $label"
  echo "Output dir: $hydra_dir"
  export PBS_JOBNAME="$label"

  python src/eval.py \
    experiment=center/paper/directflow_5 \
    ckpt_path="$CKPT" \
    +eval_mode=val \
    data.val_years='["2020"]' \
    logger=csv \
    hydra.run.dir="$hydra_dir" \
    "${accel_args[@]}" \
    "$@"
}

# Ensure out root exists
mkdir -p "$OUT_ROOT"

# 1) clean (no noise)
run_eval "clean" \
  data.apply_noise_in_eval=false

# 2) additive std=1.0
run_eval "additive_1_0" \
  data.apply_noise_in_eval=true \
  +data.noise_config_eval={} \
  +data.noise_config_eval.uv_additive_std=1.0 \
  +data.noise_config_eval.angle_jitter_deg=0 \
  +data.noise_config_eval.magnitude_scale_std=0 \
  +data.noise_config_eval.pixel_drop_prob=0 \
  +data.noise_config_eval.block_drop_prob=0

# 3) angle deg=10
run_eval "angle_10" \
  data.apply_noise_in_eval=true \
  +data.noise_config_eval={} \
  +data.noise_config_eval.uv_additive_std=0 \
  +data.noise_config_eval.angle_jitter_deg=10 \
  +data.noise_config_eval.magnitude_scale_std=0 \
  +data.noise_config_eval.pixel_drop_prob=0 \
  +data.noise_config_eval.block_drop_prob=0

# 4) magscale std=0.1
run_eval "magscale_0_1" \
  data.apply_noise_in_eval=true \
  +data.noise_config_eval={} \
  +data.noise_config_eval.uv_additive_std=0 \
  +data.noise_config_eval.angle_jitter_deg=0 \
  +data.noise_config_eval.magnitude_scale_std=0.1 \
  +data.noise_config_eval.pixel_drop_prob=0 \
  +data.noise_config_eval.block_drop_prob=0

# 5) pixdrop prob=0.05
run_eval "pixdrop_0_05" \
  data.apply_noise_in_eval=true \
  +data.noise_config_eval={} \
  +data.noise_config_eval.uv_additive_std=0 \
  +data.noise_config_eval.angle_jitter_deg=0 \
  +data.noise_config_eval.magnitude_scale_std=0 \
  +data.noise_config_eval.pixel_drop_prob=0.05 \
  +data.noise_config_eval.block_drop_prob=0

# 6) cutout/block drop prob=0.5
run_eval "cutout_0_5" \
  data.apply_noise_in_eval=true \
  +data.noise_config_eval={} \
  +data.noise_config_eval.uv_additive_std=0 \
  +data.noise_config_eval.angle_jitter_deg=0 \
  +data.noise_config_eval.magnitude_scale_std=0 \
  +data.noise_config_eval.pixel_drop_prob=0 \
  +data.noise_config_eval.block_drop_prob=0.5

echo "\nAll 2020 runs finished under: $OUT_ROOT"

# Summarize CSV metrics
python scripts/summarize_eval_csv.py --root "$OUT_ROOT" --out "$OUT_ROOT"_summary.csv || true
echo "Summary (if any) at: ${OUT_ROOT}_summary.csv"
