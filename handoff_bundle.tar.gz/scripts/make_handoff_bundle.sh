#!/usr/bin/env bash
set -euo pipefail

# Create a sanitized archive for handoff, excluding personal logs, data, and cache artifacts.
# Usage: bash scripts/make_handoff_bundle.sh [output_tar_gz]

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="${1:-handoff_bundle.tar.gz}"

EXCLUDES=(
  ".git"
  ".gitignore" # optional; comment out if you want to keep ignore rules
  ".vscode"
  ".windsurf"
  "__pycache__"
  ".pytest_cache"
  ".ipynb_checkpoints"
  "data"
  "logs"
  "outputs"
  "output.log"
  "wandb"
  "*.ckpt"
  "*.npz"
  "*.npy"
)

cd "$ROOT"

tar_args=()
for pat in "${EXCLUDES[@]}"; do
  tar_args+=(--exclude="$pat")
done

echo "Creating archive: $OUT"
tar -czf "$OUT" "${tar_args[@]}" .
echo "Done. File created at: $ROOT/$OUT"
