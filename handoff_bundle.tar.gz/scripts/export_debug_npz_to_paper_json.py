#!/usr/bin/env python3
"""
Convert a debug .npz exported by BasicVSRLightning (enable_debug_logging)
into a paper-style JSON containing lr/gt/pred for each sample.

Usage:
  python scripts/export_debug_npz_to_paper_json.py \
    --npz debug_test_outputs_2020.npz \
    --out paper_results_directflow_5.json \
    --model-key model1

Notes:
  - Expects keys in the .npz: model_output, original_ground_truth, lq
  - Assumes center-frame outputs (T==1) for CenterFrameBasicVSR variants.
  - For vector data (U/V), exports magnitude for visualization.
  - Patch position defaults to centered 64x64 HR crop; can be changed with args.
"""

import argparse
import json
from pathlib import Path
from typing import Dict, Any

import numpy as np


def to_numpy(x):
    if isinstance(x, np.ndarray):
        return x
    return np.array(x)


def get_center_frame(arr: np.ndarray) -> np.ndarray:
    """Extract center frame if a time dimension exists.

    Accepts arrays with shapes like (B,T,C,H,W) or (B,C,H,W).
    Returns (B,C,H,W).
    """
    if arr.ndim == 5:  # (B, T, C, H, W)
        b, t, c, h, w = arr.shape
        mid = t // 2  # should be 0 for saved center-frame, but guard anyway
        return arr[:, mid, :, :, :]
    elif arr.ndim == 4:
        return arr
    else:
        raise ValueError(f"Unsupported array ndim={arr.ndim}, expected 4 or 5")


def magnitude_from_uv(x: np.ndarray) -> np.ndarray:
    """Compute magnitude from 2-channel UV or pass through for 1-channel inputs.

    Input shapes supported: (B,2,H,W) or (B,1,H,W) or (B,3,H,W) where channel0 is magnitude.
    """
    if x.shape[1] == 1:
        return x[:, 0]
    if x.shape[1] == 2:
        u = x[:, 0]
        v = x[:, 1]
        return np.sqrt(u * u + v * v)
    if x.shape[1] >= 3:
        # Assume channel 0 is magnitude when using magnitude_vector
        return x[:, 0]
    raise ValueError(f"Unsupported channel count: {x.shape}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--npz", required=True, help="Path to debug .npz file")
    parser.add_argument("--out", required=True, help="Output JSON path")
    parser.add_argument(
        "--model-key",
        default="model1",
        help="Key name to store prediction under images dict (default: model1)",
    )
    parser.add_argument("--hr-patch-size", type=int, default=64)
    parser.add_argument("--scale", type=int, default=4, help="Upscale factor between LR and HR")
    args = parser.parse_args()

    npz_path = Path(args.npz)
    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    data = np.load(npz_path)

    # Required keys
    if "model_output" not in data or "original_ground_truth" not in data or "lq" not in data:
        raise KeyError(
            "NPZ must contain keys: model_output, original_ground_truth, lq. "
            f"Found: {list(data.keys())}"
        )

    model_output = to_numpy(data["model_output"])  # possibly normalized
    original_gt = to_numpy(data["original_ground_truth"])  # (B, T?, 2, H, W)
    lq = to_numpy(data["lq"])  # (B, T, 2, h, w)

    # Extract center frame
    model_output_cf = get_center_frame(model_output)
    gt_cf = get_center_frame(original_gt)
    lq_cf = get_center_frame(lq)

    # Shapes
    b, c_hr, H, W = model_output_cf.shape
    _, c_gt, H_gt, W_gt = gt_cf.shape
    _, c_lr, h, w = lq_cf.shape

    # Sanity checks
    if (H, W) != (H_gt, W_gt):
        # Some versions save model_output as normalized comps possibly same size; keep going but warn
        pass
    if h * args.scale != H or w * args.scale != W:
        # Still proceed; paper figure code will normalize per-image
        pass

    # Create samples list
    samples = []
    # Default patch position: centered HR crop
    top = max(0, (H - args.hr_patch_size) // 2)
    left = max(0, (W - args.hr_patch_size) // 2)
    patch_pos = {"top": int(top), "left": int(left)}

    # Compute magnitude images
    lr_mag = magnitude_from_uv(lq_cf)  # (B,H_lr,W_lr)
    gt_mag = magnitude_from_uv(gt_cf)  # (B,H_hr,W_hr)
    pred_mag = magnitude_from_uv(model_output_cf)  # (B,H_hr,W_hr) if channel0 is mag

    for i in range(b):
        sample = {
            "sample_idx": int(i),
            "patch_position": patch_pos,
            "images": {
                "lr": lr_mag[i].astype(float).tolist(),
                "gt": gt_mag[i].astype(float).tolist(),
                args.model_key: pred_mag[i].astype(float).tolist(),
            },
        }
        samples.append(sample)

    result = {"samples": samples}

    with out_path.open("w", encoding="utf-8") as f:
        json.dump(result, f)

    print(f"Saved paper-style JSON with {len(samples)} samples to: {out_path}")


if __name__ == "__main__":
    main()

