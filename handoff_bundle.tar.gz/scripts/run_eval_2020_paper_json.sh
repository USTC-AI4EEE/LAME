#!/usr/bin/env bash
set -euo pipefail

# Validate the 2020 split with the specified checkpoint and export a paper-style JSON.
# Notes:
# - Uses validation (not test) to trigger debug NPZ saving in BasicVSRLightning.
# - Avoids overriding num_frames, accelerator, and logger.

# Required: path to the checkpoint (override via CKPT env or edit below)
CKPT="${CKPT:-logs/train/runs/<experiment>/<timestamp>/checkpoints/epoch_xxx.ckpt}"

# Experiment config to match the checkpoint's architecture
EXPERIMENT="center/paper/directflow_5"

# Output locations
OUT_DIR="logs/paper_results"
NPZ_PATH="$OUT_DIR/debug_val_outputs_2020.npz"
JSON_PATH="$OUT_DIR/paper_results_directflow_5_2020.json"

# Model key name to store predictions in JSON
MODEL_KEY="model1"

mkdir -p "$OUT_DIR"

# Run evaluation via the unified entrypoint, in validation mode
python src/eval.py \
  experiment="$EXPERIMENT" \
  ckpt_path="$CKPT" \
  data.val_years='["2020"]' \
  trainer.devices=1 \
  +model.enable_debug_logging=true \
  +model.debug_log_path="$NPZ_PATH" \
  +eval_mode=val

echo "Saved debug NPZ to: $NPZ_PATH"

# Convert the debug NPZ to paper-style JSON
python scripts/export_debug_npz_to_paper_json.py \
  --npz "$NPZ_PATH" \
  --out "$JSON_PATH" \
  --model-key "$MODEL_KEY"

echo "Saved paper JSON to: $JSON_PATH"
