#!/usr/bin/env python3
"""
Generate 2009 predictions (00/12 UTC, center-frame) using a saved checkpoint and
the exact Hydra-composed config saved under the run dir (.hydra/config.yaml).

Output
- Saves a normalized magnitude array shaped (728, 256, 256) to a .npy file.
- Also writes a small JSON with normalization info for easy de-normalization.

Notes
- Uses only LR inputs (ERA5_npy) and does not require loading HR targets.
- Selects indices with 5-frame windows centered on times at 00/12 UTC.
  The first 00 and last 12 are excluded by the 5-frame window → 730 - 2 = 728.

Example
  python scripts/predict_igav2_2009.py \
    --run-dir logs/train/runs/168852.Ghead_experiment_center_paper_directflow_5/2025-09-28_10-55-30 \
    --ckpt logs/train/runs/168852.Ghead_experiment_center_paper_directflow_5/2025-09-28_10-55-30/checkpoints/epoch_028-EMA.ckpt \
    --lr-root data/WindSRData/ERA5_npy \
    --year 2009 \
    --out logs/predictions/igav2_2009_directflow5_epoch028EMA_mag_norm.npy
"""

import argparse
import json
from pathlib import Path
from typing import List

import numpy as np
import torch
import torch.nn.functional as F
from omegaconf import OmegaConf
import hydra
import rootutils


def load_year_lr(root: Path, year: str) -> torch.Tensor:
    """Load LR ERA5 monthly .npy files and stack to (T, 2, H, W).

    Files are expected as: <root>/<year>/era5_<year>_<MM>.npy with shape (2, Nt, H, W).
    """
    year_dir = root / year
    files = sorted(year_dir.glob(f"era5_{year}_*.npy"))
    if not files:
        raise FileNotFoundError(f"No monthly .npy files found under {year_dir}")
    seqs: List[torch.Tensor] = []
    for f in files:
        arr = np.load(str(f))  # (2, Nt, H, W)
        if arr.ndim != 4 or arr.shape[0] != 2:
            raise ValueError(f"Unexpected LR array shape in {f}: {arr.shape}")
        # to (Nt, 2, H, W)
        tchw = np.transpose(arr, (1, 0, 2, 3))
        seqs.append(torch.from_numpy(tchw).float())
    full = torch.cat(seqs, dim=0)  # (T, 2, H, W)
    return full


@torch.inference_mode()
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", required=True, help="Run dir containing .hydra/config.yaml")
    parser.add_argument("--ckpt", required=True, help="Path to checkpoint .ckpt (EMA supported)")
    parser.add_argument("--lr-root", required=True, help="Root of LR ERA5_npy directory")
    parser.add_argument("--year", default="2009", help="Year to process (default: 2009)")
    parser.add_argument("--batch-size", type=int, default=8, help="Inference batch size")
    parser.add_argument("--device", type=str, default=None, help="Device override: cuda/cpu (default: auto)")
    parser.add_argument("--out", required=True, help="Output .npy path for normalized magnitude predictions")
    parser.add_argument("--meta-out", default=None, help="Optional JSON path to write normalization metadata")
    args = parser.parse_args()

    # Ensure project root and env
    rootutils.setup_root(__file__, indicator=".project-root", pythonpath=True)

    run_dir = Path(args.run_dir)
    cfg_path = run_dir / ".hydra" / "config.yaml"
    if not cfg_path.is_file():
        raise FileNotFoundError(f"config.yaml not found: {cfg_path}")
    ckpt_path = Path(args.ckpt)
    if not ckpt_path.is_file():
        raise FileNotFoundError(f"ckpt not found: {ckpt_path}")

    # Load saved Hydra config to reconstruct the network architecture
    cfg = OmegaConf.load(cfg_path)

    # Instantiate the inner network from saved config
    # cfg.model is BasicVSRLightning; cfg.model.model is the actual backbone
    net = hydra.utils.instantiate(cfg.model.model)

    # Device
    if args.device is None:
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    else:
        device = torch.device(args.device)

    # Reconstruct the Lightning module with the instantiated net and load weights
    from src.models.basicvsr_module import BasicVSRLightning
    lit_model: BasicVSRLightning = BasicVSRLightning.load_from_checkpoint(
        str(ckpt_path), model=net, map_location=device
    )
    lit_model.eval()
    lit_model.to(device)

    # Confirm expected IO
    in_ch = getattr(net, "in_channels", 3)
    out_ch = getattr(net, "out_channels", 3)
    if in_ch != 3 or out_ch != 3:
        raise RuntimeError(
            f"This script assumes (mag,u,v)→3ch outputs. Got in_ch={in_ch}, out_ch={out_ch}."
        )

    # Normalization settings from the lit module
    normalize_type = getattr(lit_model.hparams, "normalize_type", "vector")
    use_max = getattr(lit_model.hparams, "normalize_by_max", True)
    use_zscore = getattr(lit_model.hparams, "normalize_by_zscore", False)

    if normalize_type == "vector":
        max_in = lit_model.MAX_ABS_VALUE
        mean_in = lit_model.MEAN_VALUE
        std_in = lit_model.STD_VALUE
    else:  # magnitude mode
        max_in = lit_model.MAX_LOW_RES
        mean_in = lit_model.LOW_MEAN
        std_in = lit_model.LOW_STD

    # Load LR full-year sequence: (T, 2, 52, 52)
    lr_root = Path(args.lr_root)
    lr_full = load_year_lr(lr_root, args.year)
    T, _, H_lr, W_lr = lr_full.shape

    # Resize LR to (64,64) if needed
    if (H_lr, W_lr) != (64, 64):
        lr_full = F.interpolate(
            lr_full, size=(64, 64), mode="bilinear", align_corners=False
        )

    # Select center indices for 00/12 UTC with 5-frame window (t-2..t+2)
    # Raw cadence is 3-hourly (8 per day). 00UTC → t%8==0, 12UTC → t%8==4.
    centers: List[int] = []
    for t in range(2, T - 2):  # ensure window fits
        if (t % 8) in (0, 4):
            centers.append(t)
    # Ensure exactly 728 centers: drop the trailing last 12 UTC if present.
    if centers and (centers[-1] % 8 == 4):
        centers = centers[:-1]

    # Expect 728 centers for 2009
    print(f"Total LR timesteps: {T}; selected centers: {len(centers)}")

    # Batched inference
    bs = max(1, int(args.batch_size))
    out_list: List[torch.Tensor] = []  # each (b, 256, 256)

    for i in range(0, len(centers), bs):
        batch_idx = centers[i : i + bs]
        # Gather 5-frame windows (t-2..t+2), shape (b, 5, 2, 64, 64)
        windows = []
        for t in batch_idx:
            windows.append(lr_full[t - 2 : t + 3])
        lq_bt = torch.stack(windows, dim=0)  # (b, 5, 2, 64, 64)

        # Build model input: (mag, u, v)
        u = lq_bt[..., 0, :, :]
        v = lq_bt[..., 1, :, :]
        mag = torch.sqrt(u ** 2 + v ** 2)
        inp = torch.cat([mag.unsqueeze(2), lq_bt], dim=2)  # (b, 5, 3, 64, 64)

        # Apply normalization consistent with training
        if use_max:
            inp = inp / max_in
        if use_zscore and use_max:
            inp = (inp - mean_in) / std_in

        # Forward
        pred = lit_model.model(inp.to(device))  # (b, 1, 3, 256, 256)
        pred = pred[:, 0, 0, :, :].detach().cpu()  # take center frame, magnitude channel
        out_list.append(pred)

    # Stack to (N, 256, 256) and save as .npy (float32)
    out_arr = torch.cat(out_list, dim=0).numpy().astype(np.float32)

    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    np.save(str(out_path), out_arr)
    print(f"Saved predictions to: {out_path} with shape {out_arr.shape}")

    # Write metadata for de-normalization
    meta = {
        "normalize_type": normalize_type,
        "normalize_by_max": bool(use_max),
        "normalize_by_zscore": bool(use_zscore),
        "max_value": float(max_in),
        "mean": float(mean_in),
        "std": float(std_in),
        "channel": "magnitude",
        "shape": list(out_arr.shape),
        "grid": {
            "lon_min": 6.0,
            "lon_max": 18.75,
            "lat_min": 35.0,
            "lat_max": 47.75,
            "pixel_deg": 0.05,
            "H": 256,
            "W": 256,
        },
        "time": {
            "year": args.year,
            "cadence": "12h (00/12 UTC centers; 5-frame windows)",
            "count": len(centers),
        },
    }
    meta_out = Path(args.meta_out) if args.meta_out else out_path.with_suffix(".json")
    with open(meta_out, "w", encoding="utf-8") as f:
        json.dump(meta, f, ensure_ascii=False, indent=2)
    print(f"Saved metadata to: {meta_out}")


if __name__ == "__main__":
    main()
