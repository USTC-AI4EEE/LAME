#!/usr/bin/env python3
"""
Compare PSNR between a full-year 2009 prediction (magnitude, normalized)
and a reference CERRA magnitude array.

Features
- Reads prediction metadata to de-normalize to physical units.
- Handles channel squeeze for reference (T,1,H,W) -> (T,H,W).
- Aligns orientation by vertically flipping one side (auto or manual).
- Reports total and per-month PSNR (2009, 3-hourly → 8 steps/day).

Examples
  python scripts/compare_psnr_2009.py \
    --pred logs/predictions/igav2_2009_fullyear_directflow5_epoch028EMA_mag_norm.npy \
    --ref data/WindSRData/CERRA_2009_paperRange_mag.npy \
    --center-only --reduce mean_per_frame

  python scripts/compare_psnr_2009.py \
    --pred logs/predictions/igav2_2009_directflow5_epoch028EMA_mag_norm.npy \
    --ref data/WindSRData/CERRA_2009_paperRange_mag.npy \
    --utc0012 --reduce mean_per_frame

Notes
- For runs trained/evaluated via ERA5Dataset, HR GT was vertically flipped
  during loading to correct orientation. If your reference is the raw
  "paperRange" dump (unflipped), the prediction should be flipped vertically
  to align with it. Use --flip=auto (default) to select the best alignment.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Tuple, Dict, Any, Iterable

import numpy as np


def load_pred_and_denorm(pred_path: Path, meta_path: Path | None) -> Tuple[np.ndarray, Dict[str, Any]]:
    pred = np.load(str(pred_path))  # expected (T, H, W)
    if meta_path is None:
        meta_path = pred_path.with_suffix(".json")
    if not meta_path.is_file():
        raise FileNotFoundError(f"Meta JSON not found: {meta_path}")
    with open(meta_path, "r", encoding="utf-8") as f:
        meta = json.load(f)

    use_max = bool(meta.get("normalize_by_max", True))
    use_z = bool(meta.get("normalize_by_zscore", False))
    out_stats = meta.get("out_stats", {})
    # Support both metadata styles: {out_stats:{max,mean,std}} and flat {max_value,mean,std}
    max_out = float(out_stats.get("max", meta.get("max_value", 1.0)))
    mean_out = float(out_stats.get("mean", meta.get("mean", 0.0)))
    std_out = float(out_stats.get("std", meta.get("std", 1.0)))

    pred_dn = pred.astype(np.float64)
    if use_z and use_max:
        pred_dn = pred_dn * std_out + mean_out
    if use_max:
        pred_dn = pred_dn * max_out

    return pred_dn, meta


def load_ref(ref_path: Path) -> np.ndarray:
    ref = np.load(str(ref_path))
    if ref.ndim == 4 and ref.shape[1] == 1:
        ref = ref[:, 0]
    if ref.ndim != 3:
        raise ValueError(f"Unexpected reference shape {ref.shape}; expected (T,H,W) or (T,1,H,W)")
    return ref.astype(np.float64)


def psnr_global(a: np.ndarray, b: np.ndarray, data_range: float) -> float:
    """Compute a single PSNR from global MSE across all frames/pixels."""
    mse = np.mean((a - b) ** 2)
    return float("inf") if mse == 0 else 10.0 * np.log10((data_range ** 2) / mse)


def choose_orientation(pred: np.ndarray, ref: np.ndarray) -> Tuple[np.ndarray, str]:
    """Pick the best alignment between pred and ref by trying no-flip vs vertical-flip."""
    # Compare by MSE to avoid numeric issues
    T = min(len(pred), len(ref))
    p0 = pred[:T]
    r0 = ref[:T]
    mse_no = np.mean((p0 - r0) ** 2)
    p_flip = np.flip(p0, axis=-2)
    mse_flip = np.mean((p_flip - r0) ** 2)
    if mse_flip < mse_no:
        return p_flip, "pred_vflip"
    return p0, "none"


def monthly_indices_2009(total_steps: int) -> Tuple[Tuple[int, int], ...]:
    # 2009 is non-leap; 3-hour steps → 8 per day
    days = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
    spd = 8
    out = []
    idx = 0
    for d in days:
        n = d * spd
        if idx >= total_steps:
            break
        out.append((idx, min(idx + n, total_steps)))
        idx += n
    return tuple(out)


def main() -> None:
    ap = argparse.ArgumentParser(description="Compare PSNR between prediction and CERRA reference for 2009")
    ap.add_argument("--pred", required=True, help="Prediction .npy (normalized magnitude, shape (T,256,256))")
    ap.add_argument("--meta", default=None, help="Optional metadata JSON (default: pred with .json)")
    ap.add_argument("--ref", required=True, help="Reference CERRA magnitude .npy (T,256,256 or T,1,256,256)")
    ap.add_argument("--flip", default="auto", choices=["auto", "none", "pred", "ref"], help="Orientation alignment policy")
    ap.add_argument("--data-range", type=float, default=31.347172, help="PSNR data range (m/s)")
    ap.add_argument("--reduce", default="mean_per_frame", choices=["mean_per_frame", "global"], help="Aggregation: per-frame mean (torchmetrics-like) or single PSNR from global MSE")
    ap.add_argument("--batch-mean", type=int, default=0, help="Optional: compute PSNR per batch of given size, then mean across batches (simulates Lightning step aggregation)")
    ap.add_argument("--center-only", action="store_true", help="Evaluate only center-of-5 valid steps (exclude first/last 2)")
    ap.add_argument("--utc0012", action="store_true", help="Evaluate only 00/12 UTC center steps (requires center-of-5 indexing)")
    ap.add_argument("--out", default=None, help="Optional JSON to save results")
    # DDP slicing simulation (to reproduce rank-local validation without sync)
    ap.add_argument("--ddp-world-size", type=int, default=1, help="Simulate DDP world size for rank-local evaluation")
    ap.add_argument("--ddp-rank", type=int, default=0, help="Simulate DDP rank for rank-local evaluation")
    ap.add_argument("--num-frames", type=int, default=5, help="Sequence length used in validation (for center offset)")
    args = ap.parse_args()

    pred_path = Path(args.pred)
    meta_path = Path(args.meta) if args.meta else None
    ref_path = Path(args.ref)

    if not pred_path.is_file():
        raise FileNotFoundError(f"Prediction not found: {pred_path}")
    if not ref_path.is_file():
        raise FileNotFoundError(f"Reference not found: {ref_path}")

    pred_dn, meta = load_pred_and_denorm(pred_path, meta_path)
    ref = load_ref(ref_path)
    ref_full = ref  # keep full reference for mapped indexing

    # Record original lengths and then align by truncation
    T_pred_full = int(pred_dn.shape[0])
    T_ref_full = int(ref.shape[0])
    T = min(T_pred_full, T_ref_full)
    pred_dn = pred_dn[:T]
    ref = ref[:T]

    # Orientation alignment
    flip_applied = "none"
    if args.flip == "auto":
        pred_aligned, flip_applied = choose_orientation(pred_dn, ref)
        pred_dn = pred_aligned
    elif args.flip == "pred":
        pred_dn = np.flip(pred_dn, axis=-2)
        flip_applied = "pred_vflip"
    elif args.flip == "ref":
        ref = np.flip(ref, axis=-2)
        flip_applied = "ref_vflip"
    else:
        flip_applied = "none"

    # Build a mapping from pred index -> reference time index (for monthly filters)
    # Default: 1-to-1 mapping (full-year prediction)
    time_map = list(range(T))
    if T_pred_full != T_ref_full:
        # Likely center-only (e.g., 00/12 UTC) predictions; map to ref indices
        centers = [t for t in range(2, T_ref_full - 2) if (t % 8) in (0, 4)]
        if centers and (centers[-1] % 8 == 4):
            centers = centers[:-1]
        if len(centers) >= T:
            time_map = centers[:T]

    # Time indexing on the prediction index space, but filter via mapped ref indices
    idx_all = list(range(T))
    if args.center_only:
        idx_all = [i for i in idx_all if 2 <= time_map[i] <= (T_ref_full - 3)]
    if args.utc0012:
        idx_all = [i for i in idx_all if (time_map[i] % 8) in (0, 4)]

    # Simulate DDP rank-local subset (validation without sync_dist):
    # Dataset sample index i maps to center time t = i + center_offset, center_offset = num_frames//2
    # Therefore select pred indices whose mapped ref time satisfies (t - center_offset) % world_size == rank
    if args.ddp_world_size > 1:
        center_offset = args.num_frames // 2
        idx_all = [i for i in idx_all if ((time_map[i] - center_offset) % args.ddp_world_size) == args.ddp_rank]

    # PSNR overall (choose aggregation)
    total_psnr: float
    per_month: Iterable[Dict[str, Any]]

    if args.reduce == "mean_per_frame":
        # Use torchmetrics to average per-frame PSNR across selected frames
        import torch
        from torchmetrics.image import PeakSignalNoiseRatio

        H, W = ref.shape[1:]
        vals: list[float] = []
        if args.batch_mean and args.batch_mean > 0:
            # Batch-level PSNR then mean across batches (simulates Lightning step aggregation)
            bs = max(1, int(args.batch_mean))
            for s in range(0, len(idx_all), bs):
                sel = idx_all[s : s + bs]
                if not sel:
                    continue
                x = np.stack([np.ascontiguousarray(pred_dn[i]) for i in sel], axis=0)
                y = np.stack([np.ascontiguousarray(ref_full[time_map[i]]) for i in sel], axis=0)
                px = torch.from_numpy(x).view(x.shape[0], 1, H, W)
                py = torch.from_numpy(y).view(y.shape[0], 1, H, W)
                vals.append(float(PeakSignalNoiseRatio(data_range=args.data_range)(px, py).item()))
            total_psnr = float(sum(vals) / max(1, len(vals)))
        else:
            # Per-frame PSNR then mean
            for i in idx_all:
                x = torch.from_numpy(np.ascontiguousarray(pred_dn[i])).view(1, 1, H, W)
                y = torch.from_numpy(np.ascontiguousarray(ref_full[time_map[i]])).view(1, 1, H, W)
                vals.append(float(PeakSignalNoiseRatio(data_range=args.data_range)(x, y).item()))
            total_psnr = float(sum(vals) / max(1, len(vals)))

        months = monthly_indices_2009(T_ref_full)
        per_month = []
        for mi, (s, e) in enumerate(months, start=1):
            sel = [i for i in idx_all if (s <= time_map[i] < e)]
            if not sel:
                continue
            month_vals: list[float] = []
            if args.batch_mean and args.batch_mean > 0:
                bs = max(1, int(args.batch_mean))
                for j in range(0, len(sel), bs):
                    ssel = sel[j : j + bs]
                    xx = np.stack([np.ascontiguousarray(pred_dn[i]) for i in ssel], axis=0)
                    yy = np.stack([np.ascontiguousarray(ref_full[time_map[i]]) for i in ssel], axis=0)
                    px = torch.from_numpy(xx).view(xx.shape[0], 1, H, W)
                    py = torch.from_numpy(yy).view(yy.shape[0], 1, H, W)
                    month_vals.append(float(PeakSignalNoiseRatio(data_range=args.data_range)(px, py).item()))
            else:
                for i in sel:
                    x = torch.from_numpy(np.ascontiguousarray(pred_dn[i])).view(1, 1, H, W)
                    y = torch.from_numpy(np.ascontiguousarray(ref_full[time_map[i]])).view(1, 1, H, W)
                    month_vals.append(float(PeakSignalNoiseRatio(data_range=args.data_range)(x, y).item()))
            per_month.append({"month": f"2009-{mi:02d}", "psnr_db": float(sum(month_vals) / max(1, len(month_vals)))})
    else:
        # Single PSNR from global MSE across selected frames
        pred_sel = pred_dn[idx_all]
        ref_sel = ref_full[[time_map[i] for i in idx_all]]
        total_psnr = psnr_global(pred_sel, ref_sel, args.data_range)
        months = monthly_indices_2009(T_ref_full)
        per_month = []
        for mi, (s, e) in enumerate(months, start=1):
            sel = [i for i in idx_all if (s <= time_map[i] < e)]
            if not sel:
                continue
            per_month.append({
                "month": f"2009-{mi:02d}",
                "psnr_db": float(psnr_global(pred_dn[sel], ref_full[[time_map[i] for i in sel]], args.data_range)),
            })

    # Print nicely
    print(f"Orientation: {flip_applied}")
    print(f"Aggregation: {args.reduce}")
    if args.center_only:
        print("Indexing: center-only (2..T-3)")
    if args.utc0012:
        print("Filter: 00/12 UTC centers")
    print(f"Total PSNR: {total_psnr:.4f} dB")
    for item in per_month:
        print(f"{item['month']}: {item['psnr_db']:.4f} dB")

    # Optional save
    if args.out:
        outj = {
            "pred": str(pred_path),
            "ref": str(ref_path),
            "flip_applied": flip_applied,
            "data_range": float(args.data_range),
            "reduce": args.reduce,
            "center_only": bool(args.center_only),
            "utc0012": bool(args.utc0012),
            "total_psnr_db": float(total_psnr),
            "per_month": per_month,
        }
        out_path = Path(args.out)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(outj, f, ensure_ascii=False, indent=2)
        print(f"Saved results to: {out_path}")


if __name__ == "__main__":
    main()
