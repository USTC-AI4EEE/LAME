#!/usr/bin/env python3
import argparse
import csv
from pathlib import Path
from typing import Dict, List, Tuple


def extract_label_from_path(p: str) -> str:
    parts = Path(p).parts
    # try to find our sweep folder name then take the next segment as label
    for anchor in ("2020_conf_sweep", "robust"):
        if anchor in parts:
            idx = parts.index(anchor)
            if idx + 1 < len(parts):
                return parts[idx + 1]
    # fallback: parent directory
    try:
        # expect .../<label>/csv/version_x
        return parts[-3]
    except Exception:
        return Path(p).name


def load_summary(csv_path: Path) -> List[Dict[str, str]]:
    rows: List[Dict[str, str]] = []
    with csv_path.open("r", newline="") as f:
        reader = csv.DictReader(f)
        for r in reader:
            # normalize keys
            rows.append({k.strip(): v.strip() for k, v in r.items()})
    return rows


def aggregate_best(rows: List[Dict[str, str]]) -> Dict[str, Dict[str, str]]:
    best: Dict[str, Dict[str, str]] = {}
    for r in rows:
        path = r.get("path", "")
        label = extract_label_from_path(path)
        try:
            psnr = float(r.get("val_psnr_mag", "nan"))
            ssim = float(r.get("val_ssim_mag", "nan"))
        except ValueError:
            continue
        prev = best.get(label)
        if prev is None or float(prev.get("val_psnr_mag", "-inf")) < psnr:
            rr = dict(r)
            rr["label_extracted"] = label
            best[label] = rr
    return best


def render_markdown(best: Dict[str, Dict[str, str]]) -> str:
    # baseline
    clean = best.get("clean")
    clean_psnr = float(clean.get("val_psnr_mag", 0)) if clean else 0.0
    clean_ssim = float(clean.get("val_ssim_mag", 0)) if clean else 0.0

    # sort: clean first, then by delta psnr descending
    def sort_key(item: Tuple[str, Dict[str, str]]):
        lbl, r = item
        if lbl == "clean":
            return (0, 0.0)
        dpsnr = clean_psnr - float(r.get("val_psnr_mag", 0.0))
        return (1, -dpsnr)  # larger drop first

    lines: List[str] = []
    lines.append("# 2020 Noise Sweep Results (Markdown Summary)")
    lines.append("")
    lines.append(f"Baseline (clean): PSNR={clean_psnr:.6f}, SSIM={clean_ssim:.6f}")
    lines.append("")
    lines.append("| label | val_psnr_mag | ΔPSNR vs clean | val_ssim_mag | ΔSSIM vs clean | path |")
    lines.append("|---|---:|---:|---:|---:|---|")
    for label, r in sorted(best.items(), key=sort_key):
        psnr = float(r.get("val_psnr_mag", 0.0))
        ssim = float(r.get("val_ssim_mag", 0.0))
        dpsnr = psnr - clean_psnr
        dssim = ssim - clean_ssim
        lines.append(
            f"| {label} | {psnr:.6f} | {dpsnr:+.6f} | {ssim:.6f} | {dssim:+.6f} | {r.get('path','')} |"
        )
    lines.append("")
    return "\n".join(lines)


def main():
    ap = argparse.ArgumentParser(description="Make Markdown from eval CSV summary.")
    ap.add_argument("--csv", default="logs/eval/2020_conf_sweep_summary.csv")
    ap.add_argument("--out", default="logs/eval/2020_conf_sweep_summary.md")
    args = ap.parse_args()

    csv_path = Path(args.csv)
    if not csv_path.exists():
        raise SystemExit(f"CSV not found: {csv_path}")
    rows = load_summary(csv_path)
    best = aggregate_best(rows)
    md = render_markdown(best)
    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(md, encoding="utf-8")
    print(f"Markdown written to {out_path}")


if __name__ == "__main__":
    main()

