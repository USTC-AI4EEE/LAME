#!/usr/bin/env python3
"""
Generate full-year 2009 predictions aligned to CERRA time grid.

Differences vs predict_igav2_2009.py:
- Predicts every time step in the year (3-hourly grid), not only 00/12 UTC.
- Builds a 5-frame LR window per step with boundary clamping to cover edges.
- Outputs a (T, 256, 256) float32 array, where T matches CERRA timesteps.
- Saves a JSON with normalization info and basic geo/time metadata.

Example
  python scripts/predict_igav2_2009_fullyear.py \
    --run-dir logs/train/runs/168852.Ghead_experiment_center_paper_directflow_5/2025-09-28_10-55-30 \
    --ckpt logs/train/runs/168852.Ghead_experiment_center_paper_directflow_5/2025-09-28_10-55-30/checkpoints/epoch_028-EMA.ckpt \
    --lr-root data/WindSRData/ERA5_npy \
    --hr-root data/WindSRData/CERRA_npy \
    --year 2009 \
    --out logs/predictions/igav2_2009_fullyear_directflow5_epoch028EMA_mag_norm.npy
"""

import argparse
import json
from pathlib import Path
from typing import List

import numpy as np
import torch
import torch.nn.functional as F
from omegaconf import OmegaConf
import hydra
import rootutils


def load_year_lr(root: Path, year: str) -> torch.Tensor:
    """Load LR ERA5 monthly .npy files and stack to (T, 2, H, W).

    Files are expected as: <root>/<year>/era5_<year>_<MM>.npy with shape (2, Nt, H, W).
    """
    year_dir = root / year
    files = sorted(year_dir.glob(f"era5_{year}_*.npy"))
    if not files:
        raise FileNotFoundError(f"No monthly .npy files found under {year_dir}")
    seqs: List[torch.Tensor] = []
    for f in files:
        arr = np.load(str(f))  # (2, Nt, H, W)
        if arr.ndim != 4 or arr.shape[0] != 2:
            raise ValueError(f"Unexpected LR array shape in {f}: {arr.shape}")
        tchw = np.transpose(arr, (1, 0, 2, 3))  # (Nt, 2, H, W)
        seqs.append(torch.from_numpy(tchw).float())
    full = torch.cat(seqs, dim=0)  # (T, 2, H, W)
    return full


def load_year_hr_count(root: Path, year: str) -> int:
    """Return total time steps T for CERRA HR by summing monthly Nt."""
    year_dir = root / year
    files = sorted(year_dir.glob(f"era5_{year}_*.npy"))
    if not files:
        raise FileNotFoundError(f"No monthly .npy files found under {year_dir}")
    total = 0
    for f in files:
        arr = np.load(str(f), mmap_mode="r")  # (2, Nt, H, W)
        if arr.ndim != 4 or arr.shape[0] != 2:
            raise ValueError(f"Unexpected HR array shape in {f}: {arr.shape}")
        total += arr.shape[1]
    return int(total)


@torch.inference_mode()
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", required=True, help="Run dir containing .hydra/config.yaml")
    parser.add_argument("--ckpt", required=True, help="Path to checkpoint .ckpt (EMA supported)")
    parser.add_argument("--lr-root", required=True, help="Root of LR ERA5_npy directory")
    parser.add_argument("--hr-root", default="data/WindSRData/CERRA_npy", help="Root of HR CERRA_npy directory (for time alignment)")
    parser.add_argument("--year", default="2009", help="Year to process (default: 2009)")
    parser.add_argument("--batch-size", type=int, default=8, help="Inference batch size")
    parser.add_argument("--device", type=str, default=None, help="Device override: cuda/cpu (default: auto)")
    parser.add_argument("--out", required=True, help="Output .npy path for normalized magnitude predictions (T,256,256)")
    parser.add_argument("--meta-out", default=None, help="Optional JSON path to write normalization metadata")
    args = parser.parse_args()

    # Ensure project root and env
    rootutils.setup_root(__file__, indicator=".project-root", pythonpath=True)

    run_dir = Path(args.run_dir)
    cfg_path = run_dir / ".hydra" / "config.yaml"
    if not cfg_path.is_file():
        raise FileNotFoundError(f"config.yaml not found: {cfg_path}")
    ckpt_path = Path(args.ckpt)
    if not ckpt_path.is_file():
        raise FileNotFoundError(f"ckpt not found: {ckpt_path}")

    # Load saved Hydra config to reconstruct the network architecture
    cfg = OmegaConf.load(cfg_path)

    # Instantiate the inner network from saved config
    net = hydra.utils.instantiate(cfg.model.model)

    # Device
    if args.device is None:
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    else:
        device = torch.device(args.device)

    # Reconstruct the Lightning module and load weights
    from src.models.basicvsr_module import BasicVSRLightning
    lit_model: BasicVSRLightning = BasicVSRLightning.load_from_checkpoint(
        str(ckpt_path), model=net, map_location=device
    )
    lit_model.eval()
    lit_model.to(device)

    in_ch = getattr(net, "in_channels", 3)
    out_ch = getattr(net, "out_channels", 3)
    if in_ch != 3 or out_ch != 3:
        raise RuntimeError(
            f"This script assumes (mag,u,v)→3ch outputs. Got in_ch={in_ch}, out_ch={out_ch}."
        )

    # Normalization settings from the lit module
    normalize_type = getattr(lit_model.hparams, "normalize_type", "vector")
    use_max = getattr(lit_model.hparams, "normalize_by_max", True)
    use_zscore = getattr(lit_model.hparams, "normalize_by_zscore", False)

    if normalize_type == "vector":
        max_in = lit_model.MAX_ABS_VALUE
        mean_in = lit_model.MEAN_VALUE
        std_in = lit_model.STD_VALUE
        max_out = lit_model.MAX_ABS_VALUE
        mean_out = lit_model.MEAN_VALUE
        std_out = lit_model.STD_VALUE
    else:  # magnitude mode
        max_in = lit_model.MAX_LOW_RES
        mean_in = lit_model.LOW_MEAN
        std_in = lit_model.LOW_STD
        max_out = lit_model.MAX_HIGH_RES
        mean_out = lit_model.HIGH_MEAN
        std_out = lit_model.HIGH_STD

    # Load LR full-year sequence and HR step count
    lr_root = Path(args.lr_root)
    hr_root = Path(args.hr_root)
    lr_full = load_year_lr(lr_root, args.year)  # (T_lr, 2, H_lr, W_lr)
    T_lr, _, H_lr, W_lr = lr_full.shape
    T_hr = load_year_hr_count(hr_root, args.year)

    # Resize LR to (64,64) if needed
    if (H_lr, W_lr) != (64, 64):
        lr_full = F.interpolate(lr_full, size=(64, 64), mode="bilinear", align_corners=False)

    # Build list of all time centers aligned to HR grid: 0..T_hr-1
    # For indices outside LR range in a 5-frame window, clamp to edges (padding by replication)
    def clamp(i: int, lo: int, hi: int) -> int:
        return max(lo, min(hi, i))

    all_centers = list(range(T_hr))

    bs = max(1, int(args.batch_size))
    preds: List[torch.Tensor] = []  # each (b, 256, 256)

    for i in range(0, len(all_centers), bs):
        batch_idx = all_centers[i : i + bs]
        windows = []
        for t in batch_idx:
            idxs = [
                clamp(t - 2, 0, T_lr - 1),
                clamp(t - 1, 0, T_lr - 1),
                clamp(t, 0, T_lr - 1),
                clamp(t + 1, 0, T_lr - 1),
                clamp(t + 2, 0, T_lr - 1),
            ]
            windows.append(lr_full[idxs])  # (5, 2, 64, 64)
        lq_bt = torch.stack(windows, dim=0)  # (b, 5, 2, 64, 64)

        # Build (mag, u, v)
        u = lq_bt[..., 0, :, :]
        v = lq_bt[..., 1, :, :]
        mag = torch.sqrt(u ** 2 + v ** 2)
        inp = torch.cat([mag.unsqueeze(2), lq_bt], dim=2)  # (b, 5, 3, 64, 64)

        # Normalize
        if use_max:
            inp = inp / max_in
        if use_zscore and use_max:
            inp = (inp - mean_in) / std_in

        # Forward
        pred = lit_model.model(inp.to(device))  # (b, 1, 3, 256, 256)
        pred = pred[:, 0, 0, :, :].detach().cpu()  # (b, 256, 256) magnitude channel of center frame
        preds.append(pred)

    out_arr = torch.cat(preds, dim=0).numpy().astype(np.float32)  # (T_hr, 256, 256)

    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    np.save(str(out_path), out_arr)
    print(f"Saved full-year predictions to: {out_path} with shape {out_arr.shape}")

    # Write metadata
    meta = {
        "normalize_type": normalize_type,
        "normalize_by_max": bool(use_max),
        "normalize_by_zscore": bool(use_zscore),
        "in_stats": {"max": float(max_in), "mean": float(mean_in), "std": float(std_in)},
        "out_stats": {"max": float(max_out), "mean": float(mean_out), "std": float(std_out)},
        "channel": "magnitude",
        "shape": list(out_arr.shape),
        "grid": {
            "lon_min": 6.0,
            "lon_max": 18.75,
            "lat_min": 35.0,
            "lat_max": 47.75,
            "pixel_deg": 0.05,
            "H": 256,
            "W": 256,
        },
        "time": {
            "year": args.year,
            "cadence": "3h (full-year, clamped windows)",
            "count": int(out_arr.shape[0]),
            "aligned_to": "CERRA",
        },
        "sources": {
            "run_dir": str(run_dir),
            "ckpt": str(ckpt_path),
            "lr_root": str(lr_root),
            "hr_root": str(hr_root),
        },
    }
    meta_out = Path(args.meta_out) if args.meta_out else out_path.with_suffix(".json")
    with open(meta_out, "w", encoding="utf-8") as f:
        json.dump(meta, f, ensure_ascii=False, indent=2)
    print(f"Saved metadata to: {meta_out}")


if __name__ == "__main__":
    main()

