#!/usr/bin/env python
"""Compare wind speed (ERA5 vs CERRA) and highlight CERRA's higher resolution.

The script loads one temporal frame (index selectable) from the ERA5/CERRA
wind dataset, derives wind‐speed magnitude from the (u,v) components, and
creates a comparison figure containing

1. Full–resolution ERA5 wind speed.
2. Full–resolution CERRA wind speed.
3. Zoomed-in ERA5 (bottom-right quarter).
4. Zoomed-in CERRA (bottom-right quarter).

Key requirements addressed:
- *No interpolation* is applied when displaying the arrays.  ``matplotlib``
  uses ``interpolation='none'`` explicitly to disable smoothing.
- A zoomed view (bottom-right 1/4) is shown to emphasise resolution
differences.

Usage::

    python scripts/compare_wind_speed.py \
        --config configs/data/era5_cerra.yaml \
        --year 2010 --index 0 --output wind_speed_comparison.png

If ``--lr-dir`` / ``--hr-dir`` are given they override the paths in the YAML
file.
"""
from __future__ import annotations

import sys
from pathlib import Path
# Ensure project root is on PYTHONPATH so that 'src' package is importable when running as a script
project_root = Path(__file__).resolve().parents[1]
if str(project_root) not in sys.path:
    sys.path.append(str(project_root))

import argparse
import math
import os
from pathlib import Path
from typing import Any, Dict, List

import matplotlib.pyplot as plt
import numpy as np
import torch
import yaml

# Local import: ERA5Dataset lives inside project package
from src.data.components.era5_dataset import ERA5Dataset


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="ERA5–CERRA wind-speed comparison")
    parser.add_argument(
        "--config",
        type=str,
        default="configs/data/era5_cerra.yaml",
        help="Path to YAML config containing dataset paths.",
    )
    parser.add_argument(
        "--year",
        type=str,
        default="2010",
        help="Which year to sample. Must exist in the data directories.",
    )
    parser.add_argument(
        "--index",
        type=int,
        default=0,
        help="Sample index (temporal frame) to visualise.",
    )
    parser.add_argument(
        "--lr-dir",
        type=str,
        default=None,
        help="Optional: override low-resolution (ERA5) directory.",
    )
    parser.add_argument(
        "--hr-dir",
        type=str,
        default=None,
        help="Optional: override high-resolution (CERRA) directory.",
    )
    parser.add_argument(
        "--output",
        type=str,
        default="wind_speed_comparison.svg",
        help="Output image filename (SVG).",
    )
    return parser.parse_args()


def load_config(path: str | os.PathLike) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        cfg: Dict[str, Any] = yaml.safe_load(f)
    return cfg


def maybe_override(cfg_dataset: Dict[str, Any], lr_dir: str | None, hr_dir: str | None) -> None:
    if lr_dir is not None:
        cfg_dataset["lr_data_dir"] = lr_dir
    if hr_dir is not None:
        cfg_dataset["hr_data_dir"] = hr_dir


def pick_sample(dataset: ERA5Dataset, idx: int) -> tuple[np.ndarray, np.ndarray]:
    sample = dataset[idx]
    # sample['lq'] / sample['gt']: (num_frames, 2, H, W)
    # We only use first frame.
    lq_uv = sample["lq"][0]  # (2,H,W)
    gt_uv = sample["gt"][0]  # (2,hH,hW)

    # Magnitude = sqrt(u^2 + v^2)
    lq_mag = torch.sqrt(lq_uv[0] ** 2 + lq_uv[1] ** 2).cpu().numpy()
    gt_mag = torch.sqrt(gt_uv[0] ** 2 + gt_uv[1] ** 2).cpu().numpy()
    return lq_mag, gt_mag


def create_figure(lq_mag: np.ndarray, gt_mag: np.ndarray, output: str) -> None:
    """Generate a 2×2 comparison figure and save it."""

    vmin = min(lq_mag.min(), gt_mag.min())
    vmax = max(lq_mag.max(), gt_mag.max())

    # Narrower figure to minimize horizontal gap and taller to allow vertical breathing space
    fig, axes = plt.subplots(2, 2, figsize=(8, 8))

    # Helper: choose the most dynamic patch (highest variance) using a coarse grid.
    def dynamic_region(arr: np.ndarray, grid: int = 4) -> tuple[np.ndarray, tuple[int, int, int, int]]:
        """Return patch with highest variance from an NxN grid and its bounds.

        Returns
        -------
        patch : np.ndarray
            The selected sub-array.
        bounds : tuple[int, int, int, int]
            (row_start, col_start, height, width)
        """
        h, w = arr.shape
        ph = h // grid
        pw = w // grid
        best_var = -np.inf
        best_bounds = (0, 0, ph, pw)
        for i in range(grid):
            for j in range(grid):
                r0 = i * ph
                c0 = j * pw
                patch = arr[r0 : r0 + ph, c0 : c0 + pw]
                v = patch.var()
                if v > best_var:
                    best_var = v
                    best_bounds = (r0, c0, ph, pw)
        r0, c0, ph, pw = best_bounds
        return arr[r0 : r0 + ph, c0 : c0 + pw], best_bounds

    # Top row: full views
    img0 = axes[0, 0].imshow(lq_mag, origin="lower", interpolation="none", vmin=vmin, vmax=vmax)
    axes[0, 0].set_title("ERA5 Wind Speed", fontsize=10)
    axes[0, 0].axis("off")

    img1 = axes[0, 1].imshow(gt_mag, origin="lower", interpolation="none", vmin=vmin, vmax=vmax)
    axes[0, 1].set_title("CERRA Wind Speed", fontsize=10)
    axes[0, 1].axis("off")

    # Zoomed patches – automatically find most dynamic area (highest variance)
    lq_zoom, (lq_r0, lq_c0, lq_ph, lq_pw) = dynamic_region(lq_mag)
    gt_zoom, (gt_r0, gt_c0, gt_ph, gt_pw) = dynamic_region(gt_mag)

    axes[1, 0].imshow(lq_zoom, origin="lower", interpolation="none", vmin=vmin, vmax=vmax)
    # No title for zoomed image
    axes[1, 0].axis("off")

    axes[1, 1].imshow(gt_zoom, origin="lower", interpolation="none", vmin=vmin, vmax=vmax)
    # No title for zoomed image
    axes[1, 1].axis("off")

    # Draw rectangles on main images indicating zoom region
    from matplotlib.patches import Rectangle, ConnectionPatch

    # Draw rectangle exactly around selected patch
    def add_rect(ax, r0: int, c0: int, ph: int, pw: int):
        rect = Rectangle(
            (c0 - 0.5, r0 - 0.5),  # x,y starting point in data coords
            pw,
            ph,
            linewidth=0.5,
            edgecolor="red",
            facecolor="none",
        )
        ax.add_patch(rect)

    # Draw rectangles on source images
    add_rect(axes[0, 0], lq_r0, lq_c0, lq_ph, lq_pw)
    add_rect(axes[0, 1], gt_r0, gt_c0, gt_ph, gt_pw)

    # Draw rectangle around zoom images (full extent)
    add_rect(axes[1, 0], 0, 0, lq_ph, lq_pw)
    add_rect(axes[1, 1], 0, 0, gt_ph, gt_pw)

    # Connect top-left and bottom-right corners using ConnectionPatch to create "spotlight" effect
    def connect(ax_src, ax_zoom, r0, c0, ph, pw):
        # top-left corner
        con1 = ConnectionPatch(
            xyA=(c0 - 0.5, r0 - 0.5), coordsA=ax_src.transData,
            xyB=(-0.5, -0.5), coordsB=ax_zoom.transData,
            color="red", linewidth=0.5
        )
        # bottom-right corner
        con2 = ConnectionPatch(
            xyA=(c0 + pw - 0.5, r0 + ph - 0.5), coordsA=ax_src.transData,
            xyB=(pw - 0.5, ph - 0.5), coordsB=ax_zoom.transData,
            color="red", linewidth=0.5
        )
        fig.add_artist(con1)
        fig.add_artist(con2)

    connect(axes[0, 0], axes[1, 0], lq_r0, lq_c0, lq_ph, lq_pw)
    connect(axes[0, 1], axes[1, 1], gt_r0, gt_c0, gt_ph, gt_pw)

    # Adjust spacing for uniform layout
    # Adjust spacing: minimal horizontal gap, generous vertical gap
    fig.subplots_adjust(wspace=0.25, hspace=0.25)

    out_path = Path(output)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    # Save as vector (SVG) for publication-quality graphics only
    if out_path.suffix.lower() != ".svg":
        out_path = out_path.with_suffix(".svg")
    fig.savefig(out_path, format="svg")
    print(f"Saved comparison image to {out_path.resolve()}")



def main() -> None:
    args = parse_args()

    cfg = load_config(args.config)
    dataset_cfg: Dict[str, Any] = cfg["dataset_config"]

    # Override paths if requested
    maybe_override(dataset_cfg, args.lr_dir, args.hr_dir)

    # Build dataset for a single year to avoid loading excessive memory.
    selected_years: List[str] = [args.year]

    # Ensure we don't pass duplicate kwargs
    # If user wants raw values, override in config dict
    dataset_cfg.setdefault("normalize", False)

    dataset = ERA5Dataset(
        selected_years=selected_years,
        **dataset_cfg,
    )

    if args.index >= len(dataset):
        raise IndexError(f"index {args.index} is out of range (dataset size={len(dataset)})")

    lq_mag, gt_mag = pick_sample(dataset, args.index)
    create_figure(lq_mag, gt_mag, args.output)


if __name__ == "__main__":
    main()
