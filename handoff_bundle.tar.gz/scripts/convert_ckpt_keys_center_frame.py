#!/usr/bin/env python3
"""
Convert checkpoint state_dict keys from older CenterFrame BasicVSR naming to current naming.

Specifically maps:
  model.first_frame_forward.main.* -> model.forward_resblocks.main.*
  model.last_frame_backward.main.* -> model.backward_resblocks.main.*

Usage:
  python scripts/convert_ckpt_keys_center_frame.py --in <src.ckpt> --out <dst.ckpt>
"""

import argparse
from pathlib import Path
import torch


def convert_keys(state_dict: dict) -> dict:
    out = {}
    for k, v in state_dict.items():
        nk = k
        if k.startswith("model.first_frame_forward.main"):
            nk = k.replace("model.first_frame_forward.main", "model.forward_resblocks.main", 1)
        elif k.startswith("model.last_frame_backward.main"):
            nk = k.replace("model.last_frame_backward.main", "model.backward_resblocks.main", 1)
        out[nk] = v
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", required=True, help="Source .ckpt path")
    ap.add_argument("--out", required=True, help="Destination .ckpt path")
    args = ap.parse_args()

    src = Path(args.__dict__["in"])  # avoid keyword conflict
    dst = Path(args.out)

    if not src.is_file():
        raise FileNotFoundError(src)
    ckpt = torch.load(src, map_location="cpu")
    sd = ckpt.get("state_dict", ckpt)
    new_sd = convert_keys(sd)
    if "state_dict" in ckpt:
        ckpt["state_dict"] = new_sd
    else:
        ckpt = new_sd
    dst.parent.mkdir(parents=True, exist_ok=True)
    torch.save(ckpt, dst)
    print(f"Saved converted checkpoint to: {dst}")


if __name__ == "__main__":
    main()

