#!/usr/bin/env python3
"""
Compare a checkpoint's state_dict keys with the current model's keys and
report unexpected/missing parameters plus basic tensor statistics.

Examples:
  python scripts/check_ckpt_keys.py \
    --ckpt logs/train/runs/153913.Ghead_experiment_center_paper_directflow_5/2025-06-03_14-58-41/checkpoints/epoch_038.ckpt \
    --experiment center/paper/directflow_5 \
    --overrides 'trainer=gpu' 'data.val_years=["2020"]'

Notes:
  - Uses configs/eval.yaml to instantiate the model via Hydra.
  - Defaults to experiment=center/paper/directflow_5 if not provided.
"""

import argparse
from collections import Counter
from pathlib import Path
from typing import List

import torch
import hydra
from hydra import compose, initialize_config_dir
import rootutils


def prefix(key: str, depth: int = 2) -> str:
    parts = key.split(".")
    return ".".join(parts[:depth]) if parts else key


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--ckpt", required=True, help="Path to checkpoint .ckpt file")
    parser.add_argument(
        "--experiment",
        default="center/paper/directflow_5",
        help="Hydra experiment override, e.g. center/paper/directflow_5",
    )
    parser.add_argument(
        "--overrides",
        nargs="*",
        default=["trainer=gpu", 'data.val_years=["2020"]'],
        help="Additional hydra overrides (space separated strings)",
    )
    parser.add_argument("--topn", type=int, default=20, help="Print first N keys")
    args = parser.parse_args()

    # Ensure project root is on PYTHONPATH like entry scripts
    rootutils.setup_root(__file__, indicator=".project-root", pythonpath=True)

    ckpt_path = Path(args.ckpt)
    if not ckpt_path.is_file():
        raise FileNotFoundError(f"Checkpoint not found: {ckpt_path}")

    # Resolve configs dir relative to this script
    configs_dir = (Path(__file__).resolve().parent.parent / "configs").as_posix()
    # Use absolute config dir since Hydra initialize() requires relative paths
    with initialize_config_dir(config_dir=configs_dir, version_base="1.3"):
        overrides: List[str] = [f"experiment={args.experiment}"] + list(args.overrides)
        cfg = compose(config_name="eval.yaml", overrides=overrides)
        model = hydra.utils.instantiate(cfg.model)

    model_keys = set(model.state_dict().keys())

    ckpt = torch.load(ckpt_path, map_location="cpu")
    state_dict = ckpt.get("state_dict", ckpt)
    ckpt_keys = set(state_dict.keys())

    unexpected = sorted(list(ckpt_keys - model_keys))
    missing = sorted(list(model_keys - ckpt_keys))

    print(f"Checkpoint: {ckpt_path}")
    print(f"Model target: {cfg.model._target_}")
    print(f"Total model params: {len(model_keys)} | ckpt tensors: {len(ckpt_keys)}")
    print(f"Unexpected (in ckpt not in model): {len(unexpected)}")
    if unexpected:
        print("  First keys:")
        for k in unexpected[: args.topn]:
            print("   ", k)
    print(f"Missing (in model not in ckpt): {len(missing)}")
    if missing:
        print("  First keys:")
        for k in missing[: args.topn]:
            print("   ", k)

    # Group unexpected by 3-level prefix to quickly spot branches
    if unexpected:
        cnt = Counter(prefix(k, 3) for k in unexpected)
        print("\nUnexpected key group (by 3-level prefix):")
        for pfx, c in cnt.most_common(10):
            print(f"  {pfx}: {c}")

    # Print stats for first few unexpected tensors
    print("\nTensor stats for first unexpected keys:")
    printed = 0
    for name in unexpected:
        t = state_dict.get(name)
        if isinstance(t, torch.Tensor):
            t_cpu = t.detach().cpu()
            print(
                f"- {name}: shape={tuple(t_cpu.shape)}, dtype={t_cpu.dtype}, "
                f"min={t_cpu.min().item():.4f}, max={t_cpu.max().item():.4f}, "
                f"mean={t_cpu.mean().item():.4f}, std={t_cpu.std().item():.4f}, "
                f"nnz={(t_cpu!=0).sum().item()}"
            )
            printed += 1
        if printed >= min(args.topn, 10):
            break

    print("\nDone.")


if __name__ == "__main__":
    main()
