#!/usr/bin/env python3
import argparse
import csv
import os
from pathlib import Path
from typing import Dict, List, Tuple


def find_metrics_csv(root: Path) -> List[Path]:
    files: List[Path] = []
    for p in root.rglob("metrics.csv"):
        # only keep csv under our robust eval tree
        files.append(p)
    return sorted(files)


def parse_last_row(csv_path: Path) -> Tuple[List[str], List[str]]:
    with csv_path.open("r", newline="") as f:
        reader = csv.reader(f)
        rows = list(reader)
        if not rows:
            return [], []
        header = rows[0]
        # last non-empty row
        for row in reversed(rows[1:]):
            if any(cell.strip() for cell in row):
                return header, row
        return header, []


def extract_metrics(header: List[str], row: List[str]) -> Dict[str, float]:
    idx: Dict[str, int] = {k: i for i, k in enumerate(header)}
    keys = [
        "val_psnr_mag", "val_ssim_mag", "val_mae_mag", "val_mse_mag",
        "val_psnr_mag2009", "val_ssim_mag2009", "val_mae_mag2009", "val_mse_mag2009",
        "val_psnr_mag2020", "val_ssim_mag2020", "val_mae_mag2020", "val_mse_mag2020",
    ]
    out: Dict[str, float] = {}
    for k in keys:
        if k in idx and idx[k] < len(row):
            try:
                out[k] = float(row[idx[k]])
            except ValueError:
                pass
    return out


def main():
    ap = argparse.ArgumentParser(description="Summarize robust eval CSV metrics.")
    ap.add_argument("--root", type=str, default="logs/eval/robust", help="Root dir of eval runs")
    ap.add_argument("--out", type=str, default="logs/eval/robust_summary.csv", help="Output CSV path")
    args = ap.parse_args()

    root = Path(args.root)
    if not root.exists():
        print(f"Root not found: {root}")
        return

    rows: List[Dict[str, str]] = []
    csv_files = find_metrics_csv(root)
    if not csv_files:
        print(f"No metrics.csv found under {root}")
        return

    for csv_path in csv_files:
        header, last = parse_last_row(csv_path)
        if not header or not last:
            continue
        metrics = extract_metrics(header, last)
        # label from path: .../<label>/.../metrics.csv
        parts = list(csv_path.parts)
        try:
            label_idx = parts.index("robust") + 1
            label = parts[label_idx]
        except ValueError:
            # fallback: take parent name
            label = csv_path.parent.name

        row: Dict[str, str] = {"label": label, "path": str(csv_path.parent)}
        for k, v in metrics.items():
            row[k] = f"{v:.6f}"
        rows.append(row)

    # sort by label
    rows.sort(key=lambda r: r.get("label", ""))

    # collect all keys
    keys = ["label", "path"]
    for r in rows:
        for k in r.keys():
            if k not in keys:
                keys.append(k)

    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with out_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=keys)
        writer.writeheader()
        for r in rows:
            writer.writerow(r)

    print(f"Summary written to {out_path}")
    print(f"Total runs summarized: {len(rows)}")


if __name__ == "__main__":
    main()

