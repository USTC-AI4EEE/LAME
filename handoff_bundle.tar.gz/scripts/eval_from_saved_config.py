#!/usr/bin/env python3
"""
Evaluate a checkpoint using the exact Hydra-composed config saved under a run dir
(.hydra/config.yaml), with strict=True loading and optional batch limiting.

Example:
  python scripts/eval_from_saved_config.py \
    --run-dir logs/gdata2/train/runs/153913.Ghead_experiment_center_paper_directflow_5/2025-06-03_14-58-41 \
    --ckpt logs/gdata2/train/runs/153913.Ghead_experiment_center_paper_directflow_5/2025-06-03_14-58-41/checkpoints/epoch_038.ckpt \
    --limit-test-batches 2 --devices 1 --accelerator gpu
"""

import argparse
from pathlib import Path
import os

import hydra
from omegaconf import OmegaConf
import rootutils
import lightning as L
from lightning.pytorch.loggers import CSVLogger


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", required=True, help="Path to run dir with .hydra/config.yaml")
    parser.add_argument("--ckpt", required=True, help="Path to checkpoint .ckpt")
    parser.add_argument("--limit-test-batches", type=float, default=None, help="Limit test batches (float/int)")
    parser.add_argument("--accelerator", type=str, default="gpu", help="Trainer accelerator (gpu/cpu)")
    parser.add_argument("--devices", type=int, default=1, help="Number of devices (set 1 for quick run)")
    parser.add_argument("--out", type=str, default=None, help="Output dir for logs (default: <run-dir>/eval_strict)")
    args = parser.parse_args()

    # Ensure project root on sys.path and env
    rootutils.setup_root(__file__, indicator=".project-root", pythonpath=True)
    # Now that PYTHONPATH is set, import utils
    from src.utils.instantiators import instantiate_callbacks  # noqa: WPS433

    run_dir = Path(args.run_dir)
    cfg_path = run_dir / ".hydra" / "config.yaml"
    if not cfg_path.is_file():
        raise FileNotFoundError(f"config.yaml not found under {cfg_path}")
    ckpt = Path(args.ckpt)
    if not ckpt.is_file():
        raise FileNotFoundError(f"ckpt not found: {ckpt}")

    cfg = OmegaConf.load(cfg_path)
    # Sanity adjustments for evaluation
    cfg.task_name = "eval"
    # Avoid wandb during quick/local eval
    if "logger" in cfg:
        cfg.logger = None
    # datamodule tweaks
    if "data" in cfg and isinstance(cfg.data, dict):
        cfg.data["num_workers"] = 0

    # Instantiate objects from saved config
    datamodule = hydra.utils.instantiate(cfg.data)
    model = hydra.utils.instantiate(cfg.model)
    # Try to instantiate callbacks; if Hydra-specific resolvers are present
    # (e.g., ${hydra:...}) outside a Hydra app context, fall back to none.
    try:
        callbacks = instantiate_callbacks(cfg.get("callbacks"))
    except Exception:
        callbacks = []

    # Trainer settings
    default_out = run_dir / "eval_strict"
    out_dir = Path(args.out) if args.out else default_out
    out_dir.mkdir(parents=True, exist_ok=True)
    logger = CSVLogger(save_dir=str(out_dir))

    trainer_kwargs = dict(
        accelerator=args.accelerator,
        devices=args.devices,
        logger=logger,
        default_root_dir=str(out_dir),
    )
    if args.limit_test_batches is not None:
        trainer_kwargs["limit_test_batches"] = args.limit_test_batches

    trainer = L.Trainer(callbacks=callbacks, **trainer_kwargs)

    # Strict=True is default when passing ckpt_path
    results = trainer.test(model=model, datamodule=datamodule, ckpt_path=str(ckpt))
    print("Metrics:")
    if results:
        for k, v in results[-1].items():
            print(f"  {k}: {v}")


if __name__ == "__main__":
    main()
