#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
批量同步wandb数据的脚本
从新到旧进行同步，同时在每个文件夹内留下上次同步的日期记录
如果文件夹内有内容新于上次同步记录，就进行一次同步
支持设置HTTP/HTTPS代理和精确定位wandb文件夹
"""

import os
import sys
import time
import argparse
import subprocess
from datetime import datetime
import json
from pathlib import Path
import glob


def get_last_modified_time(directory):
    """获取目录中最新文件的修改时间"""
    latest_time = 0
    for root, dirs, files in os.walk(directory):
        for file in files:
            # 跳过同步记录文件
            if file == '.wandb_sync_record.json':
                continue
            file_path = os.path.join(root, file)
            try:
                mtime = os.path.getmtime(file_path)
                if mtime > latest_time:
                    latest_time = mtime
            except Exception as e:
                print(f"警告: 无法获取文件 {file_path} 的修改时间: {e}")
    return latest_time


def get_sync_record(directory):
    """获取目录的上次同步记录"""
    record_file = os.path.join(directory, '.wandb_sync_record.json')
    if os.path.exists(record_file):
        try:
            with open(record_file, 'r') as f:
                record = json.load(f)
                return record.get('last_sync_time', 0)
        except Exception as e:
            print(f"警告: 无法读取同步记录 {record_file}: {e}")
    return 0


def update_sync_record(directory):
    """更新目录的同步记录"""
    record_file = os.path.join(directory, '.wandb_sync_record.json')
    current_time = time.time()
    sync_time_str = datetime.fromtimestamp(current_time).strftime('%Y-%m-%d %H:%M:%S')
    
    record = {
        'last_sync_time': current_time,
        'last_sync_time_human': sync_time_str
    }
    
    try:
        with open(record_file, 'w') as f:
            json.dump(record, f, indent=2, ensure_ascii=False)
        print(f"已更新同步记录: {directory} - {sync_time_str}")
    except Exception as e:
        print(f"错误: 无法更新同步记录 {record_file}: {e}")


def sync_wandb(directory, http_proxy=None, https_proxy=None, timeout=60):
    """同步wandb数据
    
    Args:
        directory: wandb数据目录
        http_proxy: HTTP代理地址
        https_proxy: HTTPS代理地址
        timeout: 命令超时时间（秒），默认30分钟
    """
    print(f"\n开始同步: {directory}")
    try:
        # 设置环境变量，包括代理
        env = os.environ.copy()
        # 可选代理设置：仅当传入时才设置/覆盖
        if http_proxy:
            env['http_proxy'] = http_proxy
            env['HTTP_PROXY'] = http_proxy
        if https_proxy:
            env['https_proxy'] = https_proxy
            env['HTTPS_PROXY'] = https_proxy
        
        # 使用 wandb 同步命令 (通过 python -m 调用, 避免 PATH 问题)
        command = [sys.executable, '-m', 'wandb', 'sync', directory]
        print(f"执行命令: {' '.join(command)} (超时：{timeout}秒)")
        result = subprocess.run(
            command,
            capture_output=True,
            text=True,
            check=True,
            env=env,
            timeout=timeout  # 添加超时参数
        )
        print(f"同步成功: {directory}")
        print(result.stdout)
        # 同步成功后更新记录
        update_sync_record(directory)
        return True
    except subprocess.TimeoutExpired as e:
        print(f"同步超时: {directory} (超过{timeout}秒)")
        print(f"命令: {e.cmd}")
        print(f"输出: {e.stdout if e.stdout else '无输出'}")
        return False
    except subprocess.CalledProcessError as e:
        print(f"同步失败: {directory}")
        print(f"错误: {e}")
        print(f"标准输出: {e.stdout}")
        print(f"标准错误: {e.stderr}")
        return False
    except Exception as e:
        print(f"同步发生未知错误: {directory}")
        print(f"错误: {type(e).__name__}: {e}")
        return False


def find_wandb_dirs(base_dir):
    """查找所有包含wandb数据的目录，精确定位到offline-run文件夹"""
    wandb_dirs = []
    
    # 查找所有wandb目录
    for root, dirs, files in os.walk(base_dir):
        if 'wandb' in dirs:
            wandb_path = os.path.join(root, 'wandb')
            if os.path.isdir(wandb_path):
                # 查找wandb目录下的offline-run-*目录
                offline_runs = glob.glob(os.path.join(wandb_path, 'offline-run-*'))
                if offline_runs:  # 如果有offline-run目录，添加它们
                    wandb_dirs.extend(offline_runs)
                else:  # 否则，如果wandb目录非空，添加wandb目录本身
                    if os.listdir(wandb_path):
                        wandb_dirs.append(wandb_path)
    
    return wandb_dirs


def main():
    parser = argparse.ArgumentParser(description='批量同步wandb数据')
    parser.add_argument('--dir', type=str, default='.', help='要搜索wandb数据的基础目录')
    parser.add_argument('--force', action='store_true', help='强制同步所有目录，忽略上次同步记录')
    parser.add_argument('--dry-run', action='store_true', help='仅列出需要同步的目录，不实际执行同步')
    parser.add_argument('--http-proxy', type=str, help='HTTP代理地址，例如 http://localhost:7890')
    parser.add_argument('--https-proxy', type=str, help='HTTPS代理地址，例如 http://localhost:7890')
    parser.add_argument('--timeout', type=int, default=60, help='同步操作超时时间（秒），默认30分钟')
    parser.add_argument('--loop', action='store_true', help='启用循环模式，定期自动运行')
    parser.add_argument('--interval', type=int, default=60, help='循环模式下的间隔时间（秒），默认60秒（1分钟）')
    args = parser.parse_args()
    
    base_dir = os.path.abspath(args.dir)
    print(f"开始扫描目录: {base_dir}")
    
    # 查找所有包含wandb数据的目录
    wandb_dirs = find_wandb_dirs(base_dir)
    print(f"找到 {len(wandb_dirs)} 个包含wandb数据的目录")
    
    if not wandb_dirs:
        print("未找到任何wandb数据目录")
        return
    
    # 获取每个目录的最新修改时间
    dir_times = []
    for directory in wandb_dirs:
        last_modified = get_last_modified_time(directory)
        last_sync = get_sync_record(directory)
        
        needs_sync = args.force or last_modified > last_sync
        
        dir_times.append({
            'directory': directory,
            'last_modified': last_modified,
            'last_modified_str': datetime.fromtimestamp(last_modified).strftime('%Y-%m-%d %H:%M:%S') if last_modified else 'N/A',
            'last_sync': last_sync,
            'last_sync_str': datetime.fromtimestamp(last_sync).strftime('%Y-%m-%d %H:%M:%S') if last_sync else '从未同步',
            'needs_sync': needs_sync
        })
    
    # 按修改时间从新到旧排序
    dir_times.sort(key=lambda x: x['last_modified'], reverse=True)
    
    # 打印所有目录的状态
    print("\n目录同步状态:")
    for i, info in enumerate(dir_times):
        status = "需要同步" if info['needs_sync'] else "无需同步"
        print(f"{i+1}. {info['directory']}")
        print(f"   最后修改: {info['last_modified_str']}")
        print(f"   上次同步: {info['last_sync_str']}")
        print(f"   状态: {status}")
    
    # 如果是dry-run模式，到此结束
    if args.dry_run:
        print("\n这是dry-run模式，不执行实际同步操作")
        return
    
    # 循环执行或单次执行
    if args.loop:
        print(f"\n启动循环模式，每 {args.interval} 秒运行一次")
        run_count = 0
        try:
            while True:
                # 执行同步
                sync_count = 0
                for info in dir_times:
                    if info['needs_sync']:
                        if sync_wandb(info['directory'], args.http_proxy, args.https_proxy, args.timeout):
                            sync_count += 1
                
                run_count += 1
                print(f"\n第 {run_count} 次同步完成，成功同步 {sync_count} 个目录")
                print(f"下一次同步将在 {args.interval} 秒后开始...")
                print(f"当前时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
                print("按 Ctrl+C 退出循环")
                
                # 等待下一次执行
                time.sleep(args.interval)
                
                # 重新获取目录状态
                wandb_dirs = find_wandb_dirs(base_dir)
                dir_times = []
                for directory in wandb_dirs:
                    last_modified = get_last_modified_time(directory)
                    last_sync = get_sync_record(directory)
                    needs_sync = args.force or last_modified > last_sync
                    dir_times.append({
                        'directory': directory,
                        'last_modified': last_modified,
                        'last_modified_str': datetime.fromtimestamp(last_modified).strftime('%Y-%m-%d %H:%M:%S') if last_modified else 'N/A',
                        'last_sync': last_sync,
                        'last_sync_str': datetime.fromtimestamp(last_sync).strftime('%Y-%m-%d %H:%M:%S') if last_sync else '从未同步',
                        'needs_sync': needs_sync
                    })
                dir_times.sort(key=lambda x: x['last_modified'], reverse=True)
        except KeyboardInterrupt:
            print("\n用户中断，退出循环模式")
    else:
        # 单次执行同步
        sync_count = 0
        for info in dir_times:
            if info['needs_sync']:
                if sync_wandb(info['directory'], args.http_proxy, args.https_proxy, args.timeout):
                    sync_count += 1
        
        print(f"\n同步完成，成功同步 {sync_count} 个目录")


if __name__ == "__main__":
    main()
