#!/usr/bin/env python
"""
Download ERA5 u10/v10 for a given region and period via CDS API.

Prerequisites
- pip install cdsapi
- Create ~/.cdsapirc with your CDS API key:
  url: https://cds.climate.copernicus.eu/api
  key: <uid>:<api-key>

Example
  python scripts/download_era5_region.py \
      --north 47.75 --south 35 --west 6 --east 18.75 \
      --year 2019 --month 01 --out outputs/era5_2019_01_region.grib
"""
from __future__ import annotations

import argparse
from pathlib import Path


def parse_args() -> argparse.Namespace:
    ap = argparse.ArgumentParser(description="Download ERA5 u10/v10 via CDS API for a region")
    ap.add_argument("--north", type=float, required=True)
    ap.add_argument("--south", type=float, required=True)
    ap.add_argument("--west", type=float, required=True)
    ap.add_argument("--east", type=float, required=True)
    ap.add_argument("--year", type=str, required=True)
    ap.add_argument("--month", type=str, required=True)
    ap.add_argument("--out", type=str, default="outputs/era5_region.grib")
    return ap.parse_args()


def main() -> None:
    args = parse_args()
    try:
        import cdsapi
    except Exception as e:  # pragma: no cover - env dependent
        raise SystemExit("Install cdsapi first: pip install cdsapi")

    c = cdsapi.Client()
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)

    # ERA5 single levels: u10/v10 hourly
    req = {
        "product_type": "reanalysis",
        "variable": ["10m_u_component_of_wind", "10m_v_component_of_wind"],
        "year": args.year,
        "month": args.month,
        "day": [f"{d:02d}" for d in range(1, 32)],
        "time": [f"{h:02d}:00" for h in range(24)],
        "area": [args.north, args.west, args.south, args.east],  # N, W, S, E
        "format": "grib",
    }
    print("Submitting ERA5 request:")
    for k, v in req.items():
        print(f"  {k}: {v}")
    c.retrieve("reanalysis-era5-single-levels", req, str(out))
    print(f"Saved -> {out.resolve()}")


if __name__ == "__main__":
    main()

