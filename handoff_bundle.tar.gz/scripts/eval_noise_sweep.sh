#!/bin/bash

# 批量含噪评测脚本：针对不同噪声类型与强度，对单一 ckpt 做鲁棒性评测
# 依赖：已在仓库中新增的 eval 阶段噪声开关 (data.apply_noise_in_eval, data.noise_config_eval)
# 用法：
#   bash scripts/eval_noise_sweep.sh -c <ckpt_path> [可选参数]
# 示例：
#   bash scripts/eval_noise_sweep.sh -c logs/gdata2/train/runs/153913.Ghead_experiment_center_paper_directflow_5/2025-06-03_14-58-41/checkpoints/epoch_038.ckpt
# 可选：
#   -t <type_list>  逗号分隔的类型列表，默认：additive,angle,magscale,pixdrop,block
#   -d <device>     设备配置，示例：cpu 或 "gpu devices=1"（默认不覆盖trainer）
#   -n <num_frames> 序列帧数，默认 5
#   -o <out_root>   输出根目录，默认 logs/eval/robust

set -euo pipefail

usage() {
  cat <<USAGE
用法: bash scripts/eval_noise_sweep.sh -c <ckpt_path> [-t types] [-d device] [-n num_frames] [-o out_root]
  -c  评测的 ckpt 路径（必填）
  -t  噪声类型列表，逗号分隔：additive,angle,magscale,pixdrop,block（默认全选）
  -d  覆盖 trainer 设备设置，例如："cpu" 或 "gpu devices=1"（默认不覆盖）
  -n  num_frames，默认 5
  -o  输出根目录，默认 logs/eval/robust
USAGE
}

CKPT=""
TYPES="additive,angle,magscale,pixdrop,block"
DEV_OVERRIDE=""
NUM_FRAMES=5
OUT_ROOT="logs/eval/robust"

while getopts ":c:t:d:n:o:h" opt; do
  case $opt in
    c) CKPT="$OPTARG" ;;
    t) TYPES="$OPTARG" ;;
    d) DEV_OVERRIDE="$OPTARG" ;;
    n) NUM_FRAMES="$OPTARG" ;;
    o) OUT_ROOT="$OPTARG" ;;
    h) usage; exit 0 ;;
    \?) echo "无效选项: -$OPTARG" >&2; usage; exit 1 ;;
    :)  echo "选项 -$OPTARG 需要一个参数。" >&2; usage; exit 1 ;;
  esac
done
shift $((OPTIND - 1))

if [ -z "$CKPT" ]; then
  echo "错误: 必须通过 -c 指定 ckpt 路径" >&2
  usage
  exit 1
fi

if [ ! -f "$CKPT" ]; then
  echo "错误: ckpt 文件不存在: $CKPT" >&2
  exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"
cd "$PROJECT_ROOT"

run_eval() {
  local label="$1"; shift
  local hydra_dir="$OUT_ROOT/${label}"
  echo "\n>>> Running eval: $label"
  echo "输出目录: $hydra_dir"
  # 为记录路径美观设置 PBS_JOBNAME（Hydra run.dir 模板里用得到）
  export PBS_JOBNAME="$label"
  # 设备覆盖
  local trainer_overrides=()
  if [ -n "$DEV_OVERRIDE" ]; then
    # 允许简写："cpu" 或 "gpu devices=1"
    case "$DEV_OVERRIDE" in
      cpu) trainer_overrides+=("trainer.accelerator=cpu" "trainer.devices=1") ;;
      gpu*) trainer_overrides+=("trainer.accelerator=gpu")
            if [[ "$DEV_OVERRIDE" == *devices=* ]]; then
              trainer_overrides+=("trainer.${DEV_OVERRIDE}")
            else
              trainer_overrides+=("trainer.devices=1")
            fi ;;
      *) echo "未知设备覆盖: $DEV_OVERRIDE" >&2 ;;
    esac
  fi

  python src/eval.py \
    model=directflow_center_frame_confidence \
    data.dataset_config.num_frames="${NUM_FRAMES}" \
    data.apply_noise_in_eval=true \
    logger=csv \
    ckpt_path="$CKPT" \
    hydra.run.dir="$hydra_dir" \
    "${trainer_overrides[@]}" \
    "$@"
}

# 各噪声类型与强度列表
IFS=',' read -r -a types_arr <<< "$TYPES"

for t in "${types_arr[@]}"; do
  case "$t" in
    additive)
      for std in 0.0 0.5 1.0 2.0; do
        run_eval "additive_std_${std}" \
          data.noise_config_eval.uv_additive_std="$std" \
          data.noise_config_eval.angle_jitter_deg=0 \
          data.noise_config_eval.magnitude_scale_std=0 \
          data.noise_config_eval.pixel_drop_prob=0 \
          data.noise_config_eval.block_drop_prob=0
      done
      ;;
    angle)
      for deg in 0 5 10 20; do
        run_eval "angle_deg_${deg}" \
          data.noise_config_eval.uv_additive_std=0 \
          data.noise_config_eval.angle_jitter_deg="$deg" \
          data.noise_config_eval.magnitude_scale_std=0 \
          data.noise_config_eval.pixel_drop_prob=0 \
          data.noise_config_eval.block_drop_prob=0
      done
      ;;
    magscale)
      for s in 0.0 0.05 0.1 0.2; do
        run_eval "magscale_std_${s}" \
          data.noise_config_eval.uv_additive_std=0 \
          data.noise_config_eval.angle_jitter_deg=0 \
          data.noise_config_eval.magnitude_scale_std="$s" \
          data.noise_config_eval.pixel_drop_prob=0 \
          data.noise_config_eval.block_drop_prob=0
      done
      ;;
    pixdrop)
      for p in 0.0 0.01 0.05 0.1; do
        run_eval "pixdrop_${p}" \
          data.noise_config_eval.uv_additive_std=0 \
          data.noise_config_eval.angle_jitter_deg=0 \
          data.noise_config_eval.magnitude_scale_std=0 \
          data.noise_config_eval.pixel_drop_prob="$p" \
          data.noise_config_eval.block_drop_prob=0
      done
      ;;
    block)
      for bp in 0.0 0.5 1.0; do
        run_eval "block_prob_${bp}" \
          data.noise_config_eval.uv_additive_std=0 \
          data.noise_config_eval.angle_jitter_deg=0 \
          data.noise_config_eval.magnitude_scale_std=0 \
          data.noise_config_eval.pixel_drop_prob=0 \
          data.noise_config_eval.block_drop_prob="$bp"
      done
      ;;
    *)
      echo "未知噪声类型: $t (支持: additive, angle, magscale, pixdrop, block)" >&2
      ;;
  esac
done

echo "\n所有任务已启动。结果写入: $OUT_ROOT/<label>/"
echo "可运行: python scripts/summarize_eval_csv.py --root $OUT_ROOT 生成汇总。"

