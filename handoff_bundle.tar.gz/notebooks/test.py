# %% [markdown]
# # 可视化调试输出 NPZ 文件
# 
# 这个 notebook 用于加载和可视化在模型验证过程中保存的 `.npz` 调试文件。
# 它包含模型输出 (`model_output`)、处理后的真实值 (`processed_ground_truth`) 和原始真实值 (`original_ground_truth`)。

# %%
import numpy as np
import matplotlib.pyplot as plt
from scipy import ndimage

# %% [markdown]
# ## 1. 加载 NPZ 文件
# 
# 请确保 `.npz` 文件与此 notebook 在同一目录下，或者提供正确的文件路径。

# %%
npz_file_path = './debug_validation_output.npz'  # 假设 npz 文件在项目根目录
try:
    data = np.load(npz_file_path)
    print(f"成功加载 NPZ 文件: {npz_file_path}")
    print("文件中包含的键:", list(data.keys()))
except FileNotFoundError:
    print(f"错误: NPZ 文件未找到于 {npz_file_path}。请检查路径。")
    data = None

# %% [markdown]
# ## 2. 提取数据
# 
# 从加载的数据中提取模型输出、处理后的真实值和原始真实值。

# %%
if data is not None:
    model_output = data['model_output']
    processed_gt = data['processed_ground_truth']
    original_gt = data['original_ground_truth']
    if 'lq' in data:
        lq_data = data['lq'] # 加载 lq 数据
    else:
        lq_data = None
        print("警告: npz 文件中未找到 'lq' 数据。")
    
    print(f"Model Output shape: {model_output.shape}")
    print(f"Processed Ground Truth shape: {processed_gt.shape}")
    print(f"Original Ground Truth shape: {original_gt.shape}")
    if lq_data is not None:
        print(f"LQ Data shape: {lq_data.shape}")
else:
    print("数据未加载，无法提取。")

# %% [markdown]
# ## 3. 可视化数据
# 
# 下面的单元格提供了可视化这些数据的示例。
# 请根据您的数据具体格式（例如，是单通道幅值还是双通道向量）调整绘图代码。

# %%
def visualize_sample(sample_idx, time_step, channel_idx=0, data_type='magnitude'):
    """可视化指定样本、时间步和通道的数据。
    
    Args:
        sample_idx (int): 要可视化的样本索引。
        time_step (int): 要可视化的时间步索引。
        channel_idx (int): 如果数据是多通道的（如向量的u或v分量），指定要显示的通道。
                           对于单通道数据（如幅值），此参数通常为0。
        data_type (str): 数据类型，'magnitude' 或 'vector'。影响标题和绘图方式。
    """
    if data is None:
        print("数据未加载，无法可视化。")
        return
    
    # 检查索引是否有效
    if sample_idx >= model_output.shape[0]:
        print(f"错误: sample_idx {sample_idx} 超出范围 (0-{model_output.shape[0]-1})")
        return
    if time_step >= model_output.shape[1]:
        print(f"错误: time_step {time_step} 超出范围 (0-{model_output.shape[1]-1})")
        return
    
    # 准备数据
    # 形状通常是 (B, T, C, H, W)
    try:
        out_slice = model_output[sample_idx, time_step, channel_idx, :, :]
        proc_gt_slice = processed_gt[sample_idx, time_step, channel_idx, :, :]
        orig_gt_slice = original_gt[sample_idx, time_step, channel_idx, :, :]
        current_lq_slice = None
        if lq_data is not None:
            # 假设 lq 和 gt/output 有相同的通道定义，或者 lq 总是单通道 (例如，如果它是输入到模型的初始帧)
            # 如果 lq 的通道结构不同，这里的 channel_idx 可能需要调整
            if lq_data.shape[2] == 1: # 如果 lq 只有一个通道
                current_lq_slice = lq_data[sample_idx, time_step, 0, :, :]
            else: # 否则，假设通道与输出/GT对齐
                current_lq_slice = lq_data[sample_idx, time_step, channel_idx, :, :]

    except IndexError as e:
        print(f"获取数据切片时发生索引错误: {e}")
        print(f"请检查 channel_idx 是否在数据通道 ({model_output.shape[2]}) 的有效范围内。")
        return
        
    fig, axes = plt.subplots(2, 2, figsize=(12, 12)) # 改为 2x2 布局
    axes_flat = axes.flatten()
    
    im_kwargs = {'cmap': 'viridis'} # 可以根据数据特性选择不同的 colormap

    # 低质量输入 (LQ)
    if current_lq_slice is not None:
        im_lq = axes_flat[0].imshow(current_lq_slice, **im_kwargs)
        axes_flat[0].set_title(f'LQ Input ({data_type}, Channel {channel_idx}) Sample {sample_idx}, Time {time_step}')
        fig.colorbar(im_lq, ax=axes_flat[0], orientation='vertical', fraction=0.046, pad=0.04)
        axes_flat[0].axis('off')
    else:
        axes_flat[0].text(0.5, 0.5, 'LQ Data Not Available',
                        horizontalalignment='center', verticalalignment='center',
                        transform=axes_flat[0].transAxes)
        axes_flat[0].axis('off')

    # 模型输出
    im0 = axes_flat[1].imshow(out_slice, **im_kwargs)
    axes_flat[1].set_title(f'Model Output ({data_type}, Channel {channel_idx})')
    fig.colorbar(im0, ax=axes_flat[1], orientation='vertical', fraction=0.046, pad=0.04)
    axes_flat[1].axis('off')
    
    # 处理后的真实值
    im1 = axes_flat[2].imshow(proc_gt_slice, **im_kwargs)
    axes_flat[2].set_title(f'Processed GT ({data_type}, Channel {channel_idx})')
    fig.colorbar(im1, ax=axes_flat[2], orientation='vertical', fraction=0.046, pad=0.04)
    axes_flat[2].axis('off')
    
    # 原始真实值
    im2 = axes_flat[3].imshow(orig_gt_slice, **im_kwargs)
    axes_flat[3].set_title(f'Original GT ({data_type}, Channel {channel_idx})')
    fig.colorbar(im2, ax=axes_flat[3], orientation='vertical', fraction=0.046, pad=0.04)
    axes_flat[3].axis('off')
        
    plt.tight_layout()
    plt.show()
    
    # 可视化差异
    diff_output_orig = np.abs(out_slice - orig_gt_slice) # 模型输出与原始GT的差异
    diff_proc_orig = np.abs(proc_gt_slice - orig_gt_slice) # 处理后GT与原始GT的差异 (如果它们不同)
    
    fig_diff, axes_diff = plt.subplots(1, 3, figsize=(18, 6)) # 修改为 1x3 布局
    
    im_diff0 = axes_diff[0].imshow(diff_output_orig, cmap='magma')
    axes_diff[0].set_title('Model Output vs Original GT (Absolute Difference)')
    fig_diff.colorbar(im_diff0, ax=axes_diff[0], orientation='vertical', fraction=0.046, pad=0.04)
    
    im_diff1 = axes_diff[1].imshow(diff_proc_orig, cmap='magma')
    axes_diff[1].set_title('Processed GT vs Original GT (Absolute Difference)')
    fig_diff.colorbar(im_diff1, ax=axes_diff[1], orientation='vertical', fraction=0.046, pad=0.04)
    
    # 计算并可视化模型输出与插值后LQ的差异
    if current_lq_slice is not None:
        target_shape = out_slice.shape
        lq_shape = current_lq_slice.shape
        
        # 计算缩放因子
        zoom_factors = (target_shape[0] / lq_shape[0], target_shape[1] / lq_shape[1])
        
        # 插值LQ图像，使用双三次插值 (order=3)
        lq_interpolated = ndimage.zoom(current_lq_slice, zoom_factors, order=3)
        
        diff_output_lq_interp = np.abs(out_slice - lq_interpolated)
        
        im_diff2 = axes_diff[2].imshow(diff_output_lq_interp, cmap='magma')
        axes_diff[2].set_title('Model Output vs Interpolated LQ (Absolute Difference)')
        fig_diff.colorbar(im_diff2, ax=axes_diff[2], orientation='vertical', fraction=0.046, pad=0.04)
    else:
        axes_diff[2].text(0.5, 0.5, 'LQ Data Not Available\nfor Difference Plot',
                        horizontalalignment='center', verticalalignment='center',
                        transform=axes_diff[2].transAxes)
        axes_diff[2].axis('off') # 如果LQ不可用，也关闭这个轴

    for ax_d in axes_diff:
        ax_d.axis('off')
        
    plt.tight_layout()
    plt.show()

# %% [markdown]
# ### 3.1 可视化示例调用
# 
# 假设您的数据是单通道的（例如，风速幅值）。如果您的 `output_mode` 是 `'vector'`，那么通道0可能是u分量，通道1可能是v分量。
# 您需要根据 `basicvsr_module.py` 中 `output_mode` 和 `input_mode` 的设置来决定 `data_type` 和 `channel_idx`。
# 
# 在 `basicvsr_module.py` 中，`outputs_comp` 和 `targets_comp` 的通道数会根据 `output_mode` 变化：
# - `'magnitude'`: 1 通道 (幅值)
# - `'vector'`: 2 通道 (u, v 分量)
# - `'magnitude_vector'`: 3 通道 (幅值, u, v)
# 
# 原始 `gt` 通常是 2 通道 (u, v)。

# %%
if data is not None:
    # 示例：可视化第一个样本，第一个时间步的数据
    # 假设 'output_mode' 是 'magnitude'，所以 channel_idx=0 代表幅值
    visualize_sample(sample_idx=0, time_step=0, channel_idx=0, data_type='magnitude')
    
    # 如果 'output_mode' 是 'vector'，可以这样可视化u分量和v分量:
    # visualize_sample(sample_idx=0, time_step=0, channel_idx=0, data_type='u分量')
    # visualize_sample(sample_idx=0, time_step=0, channel_idx=1, data_type='v分量')
    
    # 如果 'output_mode' 是 'magnitude_vector'，可以这样可视化:
    # visualize_sample(sample_idx=0, time_step=0, channel_idx=0, data_type='幅值 (来自组合输出)')
    # visualize_sample(sample_idx=0, time_step=0, channel_idx=1, data_type='u分量 (来自组合输出)')
    # visualize_sample(sample_idx=0, time_step=0, channel_idx=2, data_type='v分量 (来自组合输出)')
else:
    print("数据未加载，无法运行可视化示例。")
