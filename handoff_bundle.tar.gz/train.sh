#!/bin/bash

# 激活conda环境
source ~/.bashrc
conda activate WindSR

# 运行命令
$@