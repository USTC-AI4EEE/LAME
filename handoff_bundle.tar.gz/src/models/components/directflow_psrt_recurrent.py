import torch
import torch.nn as nn
import torch.nn.functional as F

from .psrt_recurrent import BasicRecurrentSwin

class DirectFlowBasicRecurrentSwin(BasicRecurrentSwin):
    """直接使用风速数据作为光流的PSRT-Recurrent网络
    
    继承自BasicRecurrentSwin，直接使用输入的风速数据作为光流，而不是通过SPyNet网络计算光流
    """
    # 定义常量
    TIME_INTERVAL = 3 * 3600  # 3小时，转换为秒
    # 经纬度范围（示例：中国区域）
    LAT_MIN, LAT_MAX = 35.0, 47.8
    LON_MIN, LON_MAX = 6.0, 18.8
    
    def __init__(self,
                 in_channels=2,
                 mid_channels=64,
                 embed_dim=120,
                 depths=(6, 6, 6, 6, 6, 6),
                 num_heads=(6, 6, 6, 6, 6, 6),
                 window_size=(3, 8, 8),
                 num_frames=3,
                 img_size=64,
                 patch_size=1,
                 is_low_res_input=True,
                 spynet_path=None):
        
        # 调用父类的初始化方法，但不使用spynet
        super().__init__(in_channels, mid_channels, embed_dim, depths, 
                         num_heads, window_size, num_frames, img_size, 
                         patch_size, is_low_res_input, spynet_path)
        
        # 移除spynet，因为我们直接使用风速数据作为光流
        self.spynet = None
        
        # 计算经纬度到像素的转换因子
        self.lat_resolution = (self.LAT_MAX - self.LAT_MIN)  # 总纬度跨度
        self.lon_resolution = (self.LON_MAX - self.LON_MIN)  # 总经度跨度

    def compute_flow(self, lqs):
        """将风速数据转换为光流
        
        Args:
            lqs (tensor): 输入的风速数据序列，形状为 (n, t, c, h, w)
                c=2 表示风速的x和y分量（米/秒）
        Returns:
            tuple(Tensor): 前向和后向的光流，单位为像素位移
        """
        n, t, c, h, w = lqs.size()
        
        # 检查输入通道数是否为2（风速的x和y分量）
        if c != 2:
            raise ValueError(f"输入通道数应为2（风速的x和y分量），但得到了{c}")
        
        # 计算每个纬度位置对应的实际纬度值
        lats = torch.linspace(self.LAT_MIN, self.LAT_MAX, h, device=lqs.device)
        
        # 计算每个像素对应的实际距离（米）
        lat_meters_per_pixel = 111000 * self.lat_resolution / h  # 111km 约等于 1度纬度
        
        # 计算每个纬度位置的经度方向实际距离
        # 使用余弦函数计算不同纬度下的经度距离缩放因子
        lon_scale_factors = torch.cos(lats * torch.pi / 180.0)  # 转换为弧度并计算余弦
        lon_meters_per_pixel = (111000 * lon_scale_factors).unsqueeze(1) * self.lon_resolution / w
        
        # 创建经度方向的缩放因子张量 (h, w)
        lon_scale = self.TIME_INTERVAL / lon_meters_per_pixel
        # 创建纬度方向的缩放因子 (标量)
        lat_scale = self.TIME_INTERVAL / lat_meters_per_pixel
        
        # 将经度和纬度的缩放因子组合成最终的缩放张量
        # 经度方向的缩放因子需要在每个纬度位置都不同
        scale_factors = torch.cat([
            lon_scale.expand(n, t, 1, h, w),  # 经度方向
            torch.full_like(lon_scale.expand(n, t, 1, h, w), lat_scale)  # 纬度方向
        ], dim=2)
        
        # 应用转换因子到风速数据
        flows = lqs * scale_factors
        
        # 计算后向光流（当前帧到下一帧）
        flows_backward = flows[:, :-1, :, :, :]
        
        # 计算前向光流（当前帧到前一帧）
        if self.is_mirror_extended:
            flows_forward = None
        else:
            flows_forward = -flows[:, 1:, :, :, :]
        
        return flows_forward, flows_backward

if __name__ == "__main__":
    # 测试代码
    try:
        # 创建模型实例
        model = DirectFlowBasicRecurrentSwin()
        print("模型结构：")
        print(model)
        
        # 创建随机输入进行测试
        batch_size, seq_len, channels, height, width = 1, 5, 2, 64, 64
        inputs = torch.randn(batch_size, seq_len, channels, height, width)
        print(f"\n输入形状：{inputs.shape}")
        
        # 测试前向传播
        with torch.no_grad():
            outputs = model(inputs)
            print(f"输出形状：{outputs.shape}")
            
        print("\n模型测试成功！")
    except Exception as e:
        print(f"错误信息: {e}")
        import traceback
        traceback.print_exc()
