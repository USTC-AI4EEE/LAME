import torch
import torch.nn as nn
import torch.nn.functional as F


def flow_warp(x, flow, interpolation='bilinear', padding_mode='zeros', align_corners=True):
    """Warp an image or a feature map with optical flow.
    
    Args:
        x (Tensor): Tensor with size (n, c, h, w)
        flow (Tensor): Flow with size (n, h, w, 2), normal value
        interpolation (str): Interpolation mode: 'nearest' or 'bilinear'
        padding_mode (str): Padding mode: 'zeros' or 'border' or 'reflection'
        align_corners (bool): Whether align corners

    Returns:
        Tensor: Warped image or feature map
    """
    n, c, h, w = x.size()
    
    # create mesh grid
    grid_y, grid_x = torch.meshgrid(
        torch.arange(0, h, device=x.device, dtype=x.dtype),
        torch.arange(0, w, device=x.device, dtype=x.dtype))
    grid = torch.stack((grid_x, grid_y), 2)  # (h, w, 2)
    grid = grid.unsqueeze(0).expand(n, h, w, 2)  # (n, h, w, 2)
    
    grid_flow = grid + flow
    
    # scale grid_flow to [-1,1]
    grid_flow_x = 2.0 * grid_flow[:, :, :, 0] / max(w - 1, 1) - 1.0
    grid_flow_y = 2.0 * grid_flow[:, :, :, 1] / max(h - 1, 1) - 1.0
    grid_flow = torch.stack((grid_flow_x, grid_flow_y), dim=3)
    
    output = F.grid_sample(
        x,
        grid_flow,
        mode=interpolation,
        padding_mode=padding_mode,
        align_corners=align_corners)
    
    return output


def make_layer(block, num_blocks, **kwarg):
    """Make layers by stacking the same blocks.
    
    Args:
        block (nn.Module): Neural network block.
        num_blocks (int): Number of blocks.
    
    Returns:
        nn.Sequential: Stacked blocks in nn.Sequential.
    """
    layers = []
    for _ in range(num_blocks):
        layers.append(block(**kwarg))
    return nn.Sequential(*layers) 