# src/models/components/single_frame_basicvsr_net.py

import torch
import torch.nn as nn

from .basicvsr_net import BasicVSRNet, ResidualBlocksWithInputConv

class SingleFrameBasicVSRNet(BasicVSRNet):
    """
    A single-frame version of BasicVSR for ablation studies.

    This model processes only the center frame of a sequence, effectively
    acting as a Single-Image Super-Resolution (SISR) model. It is designed
    to be comparable to the full BasicVSR model by using a similar number
    of residual blocks and the same upsampling architecture.

    It inherits from BasicVSRNet to reuse the upsampling and other modules.
    """

    def __init__(self, mid_channels=64, num_blocks=30, in_channels=2, out_channels=2, spynet_pretrained=None):
        """
        Args:
            mid_channels (int): Channel number of the intermediate features.
            num_blocks (int): Number of residual blocks. To be comparable with
                              BasicVSR, this should be similar to num_blocks in
                              the temporal propagation branches.
            in_channels (int): Number of input channels.
            out_channels (int): Number of output channels.
            spynet_pretrained (str): This is ignored as SPyNet is not used.
        """
        super(BasicVSRNet, self).__init__()

        self.mid_channels = mid_channels
        self.in_channels = in_channels

        self.resblocks = ResidualBlocksWithInputConv(
            in_channels=in_channels,
            out_channels=mid_channels,
            num_blocks=num_blocks
        )

        self.fusion = nn.Conv2d(mid_channels, mid_channels, 1, 1, 0, bias=True)

        self.upsample1 = nn.Sequential(
            nn.Conv2d(mid_channels, mid_channels * 4, 3, 1, 1, bias=True),
            nn.PixelShuffle(2)
        )
        self.upsample2 = nn.Sequential(
            nn.Conv2d(mid_channels, mid_channels * 4, 3, 1, 1, bias=True),
            nn.PixelShuffle(2)
        )

        self.conv_hr = nn.Conv2d(mid_channels, mid_channels, 3, 1, 1)
        self.conv_last = nn.Conv2d(mid_channels, out_channels, 3, 1, 1)
        self.lrelu = nn.LeakyReLU(negative_slope=0.1, inplace=True)

        self.img_upsample = nn.Upsample(
            scale_factor=4, mode='bilinear', align_corners=False)

    def forward(self, lrs):
        """
        Forward pass for the single-frame model.

        Args:
            lrs (Tensor): Input LR sequence with shape (n, t, c, h, w).
                          Only the center frame will be used.

        Returns:
            Tensor: Output HR center frame with shape (n, 1, c, 4h, 4w).
        """
        n, t, c, h, w = lrs.size()

        if c != self.in_channels:
            raise ValueError(
                f"Input channel count mismatch. Model expects {self.in_channels}, "
                f"but got {c} channels."
            )

        if t > 1:
            if t % 2 == 0:
                raise ValueError(f"Sequence length must be odd for single-frame extraction, but got {t}.")
            center_idx = t // 2
            lr_center = lrs[:, center_idx, :, :, :]
        else:
            lr_center = lrs[:, 0, :, :, :]

        feat = self.resblocks(lr_center)
        out = self.fusion(feat)

        out = self.lrelu(self.upsample1(out))
        out = self.lrelu(self.upsample2(out))
        out = self.lrelu(self.conv_hr(out))
        out = self.conv_last(out)

        base = self.img_upsample(lr_center)
        out += base

        return out.unsqueeze(1)
