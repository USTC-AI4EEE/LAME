import torch
from torch import nn, Tensor
from typing import Union, List, Tuple

from .espcn import ESPCN

class ESPCNWrapper(nn.Module):
    """ESPCN的包装类，使其能够与BasicVSRLightning模块兼容。
    
    处理以下问题：
    1. 输入维度：从(B, T, C, H, W)转换为(B, C, H, W)
    2. 处理不同的输入输出模式：magnitude、vector或magnitude_vector
    3. 支持将时间维度合并到通道维度（time_to_channel=True）
    """
    
    def __init__(
            self,
            in_channels: int,
            out_channels: int,
            channels: int,
            upscale_factor: int,
            is_image_model: bool = True,
            time_to_channel: bool = False
    ) -> None:
        """初始化ESPCN包装器。
        
        Args:
            in_channels: 输入通道数
            out_channels: 输出通道数
            channels: 中间层通道数
            upscale_factor: 上采样因子
            is_image_model: 是否以图像模型模式处理（只处理中间帧）
            time_to_channel: 是否将时间维度合并到通道维度，适用于非图像模式
        """
        super(ESPCNWrapper, self).__init__()
        
        self.is_image_model = is_image_model
        self.time_to_channel = time_to_channel
        
        # 如果使用时间维合并到通道，需要相应调整输入通道数
        self.in_channels = in_channels
        self.out_channels = out_channels
        
        # 创建基础模型
        self.model = ESPCN(
            # 如果使用时间到通道合并且不是图像模式，通道数需要乘以序列长度
            # 但在初始化时我们无法知道序列长度，将在forward方法中动态处理
            in_channels=in_channels,
            out_channels=out_channels,
            channels=channels,
            upscale_factor=upscale_factor
        )
    
    def forward(self, x: Tensor) -> Tensor:
        """处理输入并调用基础ESPCN模型。
        
        Args:
            x: 输入张量，形状为(B, T, C, H, W)
        
        Returns:
            输出张量，根据配置有不同形状：
            - 图像模式：(B, 1, C, H*scale, W*scale)
            - 非图像模式：(B, T, C, H*scale, W*scale)
            - 时间通道合并模式：会先处理输入，然后还原到(B, T, C, H*scale, W*scale)形状
        """
        batch_size, seq_len, channels, height, width = x.shape
        
        # 图像模式：只处理中间帧
        if self.is_image_model:
            mid_idx = seq_len // 2
            x_mid = x[:, mid_idx]  # (B, C, H, W)
            
            # 调用基础模型
            out = self.model(x_mid)  # (B, C, H*scale, W*scale)
            
            # 重塑为单帧序列
            out = out.unsqueeze(1)  # (B, 1, C, H*scale, W*scale)
            return out
        
        # 时间通道合并模式
        elif self.time_to_channel:
            # 将时间维度合并到通道维度 (B, T, C, H, W) -> (B, T*C, H, W)
            x_reshaped = x.view(batch_size, seq_len * channels, height, width)

            out = self.model(x_reshaped)
            
            # 将通道维度分离回时间维度 (B, T*C, H*scale, W*scale) -> (B, T, C, H*scale, W*scale)
            # out_scale_h, out_scale_w = out.shape[2:]
            # out = out.view(batch_size, seq_len, self.out_channels, out_scale_h, out_scale_w)
            
            return out
        