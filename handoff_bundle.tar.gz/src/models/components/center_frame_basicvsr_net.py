# Copyright (c) OpenMMLab. All rights reserved.
from logging import WARNING

import torch
import torch.nn as nn
import torch.nn.functional as F
import warnings

from .archs import PixelShufflePack, ResidualBlockNoBN
from .utils import flow_warp, make_layer
from .conv_module import ConvModule
from .basicvsr_net import SPyNet, ResidualBlocksWithInputConv, BasicVSRNet


class CenterFrameBasicVSRNet(BasicVSRNet):
    """CenterFrame-BasicVSR network structure for video super-resolution.
    
    A variant of BasicVSR that only propagates information to the middle frame 
    and only outputs the middle frame result.

    Support only x4 upsampling.
    Modified to support 2-channel wind velocity input instead of RGB images.

    Based on:
        BasicVSR: The Search for Essential Components in Video Super-Resolution
        and Beyond, CVPR, 2021

    Args:
        mid_channels (int): Channel number of the intermediate features.
            Default: 64.
        num_blocks (int): Number of residual blocks in each propagation branch.
            Default: 30.
        in_channels (int): Number of input channels. Default: 2.
        out_channels (int): Number of output channels. Default: 2.
        spynet_pretrained (str): Pre-trained model path of SPyNet.
            Default: None.
        full_frame_supervision (bool): Whether to output all frames for auxiliary supervision. Default: False.
    """

    def __init__(self, mid_channels=64, num_blocks=30, in_channels=2,
                 out_channels=2, spynet_pretrained=None, full_frame_supervision: bool = False,
                 propagation_mode: str = 'bidirectional', enable_alignment: bool = True,
                 enable_confidence_gate: bool = False, confidence_tau: float = 0.1,
                 confidence_smooth: bool = True):
        # 调用父类的初始化方法
        super().__init__(mid_channels, num_blocks, in_channels,
                       out_channels, spynet_pretrained)

        # 选择是否输出所有帧进行辅助监督
        self.full_frame_supervision = full_frame_supervision

        # 设置传播模式
        self.propagation_mode = propagation_mode
        if self.propagation_mode not in ['bidirectional', 'forward', 'backward']:
            raise ValueError(f"Invalid propagation_mode: {self.propagation_mode}. "
                             f"Must be 'bidirectional', 'forward', or 'backward'.")
        self.enable_alignment = enable_alignment
        # 重投影一致性门控（默认关闭，保持原行为）
        self.enable_confidence_gate = enable_confidence_gate
        self.confidence_tau = float(confidence_tau)
        self.confidence_smooth = bool(confidence_smooth)

    @torch.no_grad()
    def _photometric_confidence(self, src: torch.Tensor, tgt: torch.Tensor, flow: torch.Tensor) -> torch.Tensor:
        """基于重投影一致性计算置信度 c∈[0,1]。

        Args:
            src: 要被重投影到目标时刻的张量 (B, C, H, W)，如上一帧/下一帧。
            tgt: 当前时刻张量 (B, C, H, W)。
            flow: 用于从 tgt 坐标采样 src 的位移 (B, 2, H, W)，与 flow_warp 的假设一致。

        Returns:
            c: (B, 1, H, W) 置信度图，e = mean_c(|warp(src, flow) - tgt|)，c = exp(-e/tau)
        """
        # 将 src 按 flow 重投影到 tgt 坐标系
        warped = flow_warp(src, flow.permute(0, 2, 3, 1))
        # 通道维度求平均的 L1 误差
        err = (warped - tgt).abs().mean(dim=1, keepdim=True)
        # 指数映射到 (0,1]
        tau = max(self.confidence_tau, 1e-6)
        c = torch.exp(-err / tau)
        if self.confidence_smooth:
            c = F.avg_pool2d(c, kernel_size=3, stride=1, padding=1)
        return torch.clamp(c, 0.0, 1.0)

    def check_sequence_length(self, lrs):
        """Check if the sequence length is valid (odd number).

        Args:
            lrs (tensor): Input LR images with shape (n, t, c, h, w)
        """
        n, t, c, h, w = lrs.size()
        
        if t % 2 == 0:
            raise ValueError(
                f"Sequence length must be odd to have a center frame, but got {t}")
        
        if t < 3:
            raise ValueError(
                f"Sequence length must be at least 3 to perform propagation, but got {t}")
        
        # 计算中间帧的索引
        center_idx = t // 2
        return center_idx

    def compute_flow(self, lrs):
        """Compute optical flow using SPyNet for feature warping.

        Args:
            lrs (tensor): Input LR images with shape (n, t, c, h, w)

        Return:
            tuple(Tensor): Optical flow. 'flows_forward' corresponds to the
                flows used for forward-time propagation (current to previous).
                'flows_backward' corresponds to the flows used for
                backward-time propagation (current to next).
        """
        n, t, c, h, w = lrs.size()
        
        # 计算所有相邻帧之间的光流
        # 不使用父类的compute_flow方法，因为它可能返回None
        lrs_1 = lrs[:, :-1, :, :, :].reshape(-1, c, h, w)
        lrs_2 = lrs[:, 1:, :, :, :].reshape(-1, c, h, w)

        flows_backward = self.spynet(lrs_1, lrs_2).view(n, t - 1, 2, h, w)
        flows_forward = self.spynet(lrs_2, lrs_1).view(n, t - 1, 2, h, w)
        
        return flows_forward, flows_backward

    def forward(self, lrs):
        """Forward function for CenterFrameBasicVSR.

        Args:
            lrs (Tensor): Input LR sequence with shape (n, t, c, h, w).
                t must be an odd number to have a center frame.

        Returns:
            Tensor: Output HR center frame with shape (n, 1, c, 4h, 4w).
        """
        if self.full_frame_supervision:
            return super().forward(lrs)

        n, t, c, h, w = lrs.size()
        center_idx = self.check_sequence_length(lrs)
        flows_forward, flows_backward = self.compute_flow(lrs)

        # Initialize features for backward and forward propagation
        feat_prop_backward = torch.zeros(n, self.mid_channels, h, w, device=lrs.device)
        feat_prop_forward = torch.zeros(n, self.mid_channels, h, w, device=lrs.device)

        # Backward propagation (from future to center)
        if self.propagation_mode in ['bidirectional', 'backward']:
            feat_prop = torch.zeros(n, self.mid_channels, h, w, device=lrs.device)
            for i in range(t - 1, center_idx - 1, -1):
                lr_curr = lrs[:, i, :, :, :]
                if self.enable_alignment and i < t - 1:
                    flow = flows_backward[:, i, :, :, :]
                    feat_prop_warped = flow_warp(feat_prop, flow.permute(0, 2, 3, 1))
                    if self.enable_confidence_gate:
                        # 使用相邻帧构造重投影一致性：warp(lrs[i+1]) ≈ lrs[i]
                        src = lrs[:, i + 1, :, :, :]
                        tgt = lrs[:, i, :, :, :]
                        c = self._photometric_confidence(src, tgt, flow)
                        feat_prop = feat_prop_warped * c
                    else:
                        feat_prop = feat_prop_warped
                feat_prop = torch.cat([lr_curr, feat_prop], dim=1)
                feat_prop = self.backward_resblocks(feat_prop)
                if i == center_idx:
                    feat_prop_backward = feat_prop

        # Forward propagation (from past to center)
        if self.propagation_mode in ['bidirectional', 'forward']:
            feat_prop = torch.zeros(n, self.mid_channels, h, w, device=lrs.device)
            for i in range(0, center_idx + 1):
                lr_curr = lrs[:, i, :, :, :]
                if self.enable_alignment and i > 0 and flows_forward is not None:
                    flow = flows_forward[:, i - 1, :, :, :]
                    feat_prop_warped = flow_warp(feat_prop, flow.permute(0, 2, 3, 1))
                    if self.enable_confidence_gate:
                        # 使用相邻帧构造重投影一致性：warp(lrs[i-1]) ≈ lrs[i]
                        src = lrs[:, i - 1, :, :, :]
                        tgt = lrs[:, i, :, :, :]
                        c = self._photometric_confidence(src, tgt, flow)
                        feat_prop = feat_prop_warped * c
                    else:
                        feat_prop = feat_prop_warped
                feat_prop = torch.cat([lr_curr, feat_prop], dim=1)
                feat_prop = self.forward_resblocks(feat_prop)
                if i == center_idx:
                    feat_prop_forward = feat_prop

        # 在这里我们不再需要检查None值，因为我们预先初始化了张量
        # 但仍然可以添加日志或调试信息
        # 例如：检查张量是否全为0
        if torch.all(feat_prop_backward == 0) or torch.all(feat_prop_forward == 0):
            warnings.warn("中间帧特征全为零，可能诱发低质量输出。")

        # 融合中间帧的双向特征
        out = torch.cat([feat_prop_backward, feat_prop_forward], dim=1)
        out = self.fusion(out)

        # 上采样
        out = self.lrelu(self.upsample1(out))
        out = self.lrelu(self.upsample2(out))
        out = self.lrelu(self.conv_hr(out))
        out = self.conv_last(out)
        base = self.img_upsample(lrs[:, center_idx, :, :, :])
        out += base

        # 返回中间帧的结果，确保返回BTCHW格式，即使T=1
        # 添加时间维度 [B, C, H, W] -> [B, 1, C, H, W]
        out = out.unsqueeze(1)
        return out


if __name__ == "__main__":
    try:
        # 创建模型时不指定预训练模型路径
        model = CenterFrameBasicVSRNet(spynet_pretrained=None)
        print("模型结构：")
        print(model)
        
        # 测试1：2通道输入（原始设计）
        print("\n测试1：2通道输入（原始设计）")
        batch_size, seq_len, channels, height, width = 1, 5, 2, 64, 64
        inputs = torch.randn(batch_size, seq_len, channels, height, width)
        print(f"输入形状：{inputs.shape}")
        
        # 测试前向传播
        with torch.no_grad():
            outputs = model(inputs)
            print(f"输出形状：{outputs.shape}")
        
        # 测试2：3通道输入（额外测试）
        print("\n测试2：3通道输入（额外测试）")
        # 创建三通道模型
        model_3ch = CenterFrameBasicVSRNet(in_channels=3, out_channels=3, spynet_pretrained=None)
        # 创建三通道输入
        batch_size, seq_len, channels, height, width = 1, 5, 3, 64, 64
        inputs_3ch = torch.randn(batch_size, seq_len, channels, height, width)
        print(f"输入形状：{inputs_3ch.shape}")
        
        # 测试前向传播
        with torch.no_grad():
            outputs_3ch = model_3ch(inputs_3ch)
            print(f"输出形状：{outputs_3ch.shape}")
            
        print("\n模型测试成功！")
    except Exception as e:
        print(f"错误信息: {e}")
        import traceback
        traceback.print_exc()
