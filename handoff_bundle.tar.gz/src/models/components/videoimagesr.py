import torch
import torch.nn as nn
import torch.nn.functional as F

from .basicvsr_net import BasicVSRNet, SPyNet, ResidualBlocksWithInputConv
from .drct import DRCT
from .utils import flow_warp


class VideoAssistedImageSR(nn.Module):
    """视频辅助的图像超分模型。
    
    该模型结合了BasicVSR视频超分模型和DRCT图像超分模型。
    BasicVSR用于提取时序特征，这些特征通过DRCT的交叉注意力机制融合到当前帧处理中。
    
    Args:
        mid_channels (int): BasicVSR中间特征通道数，默认为64
        num_blocks (int): BasicVSR中residual blocks的数量，默认为10
        img_size (int): 输入图像大小，默认为64
        embed_dim (int): DRCT中嵌入维度，默认为96
        depths (tuple): DRCT各阶段深度，默认为(6, 6, 6, 6)
        num_heads (tuple): DRCT各阶段注意力头数，默认为(6, 6, 6, 6)
        window_size (int): DRCT窗口大小，默认为7
        upscale (int): 上采样倍数，默认为4
        in_channels (int): 输入通道数，默认为2（风场向量）
        out_channels (int): 输出通道数，默认为2（风场向量）
        spynet_pretrained (str): SPyNet预训练模型路径，默认为None
        use_gating (bool): 是否使用门控融合机制，默认为True
    """
    
    def __init__(self,
                 mid_channels=64,
                 num_blocks=10,
                 img_size=64,
                 embed_dim=96,
                 depths=(6, 6, 6, 6),
                 num_heads=(6, 6, 6, 6),
                 window_size=7,
                 upscale=4,
                 in_channels=2,
                 out_channels=2,
                 spynet_pretrained=None,
                 use_gating=True):
        super(VideoAssistedImageSR, self).__init__()
        
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.upscale = upscale
        
        # 初始化视频特征提取器 - 使用BasicVSR的主要组件
        self.spynet = SPyNet(in_channels=in_channels)
        
        # 提取特征的残差块（从BasicVSR中借鉴）
        # 不需要上采样部分，因为我们只需要提取特征
        
        # 视频特征提取网络 - 前向和后向分支
        self.backward_resblocks = ResidualBlocksWithInputConv(
            in_channels + mid_channels, mid_channels, num_blocks // 2)
        self.forward_resblocks = ResidualBlocksWithInputConv(
            in_channels + mid_channels, mid_channels, num_blocks // 2)
        
        # 融合前向和后向特征
        self.fusion = nn.Conv2d(
            mid_channels * 2, mid_channels, 1, 1, 0, bias=True)
        
        # 特征变换 - 将视频特征调整为DRCT需要的维度
        # 设置mem_chans为DRCT所需的记忆特征通道数
        self.mem_chans = 32
        
        self.feat_transform = nn.Sequential(
            nn.Conv2d(mid_channels, self.mem_chans, 3, 1, 1),
            nn.LeakyReLU(negative_slope=0.1, inplace=True)
        )
        
        # 初始化DRCT图像超分网络
        self.drct = DRCT(
            img_size=img_size,
            patch_size=1,
            in_chans=self.mem_chans,  # 视频特征作为记忆特征输入
            mem_chans=0, 
            embed_dim=embed_dim,
            depths=depths,
            num_heads=num_heads,
            window_size=window_size,
            upscale=upscale,
            num_out_ch=out_channels,
            cross_mode=True,  # 启用交叉注意力
            use_gating=use_gating  # 使用门控融合
        )
        
        # 激活函数
        self.lrelu = nn.LeakyReLU(negative_slope=0.1, inplace=True)
        
    def compute_flow(self, lrs):
        """计算光流以用于特征对齐。
        
        Args:
            lrs (tensor): 输入LR序列，形状为 (n, t, c, h, w)
            
        Return:
            tuple(Tensor): 光流。'flows_forward'用于前向传播（当前到前一帧），
            'flows_backward'用于后向传播（当前到下一帧）。
        """
        n, t, c, h, w = lrs.size()
        lrs_1 = lrs[:, :-1, :, :, :].reshape(-1, c, h, w)
        lrs_2 = lrs[:, 1:, :, :, :].reshape(-1, c, h, w)
        
        flows_backward = self.spynet(lrs_1, lrs_2).view(n, t - 1, 2, h, w)
        flows_forward = self.spynet(lrs_2, lrs_1).view(n, t - 1, 2, h, w)
        
        return flows_forward, flows_backward
    
    def extract_video_features(self, lrs):
        """从输入序列中提取时序特征。
        
        Args:
            lrs (Tensor): 输入LR序列，形状为 (n, t, c, h, w)
            
        Returns:
            Tensor: 提取的时序特征，形状为 (n, mem_channels, h, w)
        """
        n, t, c, h, w = lrs.size()
        
        # 计算光流
        flows_forward, flows_backward = self.compute_flow(lrs)
        
        # 后向传播
        feat_prop_backward = lrs.new_zeros(n, self.fusion.weight.size(1) // 2, h, w)
        for i in range(t - 1, -1, -1):
            if i < t - 1:  # 最后一个时间步不需要warp
                flow = flows_backward[:, i, :, :, :]
                feat_prop_backward = flow_warp(feat_prop_backward, flow.permute(0, 2, 3, 1))
            
            feat_prop_backward = torch.cat([lrs[:, i, :, :, :], feat_prop_backward], dim=1)
            feat_prop_backward = self.backward_resblocks(feat_prop_backward)
        
        # 前向传播
        feat_prop_forward = lrs.new_zeros(n, self.fusion.weight.size(1) // 2, h, w)
        for i in range(0, t):
            if i > 0:  # 第一个时间步不需要warp
                flow = flows_forward[:, i - 1, :, :, :]
                feat_prop_forward = flow_warp(feat_prop_forward, flow.permute(0, 2, 3, 1))
            
            feat_prop_forward = torch.cat([lrs[:, i, :, :, :], feat_prop_forward], dim=1)
            feat_prop_forward = self.forward_resblocks(feat_prop_forward)
        
        # 融合前向和后向特征
        feat = torch.cat([feat_prop_backward, feat_prop_forward], dim=1)
        feat = self.lrelu(self.fusion(feat))
        
        # 转换为DRCT需要的记忆特征格式
        mem_feat = self.feat_transform(feat)
        
        return mem_feat
        
    def forward(self, x):
        """前向传播函数。
        
        这个模型可以处理两种输入情况:
        1. 单帧图像: 将其视为只有1帧的序列处理
        2. 视频序列: 处理完整的时序信息
        
        Args:
            x (Tensor): 输入可以是:
               - 单帧图像，形状为 (n, c, h, w)
               - 视频序列，形状为 (n, t, c, h, w)
               
        Returns:
            Tensor: 超分辨率输出，形状与输入对应:
               - 对于单帧输入: (n, out_c, h*scale, w*scale)
               - 对于视频输入: (n, t, out_c, h*scale, w*scale)
        """
        # 检查输入是单帧还是视频序列
        if len(x.shape) == 4:  # 单帧图像 (n, c, h, w)
            is_single_frame = True
            # 将单帧转换为只有1帧的序列
            x = x.unsqueeze(1)  # (n, 1, c, h, w)
        elif len(x.shape) == 5:  # 视频序列 (n, t, c, h, w)
            is_single_frame = False
        else:
            raise ValueError(f"Unexpected input shape: {x.shape}, should be (n, c, h, w) or (n, t, c, h, w)")
        
        # 提取视频特征
        mem_feat = self.extract_video_features(x)  # (n, mem_channels, h, w)
        
        # 处理中间帧或单帧
        if is_single_frame:
            # 单帧情况
            current_frame = x[:, 0]  # (n, c, h, w)
        else:
            # 视频情况 - 我们选择中间帧作为当前帧进行处理
            mid_idx = x.size(1) // 2
            current_frame = x[:, mid_idx]  # (n, c, h, w)
        
        # 使用DRCT处理当前帧，并将视频特征作为记忆输入
        # out = self.drct(current_frame, mem_feat)  # (n, out_c, h*scale, w*scale)
        out = self.drct(mem_feat)
        
        # 如果输入是视频序列，将结果扩展为序列
        if not is_single_frame:
            # 创建输出序列
            out_seq = [out]
            out = torch.stack(out_seq, dim=1)  # (n, t, out_c, h*scale, w*scale)
        
        return out

