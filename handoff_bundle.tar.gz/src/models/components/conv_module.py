import torch
import torch.nn as nn


class ConvModule(nn.Module):
    """A conv block that contains conv/norm/activation layers.

    Args:
        in_channels (int): Same as nn.Conv2d.
        out_channels (int): Same as nn.Conv2d.
        kernel_size (int or tuple[int]): Same as nn.Conv2d.
        stride (int or tuple[int]): Same as nn.Conv2d.
        padding (int or tuple[int]): Same as nn.Conv2d.
        dilation (int or tuple[int]): Same as nn.Conv2d.
        groups (int): Same as nn.Conv2d.
        bias (bool or str): If specified as `auto`, it will be decided by the
            norm_cfg. Bias will be set as True if norm_cfg is None, otherwise
            False.
        conv_cfg (dict): Config dict for convolution layer.
        norm_cfg (dict): Config dict for normalization layer.
        act_cfg (dict): Config dict for activation layer.
        order (tuple[str]): The order of conv/norm/activation layers. It is a
            sequence of "conv", "norm" and "act". Examples are
            ("conv", "norm", "act") and ("act", "conv", "norm").
    """

    def __init__(self,
                 in_channels,
                 out_channels,
                 kernel_size,
                 stride=1,
                 padding=0,
                 dilation=1,
                 groups=1,
                 bias='auto',
                 norm_cfg=None,
                 act_cfg=None,
                 order=('conv', 'norm', 'act')):
        super().__init__()
        
        self.conv = nn.Conv2d(
            in_channels=in_channels,
            out_channels=out_channels,
            kernel_size=kernel_size,
            stride=stride,
            padding=padding,
            dilation=dilation,
            groups=groups,
            bias=bias if isinstance(bias, bool) else True)
            
        # 处理激活层
        self.activation = None
        if act_cfg is not None:
            if isinstance(act_cfg, dict):
                act_type = act_cfg.get('type', 'ReLU')
                if act_type == 'ReLU':
                    self.activation = nn.ReLU(inplace=True)
                elif act_type == 'LeakyReLU':
                    alpha = act_cfg.get('negative_slope', 0.01)
                    self.activation = nn.LeakyReLU(negative_slope=alpha, inplace=True)
                elif act_type == 'PReLU':
                    self.activation = nn.PReLU()
            # 如果act_cfg是字符串而不是dict，则默认使用ReLU
            elif act_cfg == 'ReLU':
                self.activation = nn.ReLU(inplace=True)
                
    def forward(self, x):
        x = self.conv(x)
        if self.activation is not None:
            x = self.activation(x)
        return x 