import torch
import torch.nn as nn
import torch.nn.functional as F

class InterpolationModel(nn.Module):
    """A simple model that only upscales input features using interpolation
    and includes a symbolic trainable layer."""
    def __init__(self, dim: int, upscale_factor: int = 4, *args, **kwargs):
        """Initialize the InterpolationModel.

        Args:
            dim (int): Input feature dimension.
            upscale_factor (int): Factor to upscale the input resolution. Defaults to 4.
        """
        super().__init__()
        self.dim = dim
        self.upscale_factor = upscale_factor

        if self.upscale_factor <= 0:
            raise ValueError(f"upscale_factor must be positive, got {upscale_factor}")

        # Symbolic layer to ensure the model has trainable parameters
        self.dummy_conv = nn.Conv2d(dim, dim, kernel_size=1, bias=False) # kernel_size=1 to keep H, W same

    def forward(self, x, mem=None, x_size=None):
        """Forward pass: Upscales the input tensor using interpolation and a symbolic conv layer.

        Args:
            x (torch.Tensor): Input tensor, expected shape (B, T, C, H, W) or (B, C, H, W).
            mem (torch.Tensor, optional): Memory tensor (ignored). Defaults to None.
            x_size (tuple, optional): Original spatial size (ignored). Defaults to None.

        Returns:
            torch.Tensor: Upscaled output tensor with the same dimension format as input.
        """
        # mem and x_size are ignored

        if x.ndim == 5:
            B, T, C, H, W = x.shape
            x_reshaped = x.view(B * T, C, H, W)
            input_was_5d = True
        elif x.ndim == 4:
             B, C, H, W = x.shape
             T = 1
             x_reshaped = x
             input_was_5d = False
        else:
            raise ValueError(f"Input tensor must be 4D (B, C, H, W) or 5D (B, T, C, H, W), but got shape {x.shape}")

        if self.upscale_factor == 1:
            # If upscale_factor is 1, just apply the dummy conv
            out_intermediate = x_reshaped
        else:
            # Upscale using bilinear interpolation
            out_intermediate = F.interpolate(
                x_reshaped,
                scale_factor=self.upscale_factor,
                mode='bilinear',
                align_corners=False
            )
        
        # Apply the symbolic convolutional layer
        out_reshaped = self.dummy_conv(out_intermediate)

        if input_was_5d:
            _BT, _C, H_new, W_new = out_reshaped.shape
            out = out_reshaped.view(B, T, _C, H_new, W_new)
        else:
             out = out_reshaped

        return out
