import torch
from .center_frame_basicvsr_net import CenterFrameBasicVSRNet

class DirectFlowCenterFrameBasicVSRNet(CenterFrameBasicVSRNet):
    """CenterFrame-BasicVSR network that uses direct wind flow.

    Inherits from CenterFrameBasicVSRNet and overrides flow computation
    to use wind data directly, similar to DirectFlowBasicVSRNet.
    The output is the super-resolved center frame.
    """
    # Constants for flow calculation from DirectFlowBasicVSRNet
    TIME_INTERVAL = 3 * 3600  # 3 hours, converted to seconds
    # Example: China region, can be configured if needed
    LAT_MIN, LAT_MAX = 35.0, 47.8
    LON_MIN, LON_MAX = 6.0, 18.8

    def __init__(self, mid_channels=64, num_blocks=30, in_channels=2, out_channels=2, spynet_pretrained=None, propagation_mode: str = 'bidirectional', enable_alignment: bool = True,
                 enable_confidence_gate: bool = False, confidence_tau: float = 0.1, confidence_smooth: bool = True):
        # Call parent's __init__ (CenterFrameBasicVSRNet)
        # spynet_pretrained is passed as None because SPyNet will not be used.
        super().__init__(
            mid_channels=mid_channels,
            num_blocks=num_blocks,
            in_channels=in_channels,
            out_channels=out_channels,
            spynet_pretrained=None,  # Explicitly pass None, SPyNet is not used
            propagation_mode=propagation_mode,
            enable_alignment=enable_alignment,
            enable_confidence_gate=enable_confidence_gate,
            confidence_tau=confidence_tau,
            confidence_smooth=confidence_smooth
        )

        # Remove spynet, as flow is computed directly from wind data
        self.spynet = None

        # Calculate geo-to-pixel conversion factors for use in compute_flow
        self.lat_resolution = (self.LAT_MAX - self.LAT_MIN)  # Total latitude span
        self.lon_resolution = (self.LON_MAX - self.LON_MIN)  # Total longitude span
        # self.is_mirror_extended is inherited from BasicVSRNet via CenterFrameBasicVSRNet

    def compute_flow(self, lrs):
        """Computes optical flow directly from wind data in lrs.

        This method is adapted from DirectFlowBasicVSRNet and enhanced to use wind data
        from both adjacent frames for more accurate flow calculation.

        Args:
            lrs (tensor): Input low-resolution sequence, expected to contain
                          wind data (U, V components). Shape (n, t, c, h, w).
                          If c matches self.in_channels=3, assumes (magnitude, U, V).
                          If c matches self.in_channels=2, assumes (U, V).

        Returns:
            tuple(Tensor): flows_forward, flows_backward
                           Each flow tensor has shape (n, t-1, 2, h, w).
        """
        n, t, c_in_lrs, h, w = lrs.size()

        # Determine wind data based on self.in_channels configuration
        if self.in_channels == 3:
            if c_in_lrs != 3:
                raise ValueError(
                    f"Input LRS channels mismatch for flow computation: "
                    f"Network configured for {self.in_channels} channels (expected mag, U, V), "
                    f"but LRS has {c_in_lrs} channels."
                )
            wind_data_for_flow = lrs[:, :, 1:3, :, :]  # Extract U, V components (channels 1 and 2)
        elif self.in_channels == 2:
            if c_in_lrs != 2:
                 raise ValueError(
                    f"Input LRS channels mismatch for flow computation: "
                    f"Network configured for {self.in_channels} channels (expected U, V), "
                    f"but LRS has {c_in_lrs} channels."
                )
            wind_data_for_flow = lrs # Assumes LRS itself is (U,V)
        else:
            raise ValueError(
                f"Unsupported self.in_channels ({self.in_channels}) for direct flow computation. "
                f"Must be 2 (U,V) or 3 (mag,U,V)."
            )

        # Calculate latitude for each pixel row
        lats_rad = torch.linspace(self.LAT_MIN, self.LAT_MAX, h, device=lrs.device) * (torch.pi / 180.0)

        # Meters per pixel for latitude (constant for a given projection & resolution)
        # Average radius of Earth: 6371 km. Circumference = 2 * pi * R.
        # Length of 1 degree of latitude is approx 111 km.
        lat_meters_per_pixel = (111000.0 * self.lat_resolution) / h

        # Meters per pixel for longitude (varies with latitude)
        # Length of 1 degree of longitude = 111 km * cos(latitude)
        lon_meters_per_pixel_at_lat = (111000.0 * torch.cos(lats_rad)).unsqueeze(1) * self.lon_resolution / w
        lon_meters_per_pixel_at_lat = lon_meters_per_pixel_at_lat.clamp(min=1e-6) # Avoid division by zero

        # Scaling factors to convert m/s to pixels/frame_interval
        # flow_pixels = (speed_mps * time_interval_s) / meters_per_pixel
        u_flow_scale = self.TIME_INTERVAL / lon_meters_per_pixel_at_lat # Shape (h, w)
        v_flow_scale = self.TIME_INTERVAL / lat_meters_per_pixel      # Scalar
        
        # wind_data_for_flow has shape (n, t, 2, h, w)
        # wind_data_for_flow[:, :, 0, :, :] is U component (longitude direction)
        # wind_data_for_flow[:, :, 1, :, :] is V component (latitude direction)
        flow_u = wind_data_for_flow[:, :, 0, :, :] * u_flow_scale # (n,t,h,w) * (h,w) -> (n,t,h,w)
        flow_v = wind_data_for_flow[:, :, 1, :, :] * v_flow_scale # (n,t,h,w) * scalar -> (n,t,h,w)

        flows = torch.stack([flow_u, flow_v], dim=2)  # (n, t, 2, h, w)

        # 计算反向光流（i到i+1）：使用第i帧和第i+1帧风速的平均值
        # 对于每一个帧i（除了最后一帧），计算它和i+1帧之间的光流
        flows_backward = torch.zeros((n, t-1, 2, h, w), device=lrs.device)
        for i in range(t-1):
            # 计算当前帧i和下一帧i+1的风速平均值
            avg_flow = (flows[:, i, :, :, :] + flows[:, i+1, :, :, :]) / 2.0
            flows_backward[:, i, :, :, :] = avg_flow
        
        # 计算正向光流（i到i-1）：使用第i帧和第i-1帧风速的平均值
        # 对于每一个帧i（除了第一帧），计算它和i-1帧之间的光流
        flows_forward = torch.zeros((n, t-1, 2, h, w), device=lrs.device)
        for i in range(1, t):
            # 计算当前帧i和前一帧i-1的风速平均值，并取负值（因为是反方向）
            avg_flow = -(flows[:, i, :, :, :] + flows[:, i-1, :, :, :]) / 2.0
            flows_forward[:, i-1, :, :, :] = avg_flow

        return flows_forward, flows_backward

    # The `forward` method and `check_sequence_length` are inherited from CenterFrameBasicVSRNet
    # and will use the overridden `compute_flow` method.

if __name__ == "__main__":
    try:
        print("Testing DirectFlowCenterFrameBasicVSRNet")

        # Common parameters for tests
        mid_ch = 32 # Smaller for faster test
        n_blocks = 5 # Smaller for faster test
        batch, seq, height_lr, width_lr = 1, 5, 16, 16 # Odd seq_len for center frame

        # Test 1: 2-channel input (U, V wind components), 2-channel output
        print("\nTest 1: 2-channel input/output")
        model_2ch = DirectFlowCenterFrameBasicVSRNet(
            mid_channels=mid_ch, num_blocks=n_blocks,
            in_channels=2, out_channels=2
        )

        inputs_2ch = torch.randn(batch, seq, 2, height_lr, width_lr)
        print(f"Input shape (2ch): {inputs_2ch.shape}")

        with torch.no_grad():
            outputs_2ch = model_2ch(inputs_2ch)
        
        # Expected output: (batch_size, 1 (center frame), out_channels, height_lr*4, width_lr*4)
        expected_out_shape_2ch = (batch, 1, 2, height_lr * 4, width_lr * 4)
        print(f"Output shape (2ch): {outputs_2ch.shape}")
        assert outputs_2ch.shape == expected_out_shape_2ch, \
            f"Test 1 FAILED: Expected shape {expected_out_shape_2ch}, got {outputs_2ch.shape}"
        print("Test 1 PASSED")

        # Test 2: 3-channel input (e.g., Magnitude, U, V), 3-channel output
        print("\nTest 2: 3-channel input/output")
        model_3ch = DirectFlowCenterFrameBasicVSRNet(
            mid_channels=mid_ch, num_blocks=n_blocks,
            in_channels=3, out_channels=3 # Assuming output also has 3 channels
        )
        
        inputs_3ch = torch.randn(batch, seq, 3, height_lr, width_lr)
        print(f"Input shape (3ch): {inputs_3ch.shape}")

        with torch.no_grad():
            outputs_3ch = model_3ch(inputs_3ch)

        expected_out_shape_3ch = (batch, 1, 3, height_lr * 4, width_lr * 4)
        print(f"Output shape (3ch): {outputs_3ch.shape}")
        assert outputs_3ch.shape == expected_out_shape_3ch, \
            f"Test 2 FAILED: Expected shape {expected_out_shape_3ch}, got {outputs_3ch.shape}"
        print("Test 2 PASSED")


        print("\nAll DirectFlowCenterFrameBasicVSRNet tests finished successfully!")

    except Exception as e:
        print(f"Error during testing: {e}")
        import traceback
        traceback.print_exc()
