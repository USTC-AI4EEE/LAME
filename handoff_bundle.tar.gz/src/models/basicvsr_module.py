import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.optim.adam import Adam
from torch.optim.optimizer import Optimizer
from torch.optim.lr_scheduler import CosineAnnealingWarmRestarts, OneCycleLR, _LRScheduler
from math import sqrt
from lightning import LightningModule
from typing import Dict, Optional, Any, Tuple, Union, List
from lightning.pytorch.utilities.types import OptimizerLRScheduler, LRSchedulerConfig
from torchmetrics.image import PeakSignalNoiseRatio, StructuralSimilarityIndexMeasure
from torchmetrics import MeanAbsoluteError, MeanSquaredError
import numpy as np
from collections.abc import Sized


class CharbonnierLoss(nn.Module):
    """Charbonnier损失函数。"""
    
    def __init__(self, eps=1e-6):
        super().__init__()
        self.eps = eps
    
    def forward(self, pred, target):
        diff = pred - target
        loss = torch.mean(torch.sqrt(diff * diff + self.eps))
        return loss


class BasicVSRLightning(LightningModule):
    """BasicVSR 视频超分辨率模型的 Lightning 实现。
    
    参考论文:
        BasicVSR: The Search for Essential Components in Video Super-Resolution
        and Beyond, CVPR, 2021
    """

    # 先使用向量归一化，再进行z-score归一化
    MAX_ABS_VALUE = 26.3344
    MEAN_VALUE = 0.004561
    STD_VALUE = 0.005295
    # 先使用幅值归一化，再进行z-score归一化
    MAX_HIGH_RES = 31.347172
    MAX_LOW_RES = 26.298004
    HIGH_MEAN = 0.13222886332571507
    LOW_MEAN = 0.14668680441230536
    HIGH_STD = sqrt(0.010302625093329697)
    LOW_STD = sqrt(0.012968222639802844)
    
    
    def __init__(
        self,
        model: nn.Module,
        learning_rate: float = 2e-4,
        input_mode: str = 'vector',
        output_mode: str = 'vector',
        skip_val_frames: int = 0,
        is_image_model: bool = False,
        normalize_by_max: bool = True,  # 是否使用max_abs_value进行归一化
        normalize_by_zscore: bool = False,  # 是否使用mean_value和std_value进行z-score归一化
        enable_debug_logging: bool = False, # 是否开启调试日志记录
        debug_log_path: str = "debug_validation_output.npz", # 调试日志文件路径
        normalize_type: str = "vector",
        loss_fn: str = "L1",
        full_frame_supervision_epochs: int = 0,
        log_sync_dist: bool = False,
        **kwargs
    ):
        """初始化 BasicVSR Lightning 模块。
        
        Args:
            model: BasicVSR网络
            learning_rate: 学习率，默认为2e-4
            input_mode: 输入模式，可选值为 'magnitude'(幅值), 'vector'(向量), 'magnitude_vector'(幅值和向量)
            output_mode: 输出模式，可选值为 'magnitude'(幅值), 'vector'(向量), 'magnitude_vector'(幅值和向量)
            skip_val_frames: 验证时跳过的帧数
            is_image_model: 是否为图像超分模型，若为True，则只使用中间帧的gt进行损失计算和指标评估
            enable_debug_logging: 是否开启调试日志记录，默认为False
            debug_log_path: 调试日志文件路径，默认为 'debug_validation_output.npz'
            log_sync_dist: 是否为所有日志开启分布式同步(sync_dist)，默认为 False
        """
        super().__init__()
        self.save_hyperparameters(ignore=['model'])
        
        # 验证输入输出模式
        valid_modes = ['magnitude', 'vector', 'magnitude_vector']
        if input_mode not in valid_modes:
            raise ValueError(f"input_mode 必须是 {valid_modes} 之一，而不是 {input_mode}")
        if output_mode not in valid_modes:
            raise ValueError(f"output_mode 必须是 {valid_modes} 之一，而不是 {output_mode}")
        
        # 主要组件
        self.model = model
        # 可配置损失函数
        loss_name = self.hparams.get('loss_fn', 'charbonnier').lower()
        if loss_name == 'charbonnier':
            self.pixel_loss = CharbonnierLoss()
        elif loss_name in ('l1', 'mae'):
            self.pixel_loss = nn.L1Loss()
        elif loss_name in ('mse', 'l2'):
            self.pixel_loss = nn.MSELoss()
        else:
            raise ValueError(f"Unsupported loss_fn: {loss_name}")
        self.learning_rate = learning_rate
        self.input_mode = input_mode
        self.output_mode = output_mode
        self.skip_val_frames = skip_val_frames
        self.is_image_model = is_image_model
        self.normalize_by_max = self.hparams.get('normalize_by_max', True)
        self.normalize_by_zscore = self.hparams.get('normalize_by_zscore', False)
        self.normalize_type = self.hparams.get('normalize_type', "vector")
        # 统一控制日志是否进行分布式同步
        self.log_sync_dist = self.hparams.get('log_sync_dist', False)
        
        # 初始化指标，为风速场数据特别配置
        # PSNR和SSIM使用未归一化范围（-MAX_ABS_VALUE~MAX_ABS_VALUE）
        self.psnr = PeakSignalNoiseRatio(data_range=2 * self.MAX_ABS_VALUE)
        self.ssim = StructuralSimilarityIndexMeasure(data_range=2 * self.MAX_ABS_VALUE)
        # 单通道风速幅值指标，范围由setup.py中的max_high_res定义
        self.psnr_mag = PeakSignalNoiseRatio(data_range=self.MAX_HIGH_RES)
        self.ssim_mag = StructuralSimilarityIndexMeasure(data_range=self.MAX_HIGH_RES)
        # 向量和幅值的MSE、MAE指标
        self.mae = MeanAbsoluteError()  # 向量的MAE
        self.mse = MeanSquaredError()  # 向量的MSE
        self.mae_mag = MeanAbsoluteError()  # 幅值的MAE
        self.mse_mag = MeanSquaredError()  # 幅值的MSE
        
        # 初始化用于调试日志的列表
        if self.hparams.get('enable_debug_logging', False):
            self.debug_outputs_epoch = []
        
        # 不再固定SPyNet部分的参数，而是使用不同的学习率
        self.spynet_params = []
        self.other_params = []
        for name, param in self.model.named_parameters():
            if 'spynet' in name:
                self.spynet_params.append(param)
            else:
                self.other_params.append(param)
    
    def forward(self, x, **kwargs):
        """模型前向传播。
        
        Args:
            x: 输入张量，形状为 (b, t, c, h, w)
            
        Returns:
            torch.Tensor: 超分辨率输出
        """
        return self.model(x, **kwargs)
    
    def configure_optimizers(self): # pyright: ignore
        """配置优化器和学习率调度器。
        
        Returns:
            OptimizerLRScheduler: 包含优化器和学习率调度器的配置
        """
        optimizer: Optimizer = Adam(
            self.model.parameters(),
            lr=self.learning_rate,
            betas=(self.hparams.get('optimizer_beta1', 0.9), self.hparams.get('optimizer_beta2', 0.999))
        )
        
        train_dataloader_len = 10000 # Default value
        # 使用Lightning中正确的方法获取总步数，考虑多GPU情况
        if self.trainer:
            try:
                # 尝试使用最新的Lightning API
                if hasattr(self.trainer, 'estimated_stepping_batches'):
                    # 最新版Lightning的API
                    max_epochs = self.trainer.max_epochs or 200
                    train_dataloader_len = self.trainer.estimated_stepping_batches // max_epochs
                    print(f"\n使用trainer.estimated_stepping_batches获取的每个epoch的步数: {train_dataloader_len}\n")
                else:
                    # 通过手动计算考虑多GPU/多节点
                    datamodule = getattr(self.trainer, 'datamodule', None)
                    if datamodule and hasattr(datamodule, 'train_dataloader') and callable(datamodule.train_dataloader):
                        loader = datamodule.train_dataloader()
                        if loader is not None and isinstance(loader, Sized): # Ensure loader is Sized
                            # 获取单个设备上的批次数
                            single_device_batches = len(loader)
                            
                            # 获取设备总数（GPU数量）
                            num_devices = getattr(self.trainer, 'num_devices', 1)
                            num_nodes = getattr(self.trainer, 'num_nodes', 1)
                            world_size = num_devices * num_nodes
                            
                            # 处理数据并行的情况 - 批次总数
                            train_dataloader_len = single_device_batches
                            print(f"\n单GPU的batch数: {single_device_batches}, 设备数: {world_size}\n")
                            print(f"\n考虑多GPU后的总训练步数/epoch: {train_dataloader_len}\n")
                        else:
                            print(f"\nloader非Sized类型或为None，使用默认值: {train_dataloader_len}\n")
            except Exception as e:
                print(f"\n获取训练步数时出错: {str(e)}，使用默认值: {train_dataloader_len}\n")

        # 获取配置参数
        warmup_epochs = self.hparams.get('warmup_epochs', 5)  # 默认预热5个epoch
        max_epochs = self.hparams.get('max_epochs', 200)  # 总训练epoch数
        
        # 计算预热步数和总步数
        warmup_steps = int(warmup_epochs * train_dataloader_len)
        total_steps = int(max_epochs * train_dataloader_len)
        
        # 创建学习率调度器 - OneCycleLR具有内置的预热阶段
        scheduler = OneCycleLR(
            optimizer,
            max_lr=self.learning_rate,  # 最大学习率
            total_steps=total_steps,
            pct_start=warmup_steps / total_steps,  # 预热阶段比例
            div_factor=25.0,  # 初始学习率为max_lr/div_factor
            final_div_factor=3,  # 最终学习率为初始学习率/final_div_factor
            anneal_strategy='cos'  # 使用余弦退火策略
        )
        
        lr_scheduler_config = {
            "scheduler": scheduler, 
            "interval": "step", 
            "frequency": 1,
        }
        
        return {
            "optimizer": optimizer,
            "lr_scheduler": lr_scheduler_config 
        }
    
    def training_step(self, batch, batch_idx):
        """训练步骤。
        
        Args:
            batch: 批次数据
            batch_idx: 批次索引
            
        Returns:
            torch.Tensor: 损失值
        """
        # 根据 epoch 决定全帧或中心帧监督
        use_full = self.current_epoch < self.hparams.get('full_frame_supervision_epochs', 0)
        if hasattr(self.model, 'full_frame_supervision'):
            # 避免 Module.__setattr__ 类型限制，使用 object.__setattr__ 设置布尔属性
            object.__setattr__(self.model, 'full_frame_supervision', use_full)
        
        # 处理输入
        lq = batch['lq']  # 低质量输入
        gt = batch['gt']  # 高质量目标
        
        # 根据输入模式处理输入数据
        if self.input_mode == 'magnitude':
            # 计算幅值并保持维度 (b, t, 1, h, w)
            inputs = torch.sqrt(lq[..., 0:1, :, :] ** 2 + lq[..., 1:2, :, :] ** 2)
        elif self.input_mode == 'vector':
            # 使用原始向量 (b, t, 2, h, w)
            inputs = lq
        elif self.input_mode == 'magnitude_vector':
            # 计算幅值并与向量连接 (b, t, 3, h, w)
            mag = torch.sqrt(lq[..., 0:1, :, :] ** 2 + lq[..., 1:2, :, :] ** 2)
            inputs = torch.cat([mag, lq], dim=2)
        else:
            raise ValueError(f"无效的 input_mode: {self.input_mode}. 必须是 'magnitude', 'vector', 或 'magnitude_vector' 之一")
        
        # 如果需要，对输入数据进行归一化
        hparams_normalize_type = self.hparams.get('normalize_type', 'vector')
        if hparams_normalize_type == "vector":
            current_max_abs_val_in = self.MAX_ABS_VALUE
            current_mean_val_in = self.MEAN_VALUE
            current_std_val_in = self.STD_VALUE
            current_max_abs_val_out = self.MAX_ABS_VALUE
            current_mean_val_out = self.MEAN_VALUE
            current_std_val_out = self.STD_VALUE
        else:  # "magnitude"
            current_max_abs_val_in = self.MAX_LOW_RES
            current_mean_val_in = self.LOW_MEAN
            current_std_val_in = self.LOW_STD
            current_max_abs_val_out = self.MAX_HIGH_RES
            current_mean_val_out = self.HIGH_MEAN
            current_std_val_out = self.HIGH_STD

        if self.hparams.get('normalize_by_max', True):
            inputs = inputs / current_max_abs_val_in
        if self.hparams.get('normalize_by_zscore', False) and self.hparams.get('normalize_by_max', True):
            inputs = (inputs - current_mean_val_in) / current_std_val_in
        
        # 前向传播
        outputs = self.model(inputs)
        
        # 根据 full_frame_supervision 切片 GT：full 模式保留所有帧，center 模式只取中间帧
        if not use_full:
            seq_len = gt.shape[1]
            mid_idx = seq_len // 2
            gt = gt[:, mid_idx:mid_idx+1]
        
        # 根据模型的输出模式处理与目标的比较
        if self.output_mode == 'magnitude':
            # 模型输出是幅值，需要计算目标的幅值来进行比较
            targets_comp = torch.sqrt(gt[..., 0:1, :, :] ** 2 + gt[..., 1:2, :, :] ** 2)
            outputs_comp = outputs  # 模型输出已经是幅值
            
        elif self.output_mode == 'vector':
            # 模型输出是向量，直接与目标向量比较
            targets_comp = gt
            outputs_comp = outputs
            
        elif self.output_mode == 'magnitude_vector':
            # 模型输出是幅值和向量，需要生成对应的目标格式
            mag_gt = torch.sqrt(gt[..., 0:1, :, :] ** 2 + gt[..., 1:2, :, :] ** 2)
            targets_comp = torch.cat([mag_gt, gt], dim=2)
            outputs_comp = outputs
        else:
            raise ValueError(f"无效的 output_mode: {self.output_mode}. 必须是 'magnitude', 'vector', 或 'magnitude_vector' 之一")
        
        # 如果目标需要归一化以匹配输出
        hparams_normalize_type_val = self.hparams.get('normalize_type', 'vector')
        if hparams_normalize_type_val == "vector":
            current_max_abs_val_out = self.MAX_ABS_VALUE
            current_mean_val_out = self.MEAN_VALUE
            current_std_val_out = self.STD_VALUE
        else:  # "magnitude"
            current_max_abs_val_out = self.MAX_HIGH_RES
            current_mean_val_out = self.HIGH_MEAN
            current_std_val_out = self.HIGH_STD

        if self.hparams.get('normalize_by_max', True):
            targets_comp = targets_comp / current_max_abs_val_out
        if self.hparams.get('normalize_by_zscore', False) and self.hparams.get('normalize_by_max', True):
            targets_comp = (targets_comp - current_mean_val_out) / current_std_val_out
            
        assert outputs_comp is not None, "outputs_comp was not assigned in training_step"
        assert targets_comp is not None, "targets_comp was not assigned in training_step"

        # 计算损失
        loss = self.pixel_loss(outputs_comp, targets_comp)
        
        # 记录训练损失
        self.log('train_loss', loss, prog_bar=True, sync_dist=self.log_sync_dist)
        
        return loss
    
    def validation_step(self, batch, batch_idx, dataloader_idx=0):
        """验证步骤。
        
        Args:
            batch: 批次数据
            batch_idx: 批次索引
            dataloader_idx: 验证数据加载器的索引，用于区分不同年份的验证集
            
        Returns:
            dict: 包含预测和指标的字典
        """
        # 强制关闭全帧输出，仅输出中间帧用于验证
        if hasattr(self.model, 'full_frame_supervision'):
            object.__setattr__(self.model, 'full_frame_supervision', False)
        # 获取原始输入和目标
        lq = batch['lq']
        gt = batch['gt']
        
        # 如果设置了跳过前后帧，先检查帧数是否充足
        # 记录原始帧数和是否需要跳过帧
        skip_frames = False
        original_frames = lq.shape[1]
        
        if self.skip_val_frames > 0:
            if 2 * self.skip_val_frames >= original_frames:
                raise ValueError(f"跳过的帧数 {self.skip_val_frames} 太大，无法应用于只有 {original_frames} 帧的序列")
            else:
                skip_frames = True
        
        # 根据输入模式处理输入数据
        if self.input_mode == 'magnitude':
            # 计算幅值并保持维度 (b, t, 1, h, w)
            inputs = torch.sqrt(lq[..., 0:1, :, :] ** 2 + lq[..., 1:2, :, :] ** 2)
        elif self.input_mode == 'vector':
            # 使用原始向量 (b, t, 2, h, w)
            inputs = lq
        elif self.input_mode == 'magnitude_vector':
            # 计算幅值并与向量连接 (b, t, 3, h, w)
            mag = torch.sqrt(lq[..., 0:1, :, :] ** 2 + lq[..., 1:2, :, :] ** 2)
            inputs = torch.cat([mag, lq], dim=2)
        else:
            raise ValueError(f"无效的 input_mode: {self.input_mode}. 必须是 'magnitude', 'vector', 或 'magnitude_vector' 之一")
        
        # 如果需要，对输入数据进行归一化
        hparams_normalize_type = self.hparams.get('normalize_type', 'vector')
        if hparams_normalize_type == "vector":
            current_max_abs_val_in = self.MAX_ABS_VALUE
            current_mean_val_in = self.MEAN_VALUE
            current_std_val_in = self.STD_VALUE
            current_max_abs_val_out = self.MAX_ABS_VALUE
            current_mean_val_out = self.MEAN_VALUE
            current_std_val_out = self.STD_VALUE
        else:  # "magnitude"
            current_max_abs_val_in = self.MAX_LOW_RES
            current_mean_val_in = self.LOW_MEAN
            current_std_val_in = self.LOW_STD
            current_max_abs_val_out = self.MAX_HIGH_RES
            current_mean_val_out = self.HIGH_MEAN
            current_std_val_out = self.HIGH_STD

        if self.hparams.get('normalize_by_max', True):
            inputs = inputs / current_max_abs_val_in
        if self.hparams.get('normalize_by_zscore', False) and self.hparams.get('normalize_by_max', True):
            inputs = (inputs - current_mean_val_in) / current_std_val_in
        
        # 前向传播
        outputs = self.model(inputs)
        
        # 处理输出帧：
        # 1. 如果是图像超分模型，只使用中间帧的gt进行评估
        # 2. 如果需要跳过前后帧，则在计算损失和指标前对输出和目标进行裁剪
        if self.is_image_model:
            # 获取序列长度
            seq_len = gt.shape[1]
            # 取中间帧索引
            mid_idx = seq_len // 2
            # 仅保留中间帧的gt和对应的outputs
            gt = gt[:, mid_idx:mid_idx+1]
        elif skip_frames:
            outputs = outputs[:, self.skip_val_frames:-self.skip_val_frames]
            gt = gt[:, self.skip_val_frames:-self.skip_val_frames]
        
        # 初始化变量为安全的默认值，避免可能的未绑定错误
        # 初始化为零张量而不是None，以便与log函数兼容
        zeros_tensor = torch.zeros_like(gt)[..., 0:1, :, :]  # 创建一个单通道的零张量
        zeros_tensor_2ch = torch.zeros_like(gt)  # 创建一个双通道的零张量
        
        outputs_comp: torch.Tensor = torch.empty(0, device=lq.device)
        targets_comp: torch.Tensor = torch.empty(0, device=gt.device)
        val_loss = torch.tensor(0.0, device=gt.device)
        outputs_vec_unnorm: Optional[torch.Tensor] = zeros_tensor_2ch
        targets_vec_unnorm: Optional[torch.Tensor] = zeros_tensor_2ch
        outputs_mag_unnorm: Optional[torch.Tensor] = zeros_tensor
        targets_mag_unnorm: Optional[torch.Tensor] = zeros_tensor
        
        # 根据模型的输出模式处理输出数据和目标数据以计算损失
        if self.output_mode == 'magnitude':
            # 模型输出是幅值，需要计算目标的幅值来进行比较
            outputs_comp = outputs
            targets_comp = torch.sqrt(gt[..., 0:1, :, :] ** 2 + gt[..., 1:2, :, :] ** 2)
        elif self.output_mode == 'vector':
            # 模型输出是向量，直接与目标向量比较
            outputs_comp = outputs
            targets_comp = gt
        elif self.output_mode == 'magnitude_vector':
            # 模型输出是幅值和向量，需要生成对应的目标格式
            outputs_comp = outputs
            mag_gt = torch.sqrt(gt[..., 0:1, :, :] ** 2 + gt[..., 1:2, :, :] ** 2)
            targets_comp = torch.cat([mag_gt, gt], dim=2)
        else:
            raise ValueError(f"无效的 output_mode: {self.output_mode}. 必须是 'magnitude', 'vector', 或 'magnitude_vector' 之一")
        
        # 如果目标需要归一化以匹配输出
        hparams_normalize_type_val = self.hparams.get('normalize_type', 'vector')
        if hparams_normalize_type_val == "vector":
            current_max_abs_val_out = self.MAX_ABS_VALUE
            current_mean_val_out = self.MEAN_VALUE
            current_std_val_out = self.STD_VALUE
        else:  # "magnitude"
            current_max_abs_val_out = self.MAX_HIGH_RES
            current_mean_val_out = self.HIGH_MEAN
            current_std_val_out = self.HIGH_STD

        if self.hparams.get('normalize_by_max', True):
            targets_comp = targets_comp / current_max_abs_val_out
        if self.hparams.get('normalize_by_zscore', False) and self.hparams.get('normalize_by_max', True):
            targets_comp = (targets_comp - current_mean_val_out) / current_std_val_out
            
        assert outputs_comp is not None and outputs_comp.numel() > 0, "outputs_comp was not assigned or is empty in validation_step"
        assert targets_comp is not None and targets_comp.numel() > 0, "targets_comp was not assigned or is empty in validation_step"

        val_loss = self.pixel_loss(outputs_comp, targets_comp)
        
        # 对于所有模式，无论输出模式如何，都以统一的方式计算指标
        # 如果使用了z-score归一化，需要额外取消z-score归一化
        outputs_unnorm = outputs_comp.clone()
        targets_unnorm = targets_comp.clone()

        if self.hparams.get('normalize_by_zscore', False) and self.hparams.get('normalize_by_max', True):
            outputs_unnorm = outputs_unnorm * current_std_val_out + current_mean_val_out
            targets_unnorm = targets_unnorm * current_std_val_out + current_mean_val_out
        
        if self.hparams.get('normalize_by_max', True):
            outputs_unnorm = outputs_unnorm * current_max_abs_val_out
            targets_unnorm = targets_unnorm * current_max_abs_val_out

        # 默认初始化计算向量指标的标志
        calculate_vector_metrics = False
        
        # 根据输出模式确定计算哪些指标
        if self.output_mode == 'magnitude':
            # 如果只有幅值，则只计算幅值相关的指标
            # 不再为向量部分赋值，因为不会计算向量指标
            
            # 幅值指标使用模型输出的幅值
            outputs_mag_unnorm = outputs_unnorm
            targets_mag_unnorm = targets_unnorm
            
            # 标记不计算向量指标
            calculate_vector_metrics = False
            
        elif self.output_mode == 'vector':
            # 如果输出是向量，则直接使用向量计算向量指标
            outputs_vec_unnorm = outputs_unnorm
            targets_vec_unnorm = targets_unnorm
            
            # 计算幅值以求幅值指标
            outputs_mag_unnorm = torch.sqrt(outputs_unnorm[..., 0:1, :, :].pow(2) + outputs_unnorm[..., 1:2, :, :].pow(2))
            targets_mag_unnorm = torch.sqrt(targets_unnorm[..., 0:1, :, :].pow(2) + targets_unnorm[..., 1:2, :, :].pow(2))
            
            # 标记计算向量指标
            calculate_vector_metrics = True
            
        elif self.output_mode == 'magnitude_vector':
            # 如果输出同时包含幅值和向量，则分别计算
            outputs_mag_unnorm = outputs_unnorm[..., 0:1, :, :]
            outputs_vec_unnorm = outputs_unnorm[..., 1:3, :, :]
            targets_mag_unnorm = targets_unnorm[..., 0:1, :, :]
            targets_vec_unnorm = targets_unnorm[..., 1:3, :, :]
            
            # 标记计算向量指标
            calculate_vector_metrics = True
        
        # 计算向量指标 - 只在适用时计算
        if calculate_vector_metrics:
            # 检查维度，如果是3D数据 [B, C, D, H, W]，需要重塑为2D [B*D, C, H, W]
            if len(outputs_vec_unnorm.shape) == 5:
                b, c, d, h, w = outputs_vec_unnorm.shape
                # 重塑为 [B*D, C, H, W] 并确保内存连续
                outputs_vec_reshaped = outputs_vec_unnorm.permute(0, 2, 1, 3, 4).reshape(b*d, c, h, w).contiguous()
                targets_vec_reshaped = targets_vec_unnorm.permute(0, 2, 1, 3, 4).reshape(b*d, c, h, w).contiguous()
                
                # 使用重塑后的数据计算指标
                psnr = self.psnr(outputs_vec_reshaped, targets_vec_reshaped)
                ssim = self.ssim(outputs_vec_reshaped, targets_vec_reshaped)
                mae = self.mae(outputs_vec_reshaped, targets_vec_reshaped)
                mse = self.mse(outputs_vec_reshaped, targets_vec_reshaped)
            else:
                # 如果已经是2D数据 [B, C, H, W]，直接使用
                psnr = self.psnr(outputs_vec_unnorm, targets_vec_unnorm)
                ssim = self.ssim(outputs_vec_unnorm, targets_vec_unnorm)
                mae = self.mae(outputs_vec_unnorm, targets_vec_unnorm)
                mse = self.mse(outputs_vec_unnorm, targets_vec_unnorm)
        else:
            # 如果是幅值模式，不计算向量指标，设置为适当的默认值
            # 使用torch.tensor(0.0)而不是None，以便与log函数兼容
            psnr = torch.tensor(0.0)
            ssim = torch.tensor(0.0)
            mae = torch.tensor(0.0)
            mse = torch.tensor(0.0)
        
        # 计算幅值指标 - 始终基于幅值
        # 同样检查维度
        if len(outputs_mag_unnorm.shape) == 5:
            b, c, d, h, w = outputs_mag_unnorm.shape
            # 重塑为 [B*D, C, H, W] 并确保内存连续
            outputs_mag_reshaped = outputs_mag_unnorm.permute(0, 2, 1, 3, 4).reshape(b*d, c, h, w).contiguous()
            targets_mag_reshaped = targets_mag_unnorm.permute(0, 2, 1, 3, 4).reshape(b*d, c, h, w).contiguous()
            
            # 使用重塑后的数据计算指标
            mag_psnr = self.psnr_mag(outputs_mag_reshaped, targets_mag_reshaped)
            mag_ssim = self.ssim_mag(outputs_mag_reshaped, targets_mag_reshaped)
            mag_mae = self.mae_mag(outputs_mag_reshaped, targets_mag_reshaped)
            mag_mse = self.mse_mag(outputs_mag_reshaped, targets_mag_reshaped)
        else:
            # 如果已经是2D数据，直接使用
            mag_psnr = self.psnr_mag(outputs_mag_unnorm, targets_mag_unnorm)
            mag_ssim = self.ssim_mag(outputs_mag_unnorm, targets_mag_unnorm)
            mag_mae = self.mae_mag(outputs_mag_unnorm, targets_mag_unnorm)
            mag_mse = self.mse_mag(outputs_mag_unnorm, targets_mag_unnorm)
        
        # 根据dataloader_idx确定当前验证集年份
        val_year = f"_{2009 if dataloader_idx == 0 else 2020}" if dataloader_idx <= 1 else ""
        
        # 记录评估指标，加上年份后缀以区分不同验证集
        self.log(f'val_loss{val_year}', val_loss, add_dataloader_idx=False, sync_dist=self.log_sync_dist)
        # 始终记录幅值指标，无论是哪种输出模式
        self.log(f'val_psnr_mag{val_year}', mag_psnr, add_dataloader_idx=False, sync_dist=self.log_sync_dist)
        self.log(f'val_ssim_mag{val_year}', mag_ssim, add_dataloader_idx=False, sync_dist=self.log_sync_dist)
        self.log(f'val_mae_mag{val_year}', mag_mae, add_dataloader_idx=False, sync_dist=self.log_sync_dist)
        self.log(f'val_mse_mag{val_year}', mag_mse, add_dataloader_idx=False, sync_dist=self.log_sync_dist)
        
        # 同时记录不带年份的指标以便于总体比较
        if dataloader_idx == 0:  # 只用第一个验证集记录总体指标
            self.log('val_psnr_mag', mag_psnr, add_dataloader_idx=False, sync_dist=self.log_sync_dist)
            self.log('val_ssim_mag', mag_ssim, add_dataloader_idx=False, sync_dist=self.log_sync_dist)

        if self.output_mode == 'vector' or self.output_mode == 'magnitude_vector':
            # 向量或幅值+向量输出模式下，记录向量指标
            self.log(f'val_psnr{val_year}', psnr, add_dataloader_idx=False, sync_dist=self.log_sync_dist)
            self.log(f'val_ssim{val_year}', ssim, add_dataloader_idx=False, sync_dist=self.log_sync_dist)
            self.log(f'val_mae{val_year}', mae, add_dataloader_idx=False, sync_dist=self.log_sync_dist)
            self.log(f'val_mse{val_year}', mse, add_dataloader_idx=False, sync_dist=self.log_sync_dist)
            
            # 同时记录不带年份的指标
            if dataloader_idx == 0:  # 只用第一个验证集记录总体指标
                self.log('val_psnr', psnr, add_dataloader_idx=False, sync_dist=self.log_sync_dist)
                self.log('val_ssim', ssim, add_dataloader_idx=False, sync_dist=self.log_sync_dist)
        
        # 构建返回字典
        return_dict = {
            'val_loss': val_loss,
            'val_psnr_mag': mag_psnr,
            'val_ssim_mag': mag_ssim,
            'val_mae_mag': mag_mae,
            'val_mse_mag': mag_mse,
            'preds': outputs.detach().cpu(),
            'targets': gt.detach().cpu()  # 始终使用原始目标数据
        }
        
        # 只在计算了向量指标时添加到返回字典
        if calculate_vector_metrics:
            return_dict.update({
                'val_psnr': psnr,
                'val_ssim': ssim,
                'val_mae': mae,
                'val_mse': mse
            })
        
        # 如果启用了调试日志记录
        if self.hparams.get('enable_debug_logging', False) and hasattr(self, 'debug_outputs_epoch'):
            # 确保记录的是cpu上的numpy数组
            # 记录用于计算损失的 output 和 target，以及原始的 gt
            # 注意: outputs_comp 和 targets_comp 可能是归一化后的版本
            # gt_original 是未经任何修改的原始真实值
            debug_data = {
                'model_output': outputs_comp.detach().cpu().numpy(),       # This is normalized model output
                'processed_ground_truth': targets_comp.detach().cpu().numpy(), # This is normalized GT for loss
                'original_ground_truth': gt.detach().cpu().numpy(), # gt is after frame skipping but before normalization
                'lq': lq.detach().cpu().numpy() # 添加 lq 数据
            }
            self.debug_outputs_epoch.append(debug_data)
        
        return return_dict
    
    def test_step(self, batch, batch_idx, dataloader_idx=0):
        """Alias to run validation_step during test."""
        return self.validation_step(batch, batch_idx, dataloader_idx)
    
    def on_validation_epoch_start(self):
        """在验证的每个epoch开始时调用。"""
        if self.hparams.get('enable_debug_logging', False):
            self.debug_outputs_epoch = []
    
    def on_validation_epoch_end(self):
        """在验证的每个epoch结束时调用。"""
        if self.hparams.get('enable_debug_logging', False) and hasattr(self, 'debug_outputs_epoch') and self.debug_outputs_epoch:
            all_model_outputs = []
            all_processed_gts = []
            all_original_gts = []
            all_lqs = [] # 初始化 lq 列表
            
            for data_batch in self.debug_outputs_epoch:
                all_model_outputs.append(data_batch['model_output'])
                all_processed_gts.append(data_batch['processed_ground_truth'])
                all_original_gts.append(data_batch['original_ground_truth'])
                all_lqs.append(data_batch['lq']) # 提取 lq 数据
            
            try:
                # 将列表中的numpy数组堆叠起来
                # 注意：如果每个batch的帧数（T维度）或样本数（B维度）不同，直接堆叠可能会失败
                # 假设每个batch的 B, T, C, H, W 维度是固定的，或者至少 T, C, H, W 是固定的
                # 如果帧数可变，可能需要更复杂的处理，比如填充或者分别保存每个batch
                # 这里我们尝试直接连接，如果失败，则打印错误信息
                final_model_outputs = np.concatenate(all_model_outputs, axis=0) # 假设在batch维度(0)连接
                final_processed_gts = np.concatenate(all_processed_gts, axis=0)
                final_original_gts = np.concatenate(all_original_gts, axis=0)
                final_lqs = np.concatenate(all_lqs, axis=0) # 连接 lq 数据
                
                np.savez_compressed(
                    self.hparams.get('debug_log_path', "debug_validation_output.npz"), 
                    model_output=final_model_outputs,
                    processed_ground_truth=final_processed_gts,
                    original_ground_truth=final_original_gts,
                    lq=final_lqs # 添加 lq 到保存文件
                )
                print(f"调试日志已保存到 {self.hparams.get('debug_log_path', 'debug_validation_output.npz')} (compressed)")
            except ValueError as e:
                print(f"保存调试日志到 {self.hparams.get('debug_log_path', 'debug_validation_output.npz')} 失败: {e}")
                print("这可能是由于不同batch的形状不一致导致的。考虑单独保存每个batch或进行填充。")
                # 作为后备方案，可以考虑将每个批次单独保存，或者记录到一个更灵活的格式

            # 清空列表为下一个epoch做准备
            self.debug_outputs_epoch = []
