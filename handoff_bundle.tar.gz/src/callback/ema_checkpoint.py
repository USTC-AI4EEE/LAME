from __future__ import annotations

from typing import Optional

from lightning.pytorch.callbacks import ModelCheckpoint
from lightning.pytorch import Trainer, LightningModule

try:
    # Reuse EMAOptimizer from our EMA callback implementation
    from src.callback.ema import EMAOptimizer
except Exception:  # pragma: no cover - defensive import guard
    EMAOptimizer = None  # type: ignore


class EMAModelCheckpoint(ModelCheckpoint):
    """
    A ModelCheckpoint that always saves EMA weights instead of the raw weights.

    This callback temporarily swaps model parameters to the EMA copy right before
    delegating to the underlying ModelCheckpoint saving logic, and swaps back
    immediately after, so the saved checkpoint contains EMA weights regardless of
    callback execution order.

    Configure filename/monitor/mode the same way as standard ModelCheckpoint.
    Recommended to set a filename suffix like "-EMA" in config.
    """

    # Use a distinct filename for "last" to avoid clobbering the raw-weights last.ckpt
    CHECKPOINT_NAME_LAST = "last-EMA"

    def _get_ema_optimizer(self, trainer: Trainer) -> Optional["EMAOptimizer"]:
        if EMAOptimizer is None:
            return None
        for opt in getattr(trainer, "optimizers", []) or []:
            if isinstance(opt, EMAOptimizer):
                return opt
        return None

    def _save_with_ema(self, trainer: Trainer, pl_module: LightningModule, hook_name: str):
        ema_opt = self._get_ema_optimizer(trainer)
        if ema_opt is None:
            # Fallback: no EMA initialized, behave like standard checkpoint
            getattr(super(), hook_name)(trainer, pl_module)
            return

        # swap to EMA weights just for saving
        ema_opt.switch_main_parameter_weights(saving_ema_model=True)
        try:
            getattr(super(), hook_name)(trainer, pl_module)
        finally:
            # swap back to original weights
            ema_opt.switch_main_parameter_weights(saving_ema_model=False)

    # Save checkpoints after validation
    def on_validation_end(self, trainer: Trainer, pl_module: LightningModule) -> None:  # type: ignore[override]
        self._save_with_ema(trainer, pl_module, "on_validation_end")

    # Save last checkpoint at train end if configured
    def on_train_end(self, trainer: Trainer, pl_module: LightningModule) -> None:  # type: ignore[override]
        self._save_with_ema(trainer, pl_module, "on_train_end")
