import os
import sys
import subprocess
from typing import Any, Tuple

import torch


def _ensure_package(mod_name: str, pip_name: str | None = None) -> None:
    try:
        __import__(mod_name)
    except Exception:
        subprocess.check_call([sys.executable, "-m", "pip", "install", pip_name or mod_name])


# Ensure runtime deps for FLOPs analysis and some model components
_ensure_package("fvcore")
_ensure_package("iopath")
_ensure_package("hydra-core")
_ensure_package("hydra-colorlog")
_ensure_package("rootutils")
_ensure_package("lightning")
_ensure_package("torchmetrics")

# Try import basicsr; if unavailable (e.g., due to OpenCV/libGL issues), create lightweight stubs
try:
    import basicsr  # type: ignore  # noqa: F401
except Exception:
    import types
    import torch.nn.functional as F

    basicsr = types.ModuleType("basicsr")
    basicsr.archs = types.ModuleType("basicsr.archs")
    basicsr.utils = types.ModuleType("basicsr.utils")

    arch_util = types.ModuleType("basicsr.archs.arch_util")

    def _to_2tuple(x):
        if isinstance(x, (list, tuple)):
            return tuple(x) if len(x) == 2 else (x[0], x[0])
        return (x, x)

    def _trunc_normal_(tensor, mean=0.0, std=1.0):
        try:
            torch.nn.init.trunc_normal_(tensor, mean=mean, std=std)
        except Exception:
            torch.nn.init.normal_(tensor, mean=mean, std=std)
        return tensor

    def _flow_warp(x: torch.Tensor, flow: torch.Tensor, interpolation: str = "bilinear",
                   padding_mode: str = "border", align_corners: bool = True) -> torch.Tensor:
        # Accept flow in (B, 2, H, W) or (B, H, W, 2)
        if flow.dim() == 4 and flow.size(1) == 2:
            flow = flow.permute(0, 2, 3, 1)
        b, c, h, w = x.shape
        yy, xx = torch.meshgrid(torch.arange(h, device=x.device), torch.arange(w, device=x.device), indexing='ij')
        base_grid = torch.stack((xx, yy), dim=-1).float()  # (H, W, 2)
        grid = base_grid.unsqueeze(0) + flow  # (B, H, W, 2)
        grid_x = 2.0 * grid[..., 0] / max(w - 1, 1) - 1.0
        grid_y = 2.0 * grid[..., 1] / max(h - 1, 1) - 1.0
        grid_norm = torch.stack((grid_x, grid_y), dim=-1)
        return F.grid_sample(x, grid_norm, mode=interpolation, padding_mode=padding_mode, align_corners=align_corners)

    arch_util.to_2tuple = _to_2tuple
    arch_util.trunc_normal_ = _trunc_normal_
    arch_util.flow_warp = _flow_warp

    basicvsr_arch = types.ModuleType("basicsr.archs.basicvsr_arch")

    class _ConvResidualBlocks(torch.nn.Module):
        def __init__(self, *_, **__):
            super().__init__()
        def forward(self, x):
            return x

    basicvsr_arch.ConvResidualBlocks = _ConvResidualBlocks

    registry = types.ModuleType("basicsr.utils.registry")

    class _Registry:
        def register(self, *_, **__):
            def deco(fn):
                return fn
            return deco

    registry.ARCH_REGISTRY = _Registry()

    # Wire into sys.modules so `import basicsr...` works
    sys.modules["basicsr"] = basicsr
    sys.modules["basicsr.archs"] = basicsr.archs
    sys.modules["basicsr.utils"] = basicsr.utils
    sys.modules["basicsr.archs.arch_util"] = arch_util
    sys.modules["basicsr.archs.basicvsr_arch"] = basicvsr_arch
    sys.modules["basicsr.utils.registry"] = registry

from fvcore.nn import FlopCountAnalysis, parameter_count, flop_count_table  # noqa: E402


import hydra  # noqa: E402
import rootutils  # noqa: E402
from omegaconf import DictConfig, OmegaConf  # noqa: E402


# Make project importable and set PROJECT_ROOT env
rootutils.setup_root(__file__, indicator=".project-root", pythonpath=True)


def _infer_input_shape(cfg: DictConfig, model: torch.nn.Module) -> Tuple[int, int, int, int]:
    """Infer (T, C, H, W) from hydra config and model attributes.

    Priority:
    - T, H, W from cfg.data.dataset_config if available; defaults to (3, 64, 64)
    - C from nested model attribute `in_channels` (if present)
      else from cfg.model.model.in_channels (if provided)
      else from cfg.model.input_mode
      else fallback to 2
    """

    # Defaults
    T = 3
    H, W = 64, 64

    # Try to resolve from data config
    try:
        ds_cfg = cfg.get("data", {}).get("dataset_config", {})
        if isinstance(ds_cfg, DictConfig):
            ds_cfg = OmegaConf.to_container(ds_cfg, resolve=True)
        if isinstance(ds_cfg, dict):
            if isinstance(ds_cfg.get("num_frames"), int):
                T = int(ds_cfg["num_frames"])  # type: ignore
            size = ds_cfg.get("target_size")
            if isinstance(size, (list, tuple)) and len(size) == 2:
                H, W = int(size[0]), int(size[1])
    except Exception:
        pass

    # Determine channels from model
    C = None
    # If LightningModule has `.model`, use that
    inner = getattr(model, "model", model)
    for attr in ("in_channels", "in_chans"):
        if hasattr(inner, attr):
            try:
                C_val = int(getattr(inner, attr))
                if C_val > 0:
                    C = C_val
                    break
            except Exception:
                pass

    if C is None:
        # Try from config
        try:
            model_cfg = cfg.get("model")
            if model_cfg is not None:
                # nested `model:` kwargs
                nested = model_cfg.get("model")
                if nested is not None and isinstance(nested, DictConfig):
                    if "in_channels" in nested:
                        C = int(nested.get("in_channels"))
        except Exception:
            pass

    if C is None:
        # Try from input_mode
        try:
            mode = str(cfg.get("model", {}).get("input_mode", "")).lower()
            if mode == "magnitude":
                C = 1
            elif mode == "vector":
                C = 2
            elif mode == "magnitude_vector":
                C = 3
        except Exception:
            pass

    if C is None:
        C = 2

    return T, C, H, W


def _format_number(n: float, unit: str) -> str:
    if unit == "FLOPs":
        # Return in GigaFLOPs
        return f"{n / 1e9:.3f} G"
    if unit == "Params":
        return f"{n / 1e6:.3f} M"
    return f"{n:.3f}"


def _param_stats(model: torch.nn.Module) -> Tuple[float, float]:
    """Return (total_params, trainable_params) as floats."""
    # total via fvcore (includes all params)
    params_dict = parameter_count(model)
    total_params = float(sum(params_dict.values()))
    # trainable via requires_grad
    trainable_params = float(sum(p.numel() for p in model.parameters() if getattr(p, "requires_grad", False)))
    return total_params, trainable_params


@hydra.main(version_base="1.3", config_path="../../configs", config_name="train.yaml")
def main(cfg: DictConfig) -> None:
    # Keep stdout small and focused
    # Instantiate model from hydra config
    model = hydra.utils.instantiate(cfg.model)
    model.eval()

    # Infer input shape and build dummy input (C is needed for some patches below)
    T, C, H, W = _infer_input_shape(cfg, model)
    B = 1
    # Workaround for SPyNet channel mismatch when using 3-channel inputs
    try:
        inner = getattr(model, "model", model)
        print("[FLOPs] inner model:", type(inner).__name__, "in_channels=", getattr(inner, "in_channels", None), "out_channels=", getattr(inner, "out_channels", None))
        spynet = getattr(inner, "spynet", None)
        if spynet is not None and hasattr(spynet, "in_channels") and int(spynet.in_channels) > 2:
            # Recreate SPyNet with 2-channel input to match forward trimming logic
            from src.models.components.basicvsr_net import SPyNet  # local import
            inner.spynet = SPyNet(in_channels=2, pretrained=None)  # type: ignore[attr-defined]
    except Exception:
        pass

    # If requested C < 2 but model expects optical flow, stub out compute_flow with zeros to enable FLOPs pass
    try:
        inner = getattr(model, "model", model)
        has_cf = hasattr(inner, "compute_flow")
        is_cf_callable = callable(getattr(inner, "compute_flow", None))
        print(f"[FLOPs] C={C}, has_compute_flow={has_cf}, callable={is_cf_callable}")
        if C < 2 and has_cf and is_cf_callable:
            def _zero_flow(lrs: torch.Tensor):
                n, t, _, h, w = lrs.shape
                zf = torch.zeros((n, t - 1, 2, h, w), device=lrs.device, dtype=lrs.dtype)
                return zf, zf
            # Monkey patch
            setattr(inner, "compute_flow", _zero_flow)
            print("[FLOPs] compute_flow patched to zero-flow stub for:", type(inner).__name__)
    except Exception:
        pass

    x = torch.randn(B, T, C, H, W)

    # Compute FLOPs/params on CPU
    with torch.no_grad():
        try:
            flops = FlopCountAnalysis(model, (x,))
            total_flops = float(flops.total())
            total_params, trainable_params = _param_stats(model)

            # Print summary table and headline numbers
            print(flop_count_table(flops, max_depth=3))
            print("Input shape (B, T, C, H, W):", (B, T, C, H, W))
            print("Total FLOPs (sequence):", _format_number(total_flops, "FLOPs"))
            print("FLOPs per frame:", _format_number(total_flops / max(T, 1), "FLOPs"))
            print("Total Params:", _format_number(total_params, "Params"))
            print("Trainable Params:", _format_number(trainable_params, "Params"))
        except Exception as e:
            # Try model-provided FLOPs estimators if available (e.g., PSRT/DRCT)
            print("[WARN] FLOPs analysis failed:", repr(e))
            inner = getattr(model, "model", model)
            custom_ok = False
            try:
                if hasattr(inner, "flops") and callable(getattr(inner, "flops")):
                    custom_flops = float(inner.flops())
                    print("Custom FLOPs (sequence):", _format_number(custom_flops, "FLOPs"))
                    print("Custom FLOPs per frame:", _format_number(custom_flops / max(T, 1), "FLOPs"))
                    custom_ok = True
            except Exception as e2:
                print("[WARN] Custom flops() failed:", repr(e2))

            # Always report params
            total_params, trainable_params = _param_stats(model)
            if not custom_ok:
                print("[INFO] Reporting parameter count only.")
            print("Total Params:", _format_number(total_params, "Params"))
            print("Trainable Params:", _format_number(trainable_params, "Params"))


if __name__ == "__main__":
    # Hydra changes CWD; ensure minimal stdout buffering surprises
    os.environ.setdefault("PYTHONUNBUFFERED", "1")
    main()
