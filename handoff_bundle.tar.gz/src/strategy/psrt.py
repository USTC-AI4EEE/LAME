import torch.nn as nn
from lightning.pytorch.strategies import FSDPStrategy

from src.models.components.psrt_recurrent import BasicRecurrentSwin
from src.models.components.psrt_sliding_arch import SwinIRFM, RSTB, BasicLayer, SwinTransformerBlock, WindowAttention
from src.models.components.basicvsr_net import SPyNet

WRAP_MODULES = [
    SwinTransformerBlock,
]

def wrap_policy(
    module: nn.Module,
    recurse: bool,
    nonwrapped_numel: int,
) -> bool:
    if not any(param.requires_grad for param in module.parameters()):
        return False

    if recurse:
        return True

    return isinstance(module, tuple(WRAP_MODULES))

# Global counter for wrapped modules
already_wrapped_modules_num = 0

def checkpoint_wrap_policy(module: nn.Module, recurse: bool, nonwrapped_numel: int) -> bool:
    """Applies activation checkpointing only to the first 12 SwinTransformerBlock modules encountered globally."""
    global already_wrapped_modules_num # Declare modification of the global variable

    # We always recurse down the modules
    if recurse:
        return True

    # Apply checkpointing specifically to SwinTransformerBlock
    if isinstance(module, SwinTransformerBlock):
        # Check if the global limit has been reached
        if already_wrapped_modules_num < 12:
            already_wrapped_modules_num += 1 # Increment the global counter
            return True # Wrap this module
        else:
            return False # Limit reached, do not wrap
            
    # Do not wrap other module types by default with this policy
    return False

class MyStrategy(FSDPStrategy):
    def __init__(self, cpu_offload: bool = False):
        super().__init__(
            auto_wrap_policy=wrap_policy,
            activation_checkpointing_policy=checkpoint_wrap_policy,
            use_orig_params=True,
            cpu_offload=cpu_offload,
            sharding_strategy="SHARD_GRAD_OP",
            limit_all_gathers=True,
        )
