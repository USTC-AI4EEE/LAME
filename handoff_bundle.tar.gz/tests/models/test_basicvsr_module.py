import pytest
import torch
from src.models.basicvsr_module import BasicVSRLightning
from src.models.components.basicvsr_net import BasicVSRNet


def test_basicvsr_lightning_init():
    """测试BasicVSRLightning模块的初始化"""
    # 创建基础模型
    model = BasicVSRNet(mid_channels=64, num_blocks=30)
    
    # 创建Lightning模块
    lightning_model = BasicVSRLightning(
        model=model,
        learning_rate=2e-4
    )
    
    # 测试模型是否正确初始化
    assert isinstance(lightning_model.model, BasicVSRNet)
    assert lightning_model.learning_rate == 2e-4
    
    # 测试参数分组是否正确
    spynet_params = [name for name, _ in lightning_model.model.named_parameters() if 'spynet' in name]
    other_params = [name for name, _ in lightning_model.model.named_parameters() if 'spynet' not in name]
    
    assert len(lightning_model.spynet_params) == len(spynet_params)
    assert len(lightning_model.other_params) == len(other_params)
    
    # 测试优化器配置
    optimizer = lightning_model.configure_optimizers()
    assert isinstance(optimizer['optimizer'], torch.optim.Adam)
    assert isinstance(optimizer['lr_scheduler']['scheduler'], torch.optim.lr_scheduler.CosineAnnealingWarmRestarts)
    
    # 测试前向传播
    batch_size = 2
    seq_len = 5
    channels = 3
    height = 64
    width = 64
    
    x = torch.randn(batch_size, seq_len, channels, height, width)
    output = lightning_model(x)
    
    # 检查输出形状是否正确（4倍上采样）
    assert output.shape == (batch_size, seq_len, channels, height * 4, width * 4) 